import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { Chart, registerables } from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';
import 'chartjs-adapter-date-fns';

// Register Chart.js components
Chart.register(...registerables, annotationPlugin);

// Add global styles 
const style = document.createElement('style');
style.textContent = `
  body {
    background-color: #0A0A1A;
    background-image: 
      radial-gradient(circle at 10% 20%, rgba(78, 17, 168, 0.1) 0%, transparent 20%),
      radial-gradient(circle at 90% 80%, rgba(0, 229, 255, 0.1) 0%, transparent 20%);
    background-attachment: fixed;
  }

  .bg-gradient-primary {
    background: linear-gradient(135deg, #141432 0%, #1A1B4B 100%);
  }

  .bg-gradient-accent {
    background: linear-gradient(135deg, #00B3CC 0%, #00E5FF 100%);
  }

  .bg-gradient-danger {
    background: linear-gradient(135deg, #CC0000 0%, #FF5252 100%);
  }

  .bg-gradient-warning {
    background: linear-gradient(135deg, #CCAA00 0%, #FFD600 100%);
  }

  .border-accent {
    border-color: #00E5FF;
  }

  .text-gradient {
    background: linear-gradient(135deg, #00B3CC 0%, #00E5FF 100%);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  .nav-link {
    border-left: 3px solid transparent;
    transition: all 0.3s ease;
  }

  .nav-link.active {
    border-left-color: #00E5FF;
    background-color: rgba(0, 229, 255, 0.1);
  }

  .nav-link:hover:not(.active) {
    background-color: rgba(255, 255, 255, 0.05);
  }

  .card-border-top {
    position: relative;
  }

  .card-border-top::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(135deg, #00B3CC 0%, #00E5FF 100%);
  }

  .card-border-top.danger::before {
    background: linear-gradient(135deg, #CC0000 0%, #FF5252 100%);
  }

  .card-border-top.warning::before {
    background: linear-gradient(135deg, #CCAA00 0%, #FFD600 100%);
  }

  .status-pulse {
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0% {
      box-shadow: 0 0 0 0 rgba(255, 82, 82, 0.4);
    }
    70% {
      box-shadow: 0 0 0 10px rgba(255, 82, 82, 0);
    }
    100% {
      box-shadow: 0 0 0 0 rgba(255, 82, 82, 0);
    }
  }

  /* Chart canvas animation */
  .chart-container {
    position: relative;
    transition: transform 0.3s ease;
  }

  .chart-container:hover {
    transform: translateY(-5px);
  }

  /* Sci-fi border effects */
  .sci-fi-border {
    position: relative;
    overflow: hidden;
  }

  .sci-fi-border::after {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    z-index: -1;
    background: linear-gradient(45deg, #00E5FF, transparent, #00E5FF, transparent);
    animation: border-animation 4s linear infinite;
  }

  @keyframes border-animation {
    0% {
      background-position: 0% 100%;
    }
    50% {
      background-position: 100% 0%;
    }
    100% {
      background-position: 0% 100%;
    }
  }
`;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
