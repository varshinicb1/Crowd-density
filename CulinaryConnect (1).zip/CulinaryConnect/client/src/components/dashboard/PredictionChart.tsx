import React, { useEffect, useRef } from 'react';
import { Chart } from 'chart.js';
import { generateTimeLabels } from '../../lib/sensor-utils';

interface PredictionChartProps {
  predictionData: {
    timestamps: number[];
    density: number[];
    crowdCount: number[];
    confidence: number[];
  } | null;
  criticalThreshold: number;
  highThreshold: number;
}

const PredictionChart: React.FC<PredictionChartProps> = ({ 
  predictionData, 
  criticalThreshold,
  highThreshold
}) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  // Chart colors
  const chartColors = {
    primary: '#00E5FF',
    secondary: '#4E11A8',
    danger: '#FF5252',
    warning: '#FFD600',
    success: '#AEEA00',
    grid: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.7)'
  };
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Generate time labels
    const timeLabels = generateTimeLabels(21);
    
    // Create new chart
    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: timeLabels,
        datasets: [{
          label: 'Predicted Density',
          data: predictionData ? predictionData.density : [],
          borderColor: chartColors.primary,
          backgroundColor: 'rgba(0, 229, 255, 0.1)',
          borderWidth: 2,
          pointRadius: 3,
          pointBackgroundColor: chartColors.primary,
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(20, 20, 50, 0.9)',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            borderColor: 'rgba(0, 229, 255, 0.3)',
            borderWidth: 1,
            callbacks: {
              label: function(context) {
                return `Density: ${context.parsed.y.toFixed(2)}`;
              }
            }
          },
          annotation: {
            annotations: {
              criticalLine: {
                type: 'line',
                yMin: criticalThreshold,
                yMax: criticalThreshold,
                borderColor: chartColors.danger,
                borderWidth: 2,
                borderDash: [5, 5],
                label: {
                  display: true,
                  content: 'Critical',
                  position: 'end',
                  backgroundColor: 'rgba(255, 82, 82, 0.8)',
                  color: '#FFFFFF',
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                }
              },
              highLine: {
                type: 'line',
                yMin: highThreshold,
                yMax: highThreshold,
                borderColor: chartColors.warning,
                borderWidth: 2,
                borderDash: [5, 5],
                label: {
                  display: true,
                  content: 'High',
                  position: 'end',
                  backgroundColor: 'rgba(255, 214, 0, 0.8)',
                  color: '#FFFFFF',
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                }
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.text,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          },
          y: {
            beginAtZero: true,
            max: 1.5,
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.text,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              },
              callback: function(value) {
                return value.toFixed(1);
              }
            }
          }
        }
      }
    });
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [predictionData, criticalThreshold, highThreshold]);
  
  return <canvas ref={chartRef}></canvas>;
};

export default PredictionChart;
