import React from 'react';
import { formatDate, formatFullDate } from '../../lib/sensor-utils';
import { cn } from '@/lib/utils';

interface Alert {
  id: number;
  timestamp: Date;
  alertType: 'critical' | 'high' | 'prediction';
  message: string;
  details: Record<string, any>;
  acknowledged: boolean;
}

interface AlertItemProps {
  alert: Alert;
  detailed?: boolean;
}

const AlertItem: React.FC<AlertItemProps> = ({ alert, detailed = false }) => {
  // Determine icon, classes and title based on alert type
  let icon = '';
  let borderClass = '';
  let bgClass = '';
  let textClass = '';
  let title = '';
  
  switch (alert.alertType) {
    case 'critical':
      icon = 'fas fa-exclamation-triangle';
      borderClass = 'border-danger';
      bgClass = 'bg-danger/10';
      textClass = 'text-danger';
      title = 'Critical Density Alert';
      break;
    case 'high':
      icon = 'fas fa-exclamation-circle';
      borderClass = 'border-warning';
      bgClass = 'bg-warning/10';
      textClass = 'text-warning';
      title = 'High Density Warning';
      break;
    case 'prediction':
      icon = 'fas fa-info-circle';
      borderClass = 'border-accent';
      bgClass = 'bg-accent/10';
      textClass = 'text-accent';
      title = 'Prediction Alert';
      break;
  }
  
  // Format date
  const formattedDate = new Date(alert.timestamp).toLocaleDateString();
  const formattedTime = formatDate(new Date(alert.timestamp));
  
  return (
    <div className={cn(`border-l-4 ${borderClass} ${bgClass} rounded-r-md p-3 flex items-center`, detailed && 'p-4')}>
      <div className={cn(`${textClass} mr-3`)}>
        <i className={icon}></i>
      </div>
      <div className="flex-1">
        <h4 className="font-primary font-medium">{title}</h4>
        <p className="text-sm text-text-tertiary">{alert.message}</p>
        
        {detailed && alert.details && (
          <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {Object.entries(alert.details).filter(([key]) => 
              ['eco2', 'tvoc', 'etoh', 'iaq'].includes(key)
            ).map(([key, value]) => (
              <div key={key}>
                <div className="text-xs text-text-tertiary">{key.toUpperCase()}</div>
                <div className="font-mono">{value} {key === 'eco2' ? 'ppm' : key === 'iaq' ? '' : 'ppb'}</div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="text-xs text-text-tertiary text-right">
        {formattedDate}<br />
        {formattedTime}
      </div>
    </div>
  );
};

export default AlertItem;
