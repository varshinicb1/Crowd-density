import React, { useContext } from 'react';
import StatusCard from './StatusCard';
import PredictionChart from './PredictionChart';
import SensorCard from './SensorCard';
import AlertItem from './AlertItem';
import { AppContext } from '../../App';

const DashboardPage: React.FC = () => {
  const { state, fetchSensorData } = useContext(AppContext);
  const { currentData, predictionData, alertHistory } = state;
  
  // Calculate peak density from prediction
  const peakDensity = predictionData ? 
    Math.max(...predictionData.density) : 
    currentData ? parseFloat(currentData.density) : 0;
  
  // Calculate average confidence
  const avgConfidence = predictionData ? 
    predictionData.confidence.reduce((sum, val) => sum + val, 0) / predictionData.confidence.length : 
    0;
  
  return (
    <div className="p-6">
      <div className="flex flex-wrap items-center justify-between mb-6">
        <h2 className="text-2xl font-primary font-semibold">Crowd Monitoring Dashboard</h2>
        <button 
          onClick={() => fetchSensorData()}
          className="bg-accent/10 hover:bg-accent/20 text-accent rounded-md px-4 py-2 flex items-center transition duration-300"
        >
          <i className="fas fa-sync-alt mr-2"></i>
          <span>Refresh</span>
        </button>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatusCard 
          title="CROWD DENSITY"
          value={currentData ? parseFloat(currentData.density).toFixed(2) : "0.00"}
          subtitle="normalized value (0-1+)"
          status={currentData ? parseFloat(currentData.density) : 0}
          criticalThreshold={parseFloat(state.settings.critical_threshold)}
          highThreshold={parseFloat(state.settings.high_threshold)}
        />
        
        <StatusCard 
          title="ESTIMATED COUNT"
          value={currentData ? currentData.crowdCount.toString() : "0"}
          subtitle="people"
          icon="fas fa-users"
          iconClass="text-text-tertiary opacity-40"
        />
        
        <StatusCard 
          title="PREDICTION (20 MIN)"
          value={peakDensity.toFixed(2)}
          subtitle="peak density"
          icon="fas fa-chart-line"
          iconClass="text-warning opacity-40"
        />
        
        <StatusCard 
          title="PREDICTION ACCURACY"
          value={`${Math.round(avgConfidence * 100)}%`}
          subtitle="confidence level"
          icon="fas fa-check-circle"
          iconClass="text-accent opacity-40"
        />
      </div>

      {/* Density Chart */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-8">
        <h3 className="text-lg font-primary font-semibold mb-4">Crowd Density Prediction</h3>
        <div className="chart-container h-64 lg:h-80">
          <PredictionChart 
            predictionData={predictionData} 
            criticalThreshold={parseFloat(state.settings.critical_threshold)}
            highThreshold={parseFloat(state.settings.high_threshold)}
          />
        </div>
      </div>

      {/* Sensor Readings and Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Sensor Values */}
        <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
          <h3 className="text-lg font-primary font-semibold mb-4">Sensor Readings</h3>
          <div className="grid grid-cols-2 gap-4">
            <SensorCard 
              title="eCO2"
              value={currentData ? currentData.eco2.toString() : "0"}
              unit="ppm"
            />
            <SensorCard 
              title="TVOC"
              value={currentData ? currentData.tvoc.toString() : "0"}
              unit="ppb"
            />
            <SensorCard 
              title="EtOH"
              value={currentData ? currentData.etoh.toString() : "0"}
              unit="ppb"
            />
            <SensorCard 
              title="IAQ"
              value={currentData ? currentData.iaq.toString() : "0"}
              unit="index"
            />
          </div>
        </div>

        {/* Recent Alerts */}
        <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
          <h3 className="text-lg font-primary font-semibold mb-4">Recent Alerts</h3>
          <div className="space-y-3">
            {alertHistory && alertHistory.length > 0 ? (
              alertHistory.slice(0, 3).map((alert) => (
                <AlertItem key={alert.id} alert={alert} />
              ))
            ) : (
              <div className="text-text-tertiary text-center py-8">
                No alerts to display
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
