import React from 'react';
import { StatusIndicator } from '../ui/status-indicator';
import { getDensityStatus } from '../../lib/sensor-utils';

interface StatusCardProps {
  title: string;
  value: string;
  subtitle: string;
  status?: number;
  icon?: string;
  iconClass?: string;
  criticalThreshold?: number;
  highThreshold?: number;
}

const StatusCard: React.FC<StatusCardProps> = ({
  title,
  value,
  subtitle,
  status,
  icon,
  iconClass,
  criticalThreshold = 1.0,
  highThreshold = 0.7
}) => {
  // Determine status if provided
  let statusComponent = null;
  if (status !== undefined) {
    const statusInfo = getDensityStatus(status, criticalThreshold, highThreshold);
    statusComponent = (
      <StatusIndicator status={statusInfo.class.replace('status-', '') as any} label={statusInfo.text} />
    );
  }

  return (
    <div className="bg-gradient-primary rounded-lg p-6 card-border-top">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-sm font-primary text-text-secondary mb-1">{title}</h3>
          <div className="font-primary font-bold text-4xl">{value}</div>
          <div className="font-mono text-xs text-text-tertiary">{subtitle}</div>
        </div>
        {statusComponent ? (
          statusComponent
        ) : icon ? (
          <div className={iconClass || "text-text-tertiary opacity-40"}>
            <i className={`${icon} text-3xl`}></i>
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default StatusCard;
