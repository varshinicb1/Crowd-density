import React from 'react';

interface SensorCardProps {
  title: string;
  value: string;
  unit: string;
  subtitle?: string;
}

const SensorCard: React.FC<SensorCardProps> = ({ title, value, unit, subtitle }) => {
  return (
    <div className="bg-tertiary-bg rounded-lg p-4 text-center">
      <div className="text-xs font-primary text-text-secondary">{title}</div>
      <div className="font-mono text-2xl my-2">{value}</div>
      <div className="text-xs text-text-tertiary">{unit}</div>
      {subtitle && <div className="text-xs text-accent mt-2">{subtitle}</div>}
    </div>
  );
};

export default SensorCard;
