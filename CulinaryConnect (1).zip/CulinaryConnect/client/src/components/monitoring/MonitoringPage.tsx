import React, { useContext, useState, useEffect } from 'react';
import { AppContext } from '../../App';
import { StatusIndicator } from '../ui/status-indicator';
import SensorCard from '../dashboard/SensorCard';
import DensityChart from './DensityChart';
import SensorChart from './SensorChart';
import HistoryChart from './HistoryChart';
import AllSensorsChart from '../visualizations/AllSensorsChart';
import { getDensityStatus } from '../../lib/sensor-utils';
import { useQuery } from '@tanstack/react-query';
import { SensorData } from '@shared/schema';

const MonitoringPage: React.FC = () => {
  const { state, fetchSensorData, fetchHistoricalData } = useContext(AppContext);
  const { currentData, settings } = state;
  
  // State for historical period
  const [historyPeriod, setHistoryPeriod] = useState('day');
  // State for all-sensors chart time range
  const [timeRange, setTimeRange] = useState('3h');
  // State for prediction data
  const [predictionData, setPredictionData] = useState(null);

  // Fetch prediction data
  useEffect(() => {
    if (currentData) {
      // Fetch prediction data whenever current data changes
      fetch('/api/prediction/enhanced', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          currentReading: {
            eco2: currentData.eco2,
            tvoc: currentData.tvoc,
            etoh: currentData.etoh,
            iaq: currentData.iaq
          },
          minutesAhead: 30
        })
      })
      .then(res => res.json())
      .then(data => {
        setPredictionData(data);
      })
      .catch(err => {
        console.error("Error fetching prediction data:", err);
      });
    }
  }, [currentData]);
  
  // Get historical data for the selected time range
  const { data: historicalData } = useQuery({
    queryKey: ['/api/sensor/history', timeRange === '1h' ? '1' : 
                              timeRange === '3h' ? '3' : 
                              timeRange === '6h' ? '6' : 
                              timeRange === '12h' ? '12' : '24'],
  });
  
  // Get density status
  const densityStatus = currentData ? 
    getDensityStatus(
      parseFloat(currentData.density), 
      parseFloat(settings.critical_threshold), 
      parseFloat(settings.high_threshold)
    ) : 
    { class: 'status-low', text: 'Low' };
  
  // Handler for time range change
  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-wrap items-center justify-between mb-6">
        <h2 className="text-2xl font-primary font-semibold">Real-time Monitoring</h2>
        <div className="flex items-center space-x-3">
          <StatusIndicator 
            status={densityStatus.class.replace('status-', '') as any}
            label={densityStatus.text}
            id="monitoring-density-status"
          />
          <button 
            onClick={() => fetchSensorData()}
            className="bg-accent/10 hover:bg-accent/20 text-accent rounded-md px-4 py-2 flex items-center transition duration-300"
            id="monitoring-refresh-btn"
          >
            <i className="fas fa-sync-alt mr-2"></i>
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Sensor Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <SensorCard 
          title="eCO2"
          value={currentData ? currentData.eco2.toString() : "0"}
          unit="ppm"
          subtitle="Carbon Dioxide"
        />
        <SensorCard 
          title="TVOC"
          value={currentData ? currentData.tvoc.toString() : "0"}
          unit="ppb"
          subtitle="Volatile Compounds"
        />
        <SensorCard 
          title="EtOH"
          value={currentData ? currentData.etoh.toString() : "0"}
          unit="ppb"
          subtitle="Ethanol"
        />
        <SensorCard 
          title="IAQ"
          value={currentData ? currentData.iaq.toString() : "0"}
          unit="index"
          subtitle="Air Quality"
        />
      </div>

      {/* All Sensors Visualization Chart */}
      <div className="mb-6">
        <AllSensorsChart 
          currentData={currentData}
          historicalData={historicalData}
          predictionData={predictionData}
          timeRange={timeRange}
          onTimeRangeChange={handleTimeRangeChange}
        />
      </div>

      {/* Density Chart */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-primary font-semibold">Crowd Density Trend</h3>
          <div className="text-sm text-text-secondary">
            Current: <span className="font-mono font-semibold text-accent" id="density-value-monitoring">
              {currentData ? parseFloat(currentData.density).toFixed(2) : "0.00"}
            </span>
          </div>
        </div>
        <div className="chart-container h-64">
          <DensityChart 
            criticalThreshold={parseFloat(settings.critical_threshold)}
            highThreshold={parseFloat(settings.high_threshold)}
          />
        </div>
      </div>

      {/* Sensor Charts */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-primary font-semibold">Sensor Readings</h3>
          <div className="flex items-center">
            <span className="text-sm text-text-secondary mr-2">Time Period:</span>
            <select 
              id="sensor-time-period" 
              className="bg-tertiary-bg text-text-primary border border-white/10 rounded py-1 px-2 text-sm"
              defaultValue="day"
            >
              <option value="hour">Last Hour</option>
              <option value="day">Last Day</option>
              <option value="week">Last Week</option>
            </select>
          </div>
        </div>
        <div className="chart-container h-80">
          <SensorChart />
        </div>
      </div>

      {/* Historical Data */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-primary font-semibold">Historical Analysis</h3>
          <div className="flex items-center">
            <span className="text-sm text-text-secondary mr-2">Period:</span>
            <select 
              id="history-period" 
              className="bg-tertiary-bg text-text-primary border border-white/10 rounded py-1 px-2 text-sm"
              value={historyPeriod}
              onChange={(e) => setHistoryPeriod(e.target.value)}
            >
              <option value="day">Day</option>
              <option value="week">Week</option>
              <option value="month">Month</option>
            </select>
          </div>
        </div>
        <div className="chart-container h-80">
          <HistoryChart period={historyPeriod} />
        </div>
      </div>
    </div>
  );
};

export default MonitoringPage;
