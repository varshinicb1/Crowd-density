import React, { useEffect, useRef, useContext, useState } from 'react';
import { Chart } from 'chart.js';
import { AppContext } from '../../App';

interface HistoryChartProps {
  period: string;
}

const HistoryChart: React.FC<HistoryChartProps> = ({ period }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const { fetchHistoricalData } = useContext(AppContext);
  const [isLoading, setIsLoading] = useState(false);
  
  // Chart colors
  const chartColors = {
    primary: '#00E5FF',
    secondary: '#4E11A8',
    danger: '#FF5252',
    warning: '#FFD600',
    success: '#AEEA00',
    eco2: '#00E5FF',
    tvoc: '#FF5252',
    etoh: '#FFD600',
    iaq: '#AEEA00',
    grid: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.7)'
  };
  
  useEffect(() => {
    let isMounted = true;
    
    const loadHistoricalData = async () => {
      if (!chartRef.current) return;
      
      setIsLoading(true);
      try {
        const historyData = await fetchHistoricalData(period);
        
        if (!isMounted) return;
        
        const ctx = chartRef.current.getContext('2d');
        if (!ctx) return;
        
        // Destroy existing chart
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }
        
        // Format timestamps to readable labels
        const timeLabels = historyData.timestamps.map((timestamp: number) => {
          const date = new Date(timestamp);
          if (period === 'day') {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          } else if (period === 'week') {
            return date.toLocaleDateString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' });
          } else {
            return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
          }
        });
        
        // Create new chart
        chartInstance.current = new Chart(ctx, {
          type: 'line',
          data: {
            labels: timeLabels,
            datasets: [
              {
                label: 'Crowd Density',
                data: historyData.density,
                borderColor: chartColors.primary,
                backgroundColor: 'rgba(0, 229, 255, 0.1)',
                borderWidth: 2,
                pointRadius: 0,
                pointHoverRadius: 3,
                pointBackgroundColor: chartColors.primary,
                tension: 0.4,
                fill: true,
                yAxisID: 'y-density'
              },
              {
                label: 'Crowd Count',
                data: historyData.crowdCount,
                borderColor: chartColors.secondary,
                backgroundColor: 'rgba(78, 17, 168, 0.1)',
                borderWidth: 2,
                pointRadius: 0,
                pointHoverRadius: 3,
                pointBackgroundColor: chartColors.secondary,
                tension: 0.4,
                fill: false,
                yAxisID: 'y-count'
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
              mode: 'index',
              intersect: false
            },
            plugins: {
              legend: {
                position: 'top',
                labels: {
                  color: chartColors.text,
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  },
                  boxWidth: 12,
                  usePointStyle: true,
                  pointStyle: 'circle'
                }
              },
              tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: 'rgba(20, 20, 50, 0.9)',
                titleColor: '#FFFFFF',
                bodyColor: '#FFFFFF',
                borderColor: 'rgba(0, 229, 255, 0.3)',
                borderWidth: 1
              }
            },
            scales: {
              x: {
                grid: {
                  color: chartColors.grid
                },
                ticks: {
                  color: chartColors.text,
                  font: {
                    family: "'Share Tech Mono', monospace",
                    size: 10
                  },
                  maxRotation: 45,
                  minRotation: 45,
                  autoSkip: true,
                  maxTicksLimit: 15
                }
              },
              'y-density': {
                type: 'linear',
                display: true,
                position: 'left',
                title: {
                  display: true,
                  text: 'Crowd Density',
                  color: chartColors.primary,
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                },
                min: 0,
                max: 1.5,
                grid: {
                  color: chartColors.grid
                },
                ticks: {
                  color: chartColors.primary,
                  font: {
                    family: "'Share Tech Mono', monospace",
                    size: 10
                  },
                  callback: function(value) {
                    return value.toFixed(1);
                  }
                }
              },
              'y-count': {
                type: 'linear',
                display: true,
                position: 'right',
                title: {
                  display: true,
                  text: 'Crowd Count',
                  color: chartColors.secondary,
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                },
                min: 0,
                max: 500,
                grid: {
                  drawOnChartArea: false
                },
                ticks: {
                  color: chartColors.secondary,
                  font: {
                    family: "'Share Tech Mono', monospace",
                    size: 10
                  }
                }
              }
            }
          }
        });
      } catch (error) {
        console.error('Error loading historical data:', error);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };
    
    loadHistoricalData();
    
    return () => {
      isMounted = false;
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [period, fetchHistoricalData]);
  
  return (
    <>
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
          <div className="text-accent flex items-center">
            <i className="fas fa-circle-notch fa-spin mr-2"></i>
            <span>Loading historical data...</span>
          </div>
        </div>
      )}
      <canvas ref={chartRef}></canvas>
    </>
  );
};

export default HistoryChart;
