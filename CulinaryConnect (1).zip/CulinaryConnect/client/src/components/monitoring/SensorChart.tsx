import React, { useEffect, useRef, useContext } from 'react';
import { Chart } from 'chart.js';
import { AppContext } from '../../App';

const SensorChart: React.FC = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const { state } = useContext(AppContext);
  
  // Chart colors
  const chartColors = {
    eco2: '#00E5FF',
    tvoc: '#FF5252',
    etoh: '#FFD600',
    iaq: '#AEEA00',
    grid: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.7)'
  };
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Mock data for initial rendering
    // In a real app, we'd fetch historical sensor data
    const mockLabels = Array.from({length: 30}, (_, i) => `-${30-i} min`);
    mockLabels[mockLabels.length - 1] = 'Now';
    
    const mockEco2Data = Array.from({length: 30}, () => Math.random() * 600 + 700);
    const mockTvocData = Array.from({length: 30}, () => Math.random() * 200 + 200);
    const mockEtohData = Array.from({length: 30}, () => Math.random() * 100 + 100);
    const mockIaqData = Array.from({length: 30}, () => Math.random() * 50 + 50);
    
    if (state.currentData) {
      mockEco2Data[mockEco2Data.length - 1] = state.currentData.eco2;
      mockTvocData[mockTvocData.length - 1] = state.currentData.tvoc;
      mockEtohData[mockEtohData.length - 1] = state.currentData.etoh;
      mockIaqData[mockIaqData.length - 1] = state.currentData.iaq;
    }
    
    // Create new chart
    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: mockLabels,
        datasets: [
          {
            label: 'eCO2 (ppm)',
            data: mockEco2Data,
            borderColor: chartColors.eco2,
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointRadius: 2,
            pointBackgroundColor: chartColors.eco2,
            tension: 0.4,
            yAxisID: 'y'
          },
          {
            label: 'TVOC (ppb)',
            data: mockTvocData,
            borderColor: chartColors.tvoc,
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointRadius: 2,
            pointBackgroundColor: chartColors.tvoc,
            tension: 0.4,
            yAxisID: 'y1'
          },
          {
            label: 'EtOH (ppb)',
            data: mockEtohData,
            borderColor: chartColors.etoh,
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointRadius: 2,
            pointBackgroundColor: chartColors.etoh,
            tension: 0.4,
            yAxisID: 'y1'
          },
          {
            label: 'IAQ (index)',
            data: mockIaqData,
            borderColor: chartColors.iaq,
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointRadius: 2,
            pointBackgroundColor: chartColors.iaq,
            tension: 0.4,
            yAxisID: 'y2'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              color: chartColors.text,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              },
              boxWidth: 12,
              usePointStyle: true,
              pointStyle: 'circle'
            }
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(20, 20, 50, 0.9)',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            borderColor: 'rgba(0, 229, 255, 0.3)',
            borderWidth: 1
          }
        },
        scales: {
          x: {
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.text,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'eCO2 (ppm)',
              color: chartColors.eco2,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              }
            },
            min: 400,
            max: 2000,
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.eco2,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'TVOC/EtOH (ppb)',
              color: chartColors.tvoc,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              }
            },
            min: 0,
            max: 1000,
            grid: {
              drawOnChartArea: false
            },
            ticks: {
              color: chartColors.tvoc,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          },
          y2: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'IAQ Index',
              color: chartColors.iaq,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              }
            },
            min: 0,
            max: 500,
            grid: {
              drawOnChartArea: false
            },
            ticks: {
              color: chartColors.iaq,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          }
        }
      }
    });
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [state.currentData]);
  
  return <canvas ref={chartRef}></canvas>;
};

export default SensorChart;
