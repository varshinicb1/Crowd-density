import React, { useEffect, useRef, useContext } from 'react';
import { Chart } from 'chart.js';
import { AppContext } from '../../App';

interface DensityChartProps {
  criticalThreshold: number;
  highThreshold: number;
}

const DensityChart: React.FC<DensityChartProps> = ({ criticalThreshold, highThreshold }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const { state } = useContext(AppContext);
  
  // Chart colors
  const chartColors = {
    primary: '#00E5FF',
    secondary: '#4E11A8',
    danger: '#FF5252',
    warning: '#FFD600',
    success: '#AEEA00',
    grid: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.7)'
  };
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Mock data for initial rendering
    // In a real app, we'd fetch historical density data
    const mockLabels = Array.from({length: 30}, (_, i) => `-${30-i} min`);
    mockLabels[mockLabels.length - 1] = 'Now';
    
    const mockData = Array.from({length: 30}, () => Math.random() * 0.6 + 0.2);
    if (state.currentData) {
      mockData[mockData.length - 1] = parseFloat(state.currentData.density);
    }
    
    // Create new chart
    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: mockLabels,
        datasets: [{
          label: 'Crowd Density',
          data: mockData,
          borderColor: chartColors.primary,
          backgroundColor: 'rgba(0, 229, 255, 0.1)',
          borderWidth: 2,
          pointRadius: 3,
          pointBackgroundColor: chartColors.primary,
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(20, 20, 50, 0.9)',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            borderColor: 'rgba(0, 229, 255, 0.3)',
            borderWidth: 1,
            callbacks: {
              label: function(context) {
                return `Density: ${context.parsed.y.toFixed(2)}`;
              }
            }
          },
          annotation: {
            annotations: {
              criticalLine: {
                type: 'line',
                yMin: criticalThreshold,
                yMax: criticalThreshold,
                borderColor: chartColors.danger,
                borderWidth: 2,
                borderDash: [5, 5],
                label: {
                  display: true,
                  content: 'Critical',
                  position: 'end',
                  backgroundColor: 'rgba(255, 82, 82, 0.8)',
                  color: '#FFFFFF',
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                }
              },
              highLine: {
                type: 'line',
                yMin: highThreshold,
                yMax: highThreshold,
                borderColor: chartColors.warning,
                borderWidth: 2,
                borderDash: [5, 5],
                label: {
                  display: true,
                  content: 'High',
                  position: 'end',
                  backgroundColor: 'rgba(255, 214, 0, 0.8)',
                  color: '#FFFFFF',
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                }
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.text,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          },
          y: {
            beginAtZero: true,
            max: 1.5,
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.text,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              },
              callback: function(value) {
                return value.toFixed(1);
              }
            }
          }
        }
      }
    });
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [state.currentData, criticalThreshold, highThreshold]);
  
  // Update chart when current data changes
  useEffect(() => {
    if (chartInstance.current && state.currentData) {
      const currentDensity = parseFloat(state.currentData.density);
      
      // Add current density to the end of the dataset
      const data = chartInstance.current.data.datasets[0].data;
      data.push(currentDensity);
      if (data.length > 31) { // Keep only last 31 points
        data.shift();
      }
      
      chartInstance.current.update();
    }
  }, [state.currentData]);
  
  return <canvas ref={chartRef}></canvas>;
};

export default DensityChart;
