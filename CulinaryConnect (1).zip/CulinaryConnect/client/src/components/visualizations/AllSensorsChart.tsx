import React, { useEffect, useRef, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  TimeScale,
  ChartData,
  ChartOptions
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import 'chartjs-adapter-date-fns';
import { SensorData } from '@shared/schema';
import { formatInTimeZone } from 'date-fns-tz';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  TimeScale,
  Title,
  Tooltip,
  Legend
);

// Interface for prediction data
interface PredictionData {
  timestamps: number[];
  density: number[];
  crowdCount: number[];
  confidence: number[];
}

// Props for the AllSensorsChart component
interface AllSensorsChartProps {
  currentData: SensorData | null;
  historicalData?: SensorData[] | unknown;
  predictionData?: PredictionData | null;
  timeRange?: string;
  onTimeRangeChange?: (range: string) => void;
}

// Color scheme for chart lines
const CHART_COLORS = {
  eco2: {
    line: 'rgba(255, 99, 132, 1)',
    fill: 'rgba(255, 99, 132, 0.2)'
  },
  tvoc: {
    line: 'rgba(54, 162, 235, 1)',
    fill: 'rgba(54, 162, 235, 0.2)'
  },
  etoh: {
    line: 'rgba(255, 206, 86, 1)',
    fill: 'rgba(255, 206, 86, 0.2)'
  },
  iaq: {
    line: 'rgba(75, 192, 192, 1)',
    fill: 'rgba(75, 192, 192, 0.2)'
  },
  density: {
    line: 'rgba(153, 102, 255, 1)',
    fill: 'rgba(153, 102, 255, 0.2)'
  },
  prediction: {
    line: 'rgba(255, 159, 64, 1)',
    fill: 'rgba(255, 159, 64, 0.2)'
  }
};

// Format timestamp in IST
const formatIST = (date: Date): string => {
  return formatInTimeZone(date, 'Asia/Kolkata', 'MMM dd, yyyy HH:mm:ss');
};

/**
 * AllSensorsChart Component
 * Displays all sensor parameters in a single view with prediction curves
 */
export const AllSensorsChart: React.FC<AllSensorsChartProps> = ({
  currentData,
  historicalData = [],
  predictionData = null,
  timeRange = '1h',
  onTimeRangeChange = () => {}
}) => {
  // Query to get historical sensor data
  const { data: historyData } = useQuery<SensorData[]>({ 
    queryKey: ['/api/sensor/history', timeRange],
    enabled: !historicalData?.length,
  });

  // Combine provided historical data or data from query
  const allHistoricalData = (historicalData && historicalData.length > 0) 
    ? historicalData 
    : (Array.isArray(historyData) ? historyData : []);
  
  // Chart options with shared configuration
  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        type: 'time',
        time: {
          unit: timeRange === '24h' ? 'hour' : 'minute',
          displayFormats: {
            minute: 'HH:mm',
            hour: 'HH:mm'
          },
          tooltipFormat: 'yyyy-MM-dd HH:mm'
        },
        title: {
          display: true,
          text: 'Time (IST)'
        }
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Value'
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          title: (items) => {
            // Display timestamp in IST
            if (!items.length) return '';
            const timestamp = new Date(items[0].parsed.x);
            return formatIST(timestamp);
          }
        }
      },
      legend: {
        position: 'top' as const,
      },
    },
  };

  // Function to prepare data for combined chart
  const prepareCombinedData = (): ChartData<'line'> => {
    // Make sure there's data to process
    if (!allHistoricalData || allHistoricalData.length === 0) {
      return {
        labels: [],
        datasets: []
      };
    }
    
    // Sort data by timestamp
    const sortedData = [...allHistoricalData].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    // Extract timestamps and values
    const timestamps = sortedData.map(d => new Date(d.timestamp).getTime());
    const eco2Values = sortedData.map(d => d.eco2);
    const tvocValues = sortedData.map(d => d.tvoc);
    const etohValues = sortedData.map(d => d.etoh);
    const iaqValues = sortedData.map(d => d.iaq);
    const densityValues = sortedData.map(d => parseFloat(d.density));
    
    // Add prediction data if available
    let predictionTimestamps: number[] = [];
    let predictionDensity: number[] = [];
    
    if (predictionData && predictionData.timestamps.length > 0) {
      predictionTimestamps = predictionData.timestamps;
      predictionDensity = predictionData.density;
    }
    
    // Create datasets for each sensor parameter
    return {
      labels: timestamps,
      datasets: [
        {
          label: 'eCO₂ (ppm)',
          data: timestamps.map((t, i) => ({ x: t, y: eco2Values[i] })),
          borderColor: CHART_COLORS.eco2.line,
          backgroundColor: CHART_COLORS.eco2.fill,
          yAxisID: 'y',
          borderWidth: 2,
          tension: 0.3,
          hidden: false
        },
        {
          label: 'TVOC (ppb)',
          data: timestamps.map((t, i) => ({ x: t, y: tvocValues[i] })),
          borderColor: CHART_COLORS.tvoc.line,
          backgroundColor: CHART_COLORS.tvoc.fill,
          yAxisID: 'y',
          borderWidth: 2,
          tension: 0.3,
          hidden: true // Hidden by default due to different scale
        },
        {
          label: 'EtOH (ppb)',
          data: timestamps.map((t, i) => ({ x: t, y: etohValues[i] })),
          borderColor: CHART_COLORS.etoh.line,
          backgroundColor: CHART_COLORS.etoh.fill,
          yAxisID: 'y',
          borderWidth: 2,
          tension: 0.3,
          hidden: true // Hidden by default due to different scale
        },
        {
          label: 'IAQ',
          data: timestamps.map((t, i) => ({ x: t, y: iaqValues[i] })),
          borderColor: CHART_COLORS.iaq.line,
          backgroundColor: CHART_COLORS.iaq.fill,
          yAxisID: 'y',
          borderWidth: 2,
          tension: 0.3,
          hidden: true // Hidden by default due to different scale
        },
        {
          label: 'Density',
          data: timestamps.map((t, i) => ({ x: t, y: densityValues[i] })),
          borderColor: CHART_COLORS.density.line,
          backgroundColor: CHART_COLORS.density.fill,
          yAxisID: 'y',
          borderWidth: 3,
          tension: 0.3,
          hidden: false
        },
        {
          label: 'Predicted Density',
          data: predictionTimestamps.map((t, i) => ({ x: t, y: predictionDensity[i] })),
          borderColor: CHART_COLORS.prediction.line,
          backgroundColor: CHART_COLORS.prediction.fill,
          borderDash: [5, 5],
          yAxisID: 'y',
          borderWidth: 2,
          tension: 0.3,
          hidden: false
        }
      ]
    };
  };

  // Function to prepare normalized data chart
  const prepareNormalizedData = (): ChartData<'line'> => {
    // Make sure there's data to process
    if (!allHistoricalData || allHistoricalData.length === 0) {
      return {
        labels: [],
        datasets: []
      };
    }
    
    // Sort data by timestamp
    const sortedData = [...allHistoricalData].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    // Extract timestamps
    const timestamps = sortedData.map(d => new Date(d.timestamp).getTime());
    
    // Normalize all values to 0-1 scale for comparison
    const eco2Max = Math.max(...sortedData.map(d => d.eco2), 1000);
    const tvocMax = Math.max(...sortedData.map(d => d.tvoc), 500);
    const etohMax = Math.max(...sortedData.map(d => d.etoh), 500);
    const iaqMax = Math.max(...sortedData.map(d => d.iaq), 200);
    
    const normalizedEco2 = sortedData.map(d => d.eco2 / eco2Max);
    const normalizedTvoc = sortedData.map(d => d.tvoc / tvocMax);
    const normalizedEtoh = sortedData.map(d => d.etoh / etohMax);
    const normalizedIaq = sortedData.map(d => d.iaq / iaqMax);
    const densityValues = sortedData.map(d => parseFloat(d.density));
    
    // Add prediction data if available
    let predictionTimestamps: number[] = [];
    let predictionDensity: number[] = [];
    
    if (predictionData && predictionData.timestamps.length > 0) {
      predictionTimestamps = predictionData.timestamps;
      predictionDensity = predictionData.density;
    }
    
    return {
      labels: timestamps,
      datasets: [
        {
          label: 'Normalized eCO₂',
          data: timestamps.map((t, i) => ({ x: t, y: normalizedEco2[i] })),
          borderColor: CHART_COLORS.eco2.line,
          backgroundColor: CHART_COLORS.eco2.fill,
          borderWidth: 2,
          tension: 0.3
        },
        {
          label: 'Normalized TVOC',
          data: timestamps.map((t, i) => ({ x: t, y: normalizedTvoc[i] })),
          borderColor: CHART_COLORS.tvoc.line,
          backgroundColor: CHART_COLORS.tvoc.fill,
          borderWidth: 2,
          tension: 0.3
        },
        {
          label: 'Normalized EtOH',
          data: timestamps.map((t, i) => ({ x: t, y: normalizedEtoh[i] })),
          borderColor: CHART_COLORS.etoh.line,
          backgroundColor: CHART_COLORS.etoh.fill,
          borderWidth: 2,
          tension: 0.3
        },
        {
          label: 'Normalized IAQ',
          data: timestamps.map((t, i) => ({ x: t, y: normalizedIaq[i] })),
          borderColor: CHART_COLORS.iaq.line,
          backgroundColor: CHART_COLORS.iaq.fill,
          borderWidth: 2,
          tension: 0.3
        },
        {
          label: 'Density',
          data: timestamps.map((t, i) => ({ x: t, y: densityValues[i] })),
          borderColor: CHART_COLORS.density.line,
          backgroundColor: CHART_COLORS.density.fill,
          borderWidth: 3,
          tension: 0.3
        },
        {
          label: 'Predicted Density',
          data: predictionTimestamps.map((t, i) => ({ x: t, y: predictionDensity[i] })),
          borderColor: CHART_COLORS.prediction.line,
          backgroundColor: CHART_COLORS.prediction.fill,
          borderDash: [5, 5],
          borderWidth: 2,
          tension: 0.3
        }
      ]
    };
  };

  // Function to prepare density-focused chart
  const prepareDensityChart = (): ChartData<'line'> => {
    // Make sure there's data to process
    if (!allHistoricalData || allHistoricalData.length === 0) {
      return {
        labels: [],
        datasets: []
      };
    }
    
    // Sort data by timestamp
    const sortedData = [...allHistoricalData].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    // Extract timestamps
    const timestamps = sortedData.map(d => new Date(d.timestamp).getTime());
    const densityValues = sortedData.map(d => parseFloat(d.density));
    const crowdCountValues = sortedData.map(d => d.crowdCount);
    
    // Add prediction data if available
    let predictionTimestamps: number[] = [];
    let predictionDensity: number[] = [];
    let predictionCrowdCount: number[] = [];
    let confidenceValues: number[] = [];
    
    if (predictionData && predictionData.timestamps.length > 0) {
      predictionTimestamps = predictionData.timestamps;
      predictionDensity = predictionData.density;
      predictionCrowdCount = predictionData.crowdCount;
      confidenceValues = predictionData.confidence;
    }
    
    return {
      labels: timestamps,
      datasets: [
        {
          label: 'Crowd Density',
          data: timestamps.map((t, i) => ({ x: t, y: densityValues[i] })),
          borderColor: CHART_COLORS.density.line,
          backgroundColor: CHART_COLORS.density.fill,
          borderWidth: 3,
          tension: 0.3
        },
        {
          label: 'Predicted Density',
          data: predictionTimestamps.map((t, i) => ({ x: t, y: predictionDensity[i] })),
          borderColor: CHART_COLORS.prediction.line,
          backgroundColor: CHART_COLORS.prediction.fill,
          borderDash: [5, 5],
          borderWidth: 2,
          tension: 0.3
        }
      ]
    };
  };

  // Render different chart views based on tabs
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Sensor Data & Prediction Visualization</CardTitle>
          <Select value={timeRange} onValueChange={onTimeRangeChange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Last Hour</SelectItem>
              <SelectItem value="3h">Last 3 Hours</SelectItem>
              <SelectItem value="6h">Last 6 Hours</SelectItem>
              <SelectItem value="12h">Last 12 Hours</SelectItem>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <CardDescription>
          View all sensor parameters and predictions in one place
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="combined" className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="combined">Combined View</TabsTrigger>
            <TabsTrigger value="normalized">Normalized View</TabsTrigger>
            <TabsTrigger value="density">Density Prediction</TabsTrigger>
          </TabsList>
          
          <TabsContent value="combined" className="w-full">
            <div className="h-[350px]">
              <Line 
                data={prepareCombinedData()} 
                options={options} 
                height="100%" 
              />
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              <p>Note: Some parameters are hidden by default due to different scales. Click legend items to toggle visibility.</p>
            </div>
          </TabsContent>
          
          <TabsContent value="normalized" className="w-full">
            <div className="h-[350px]">
              <Line 
                data={prepareNormalizedData()} 
                options={{
                  ...options,
                  scales: {
                    ...options.scales,
                    y: {
                      beginAtZero: true,
                      max: 1.5,
                      title: {
                        display: true,
                        text: 'Normalized Value (0-1)'
                      }
                    }
                  }
                }} 
                height="100%" 
              />
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              <p>Note: All sensor values are normalized to 0-1 scale for comparative analysis.</p>
            </div>
          </TabsContent>
          
          <TabsContent value="density" className="w-full">
            <div className="h-[350px]">
              <Line 
                data={prepareDensityChart()} 
                options={{
                  ...options,
                  scales: {
                    ...options.scales,
                    y: {
                      beginAtZero: true,
                      max: 1.5,
                      title: {
                        display: true,
                        text: 'Crowd Density'
                      }
                    }
                  }
                }} 
                height="100%" 
              />
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              <p>Note: This view focuses on crowd density with prediction curve and threshold indicators.</p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AllSensorsChart;