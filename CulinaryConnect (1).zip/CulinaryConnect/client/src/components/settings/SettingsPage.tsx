import React, { useContext, useState } from 'react';
import { AppContext } from '../../App';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

const SettingsPage: React.FC = () => {
  const { state, setState } = useContext(AppContext);
  const { settings } = state;
  const { toast } = useToast();

  // State for settings tabs
  const [activeTab, setActiveTab] = useState('thresholds');
  
  // State for form values
  const [formValues, setFormValues] = useState({
    critical_threshold: settings.critical_threshold,
    high_threshold: settings.high_threshold,
    medium_threshold: settings.medium_threshold || "0.3",
    low_threshold: settings.low_threshold || "0.1",
    enable_sound: settings.enable_sound,
    enable_browser: settings.enable_browser,
    enable_email: settings.enable_email,
    email_address: settings.email_address || '',
    enable_sms: settings.enable_sms || false,
    phone_number: settings.phone_number || '',
    sms_critical: settings.sms_critical !== undefined ? settings.sms_critical : true,
    sms_high: settings.sms_high !== undefined ? settings.sms_high : true,
    sms_medium: settings.sms_medium !== undefined ? settings.sms_medium : false,
    sms_low: settings.sms_low !== undefined ? settings.sms_low : false,
    refresh_interval: settings.refresh_interval,
    prediction_interval: settings.prediction_interval,
    adafruit_username: settings.adafruit_username,
    adafruit_key: settings.adafruit_key,
    eco2_feed: settings.eco2_feed,
    tvoc_feed: settings.tvoc_feed,
    etoh_feed: settings.etoh_feed,
    iaq_feed: settings.iaq_feed,
    // Sensor weights (not stored in settings currently)
    eco2_weight: 40,
    tvoc_weight: 30,
    etoh_weight: 20,
    iaq_weight: 10
  });
  
  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    setFormValues({
      ...formValues,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    });
  };
  
  // Save alert threshold settings
  const saveAlertSettings = async () => {
    try {
      const response = await apiRequest('POST', '/api/settings', {
        critical_threshold: formValues.critical_threshold,
        high_threshold: formValues.high_threshold
      });
      
      if (response.ok) {
        const updatedSettings = await response.json();
        setState(prev => ({
          ...prev,
          settings: {
            ...prev.settings,
            critical_threshold: updatedSettings.critical_threshold,
            high_threshold: updatedSettings.high_threshold
          }
        }));
        
        toast({
          title: "Settings Updated",
          description: "Alert thresholds have been saved successfully."
        });
      }
    } catch (error) {
      console.error('Error saving alert settings:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save alert settings."
      });
    }
  };
  
  // Save sensor weights
  const saveSensorWeights = async () => {
    // In a full implementation, this would save to the server
    toast({
      title: "Weights Updated",
      description: "Sensor weights have been updated successfully."
    });
  };
  
  // Save notification settings
  const saveNotificationSettings = async () => {
    try {
      const response = await apiRequest('POST', '/api/settings', {
        enable_sound: formValues.enable_sound,
        enable_browser: formValues.enable_browser,
        enable_email: formValues.enable_email,
        email_address: formValues.email_address,
        enable_sms: formValues.enable_sms,
        phone_number: formValues.phone_number,
        sms_critical: formValues.sms_critical,
        sms_high: formValues.sms_high,
        sms_medium: formValues.sms_medium,
        sms_low: formValues.sms_low
      });
      
      if (response.ok) {
        const updatedSettings = await response.json();
        setState(prev => ({
          ...prev,
          settings: {
            ...prev.settings,
            enable_sound: updatedSettings.enable_sound,
            enable_browser: updatedSettings.enable_browser,
            enable_email: updatedSettings.enable_email,
            email_address: updatedSettings.email_address,
            enable_sms: updatedSettings.enable_sms,
            phone_number: updatedSettings.phone_number,
            sms_critical: updatedSettings.sms_critical,
            sms_high: updatedSettings.sms_high,
            sms_medium: updatedSettings.sms_medium,
            sms_low: updatedSettings.sms_low
          }
        }));
        
        toast({
          title: "Settings Updated",
          description: "Notification settings have been saved successfully."
        });
        
        // Request notification permission if browser notifications are enabled
        if (formValues.enable_browser && "Notification" in window) {
          Notification.requestPermission();
        }
        
        // Test SMS if it's enabled
        if (formValues.enable_sms && formValues.phone_number) {
          toast({
            title: "SMS Notification",
            description: "SMS notifications have been configured. A test message will be sent for verification."
          });
          
          // Send a test SMS
          try {
            const testResponse = await apiRequest('POST', '/api/notifications/sms', {
              phoneNumber: formValues.phone_number,
              alert: {
                alertType: 'test',
                message: 'This is a test SMS from your Crowd Monitoring System',
                details: { 
                  timestamp: new Date(), 
                  density: 0.5,
                  crowdCount: 175
                },
                timestamp: new Date()
              }
            });
            
            if (testResponse.ok) {
              toast({
                title: "SMS Test",
                description: "Test SMS has been sent successfully!"
              });
            }
          } catch (smsError) {
            console.error('Error sending test SMS:', smsError);
          }
        }
      }
    } catch (error) {
      console.error('Error saving notification settings:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save notification settings."
      });
    }
  };
  
  // Save Adafruit IO settings
  const saveAdafruitSettings = async () => {
    try {
      const response = await apiRequest('POST', '/api/settings', {
        adafruit_username: formValues.adafruit_username,
        adafruit_key: formValues.adafruit_key,
        eco2_feed: formValues.eco2_feed,
        tvoc_feed: formValues.tvoc_feed,
        etoh_feed: formValues.etoh_feed,
        iaq_feed: formValues.iaq_feed
      });
      
      if (response.ok) {
        const updatedSettings = await response.json();
        setState(prev => ({
          ...prev,
          settings: {
            ...prev.settings,
            adafruit_username: updatedSettings.adafruit_username,
            adafruit_key: updatedSettings.adafruit_key,
            eco2_feed: updatedSettings.eco2_feed,
            tvoc_feed: updatedSettings.tvoc_feed,
            etoh_feed: updatedSettings.etoh_feed,
            iaq_feed: updatedSettings.iaq_feed
          }
        }));
        
        toast({
          title: "Settings Updated",
          description: "Adafruit IO settings have been saved successfully."
        });
      }
    } catch (error) {
      console.error('Error saving Adafruit IO settings:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save Adafruit IO settings."
      });
    }
  };
  
  // Test Adafruit IO connection
  const testConnection = async () => {
    try {
      toast({
        title: "Testing Connection",
        description: "Attempting to connect to Adafruit IO..."
      });
      
      const response = await apiRequest('POST', '/api/adafruit/test', {
        username: formValues.adafruit_username,
        key: formValues.adafruit_key
      });
      
      if (response.ok) {
        toast({
          title: "Connection Successful",
          description: "Successfully connected to Adafruit IO."
        });
      } else {
        const data = await response.json();
        toast({
          variant: "destructive",
          title: "Connection Failed",
          description: data.message || "Failed to connect to Adafruit IO."
        });
      }
    } catch (error) {
      console.error('Error testing Adafruit IO connection:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "An error occurred while testing the connection."
      });
    }
  };
  
  // Save application settings
  const saveAppSettings = async () => {
    try {
      const response = await apiRequest('POST', '/api/settings', {
        refresh_interval: parseInt(formValues.refresh_interval.toString()),
        prediction_interval: parseInt(formValues.prediction_interval.toString())
      });
      
      if (response.ok) {
        const updatedSettings = await response.json();
        setState(prev => ({
          ...prev,
          settings: {
            ...prev.settings,
            refresh_interval: updatedSettings.refresh_interval,
            prediction_interval: updatedSettings.prediction_interval
          }
        }));
        
        toast({
          title: "Settings Updated",
          description: "Application settings have been saved successfully."
        });
      }
    } catch (error) {
      console.error('Error saving app settings:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save application settings."
      });
    }
  };
  
  // Reset settings to defaults
  const resetSettings = () => {
    const defaultSettings = {
      critical_threshold: "1.0",
      high_threshold: "0.7",
      medium_threshold: "0.3",
      low_threshold: "0.1",
      enable_sound: true,
      enable_browser: true,
      enable_email: false,
      email_address: '',
      enable_sms: false,
      phone_number: '',
      sms_critical: true,
      sms_high: true,
      sms_medium: false,
      sms_low: false,
      refresh_interval: 30,
      prediction_interval: 300,
      adafruit_username: "varshinicb99",
      adafruit_key: "aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe",
      eco2_feed: "eco2",
      tvoc_feed: "tvoc",
      etoh_feed: "etoh",
      iaq_feed: "indoor-aqi",
      eco2_weight: 40,
      tvoc_weight: 30,
      etoh_weight: 20,
      iaq_weight: 10
    };
    
    setFormValues(defaultSettings);
    
    toast({
      title: "Settings Reset",
      description: "All settings have been reset to default values. Click save to apply."
    });
  };
  
  return (
    <div className="p-6">
      <h2 className="text-2xl font-primary font-semibold mb-6">System Settings</h2>

      {/* Settings Tabs */}
      <div className="mb-6 border-b border-white/10">
        <div className="flex overflow-x-auto">
          <button 
            className={`px-4 py-2 font-primary ${activeTab === 'thresholds' ? 'text-accent border-b-2 border-accent' : 'text-text-secondary border-b-2 border-transparent'}`}
            onClick={() => setActiveTab('thresholds')}
          >
            Alert Thresholds
          </button>
          <button 
            className={`px-4 py-2 font-primary ${activeTab === 'notifications' ? 'text-accent border-b-2 border-accent' : 'text-text-secondary border-b-2 border-transparent'}`}
            onClick={() => setActiveTab('notifications')}
          >
            Notifications
          </button>
          <button 
            className={`px-4 py-2 font-primary ${activeTab === 'adafruit' ? 'text-accent border-b-2 border-accent' : 'text-text-secondary border-b-2 border-transparent'}`}
            onClick={() => setActiveTab('adafruit')}
          >
            Adafruit IO
          </button>
          <button 
            className={`px-4 py-2 font-primary ${activeTab === 'application' ? 'text-accent border-b-2 border-accent' : 'text-text-secondary border-b-2 border-transparent'}`}
            onClick={() => setActiveTab('application')}
          >
            Application
          </button>
        </div>
      </div>

      {/* Alert Thresholds Settings */}
      {activeTab === 'thresholds' && (
        <div className="settings-panel active">
          <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
            <h3 className="text-lg font-primary font-semibold mb-4">Crowd Density Thresholds</h3>
            <div className="space-y-6">
              {/* Critical Threshold */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-text-secondary">Critical Threshold</label>
                  <span className="text-danger font-mono" id="critical-threshold-value">
                    {formValues.critical_threshold}
                  </span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">0.7</span>
                  <input 
                    type="range" 
                    id="critical-threshold"
                    name="critical_threshold"
                    min="0.7" 
                    max="1.5" 
                    step="0.01" 
                    value={formValues.critical_threshold} 
                    onChange={handleChange}
                    className="flex-1 accent-danger h-2 bg-tertiary-bg rounded-full appearance-none"
                  />
                  <span className="text-xs text-text-tertiary ml-3">1.5</span>
                </div>
                <p className="text-xs text-text-tertiary mt-2">Critical alerts will be triggered when density exceeds this value</p>
              </div>

              {/* High Threshold */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-text-secondary">High Threshold</label>
                  <span className="text-warning font-mono" id="high-threshold-value">
                    {formValues.high_threshold}
                  </span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">0.3</span>
                  <input 
                    type="range" 
                    id="high-threshold"
                    name="high_threshold"
                    min="0.3" 
                    max="1.0" 
                    step="0.01" 
                    value={formValues.high_threshold} 
                    onChange={handleChange}
                    className="flex-1 accent-warning h-2 bg-tertiary-bg rounded-full appearance-none"
                  />
                  <span className="text-xs text-text-tertiary ml-3">1.0</span>
                </div>
                <p className="text-xs text-text-tertiary mt-2">Warning alerts will be triggered when density exceeds this value</p>
              </div>

              {/* Medium Threshold */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-text-secondary">Medium Threshold</label>
                  <span className="text-success font-mono">0.30</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">0.1</span>
                  <input 
                    type="range" 
                    min="0.1" 
                    max="0.5" 
                    step="0.01" 
                    value="0.3" 
                    className="flex-1 accent-success h-2 bg-tertiary-bg rounded-full appearance-none" 
                    disabled
                  />
                  <span className="text-xs text-text-tertiary ml-3">0.5</span>
                </div>
                <p className="text-xs text-text-tertiary mt-2">Density values above this are classified as medium</p>
              </div>
            </div>
            <button 
              id="save-alert-settings" 
              className="mt-6 bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md px-6 py-2.5 transition duration-300"
              onClick={saveAlertSettings}
            >
              Save Threshold Settings
            </button>
          </div>

          {/* Sensor Weights */}
          <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
            <h3 className="text-lg font-primary font-semibold mb-4">Sensor Weight Configuration</h3>
            <p className="text-text-secondary mb-4">Configure how much each sensor contributes to the overall density calculation.</p>
            <div className="space-y-4">
              {/* eCO2 Weight */}
              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-text-secondary">eCO2 Weight</label>
                  <span className="text-accent font-mono">{formValues.eco2_weight}%</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">10%</span>
                  <input 
                    type="range" 
                    name="eco2_weight"
                    min="10" 
                    max="60" 
                    step="5" 
                    value={formValues.eco2_weight} 
                    onChange={handleChange}
                    className="flex-1 accent-accent h-2 bg-tertiary-bg rounded-full appearance-none"
                  />
                  <span className="text-xs text-text-tertiary ml-3">60%</span>
                </div>
              </div>

              {/* TVOC Weight */}
              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-text-secondary">TVOC Weight</label>
                  <span className="text-danger font-mono">{formValues.tvoc_weight}%</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">10%</span>
                  <input 
                    type="range"
                    name="tvoc_weight"
                    min="10" 
                    max="60" 
                    step="5" 
                    value={formValues.tvoc_weight} 
                    onChange={handleChange}
                    className="flex-1 accent-danger h-2 bg-tertiary-bg rounded-full appearance-none"
                  />
                  <span className="text-xs text-text-tertiary ml-3">60%</span>
                </div>
              </div>

              {/* EtOH Weight */}
              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-text-secondary">EtOH Weight</label>
                  <span className="text-warning font-mono">{formValues.etoh_weight}%</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">5%</span>
                  <input 
                    type="range"
                    name="etoh_weight"
                    min="5" 
                    max="40" 
                    step="5" 
                    value={formValues.etoh_weight} 
                    onChange={handleChange}
                    className="flex-1 accent-warning h-2 bg-tertiary-bg rounded-full appearance-none"
                  />
                  <span className="text-xs text-text-tertiary ml-3">40%</span>
                </div>
              </div>

              {/* IAQ Weight */}
              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-text-secondary">IAQ Weight</label>
                  <span className="text-success font-mono">{formValues.iaq_weight}%</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-text-tertiary mr-3">5%</span>
                  <input 
                    type="range"
                    name="iaq_weight"
                    min="5" 
                    max="30" 
                    step="5" 
                    value={formValues.iaq_weight} 
                    onChange={handleChange}
                    className="flex-1 accent-success h-2 bg-tertiary-bg rounded-full appearance-none"
                  />
                  <span className="text-xs text-text-tertiary ml-3">30%</span>
                </div>
              </div>

              <div className="text-xs text-text-tertiary mt-2">
                Total weight: {parseInt(formValues.eco2_weight.toString()) + 
                parseInt(formValues.tvoc_weight.toString()) + 
                parseInt(formValues.etoh_weight.toString()) + 
                parseInt(formValues.iaq_weight.toString())}% 
                (should equal 100%)
              </div>
            </div>
            <button 
              id="save-sensor-weights" 
              className="mt-6 bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md px-6 py-2.5 transition duration-300"
              onClick={saveSensorWeights}
            >
              Save Weight Configuration
            </button>
          </div>
        </div>
      )}

      {/* Notifications Settings */}
      {activeTab === 'notifications' && (
        <div className="settings-panel">
          <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
            <h3 className="text-lg font-primary font-semibold mb-4">Notification Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-tertiary-bg p-4 rounded-lg">
                <div>
                  <h4 className="font-primary font-medium">Browser Notifications</h4>
                  <p className="text-sm text-text-tertiary mt-1">Receive alerts as browser notifications</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    name="enable_browser"
                    checked={formValues.enable_browser}
                    onChange={handleChange}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-tertiary-bg peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between bg-tertiary-bg p-4 rounded-lg">
                <div>
                  <h4 className="font-primary font-medium">Sound Alerts</h4>
                  <p className="text-sm text-text-tertiary mt-1">Play sound when alerts are triggered</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    name="enable_sound"
                    checked={formValues.enable_sound}
                    onChange={handleChange}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-tertiary-bg peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between bg-tertiary-bg p-4 rounded-lg">
                <div>
                  <h4 className="font-primary font-medium">Email Notifications</h4>
                  <p className="text-sm text-text-tertiary mt-1">Receive alerts via email</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    name="enable_email"
                    checked={formValues.enable_email}
                    onChange={handleChange}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-tertiary-bg peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                </label>
              </div>
              
              {formValues.enable_email && (
                <div className="bg-tertiary-bg p-4 rounded-lg">
                  <label className="block text-sm font-medium text-text-secondary mb-2">Email Address</label>
                  <input
                    type="email"
                    name="email_address"
                    value={formValues.email_address}
                    onChange={handleChange}
                    placeholder="Enter your email address"
                    className="w-full bg-secondary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
              )}
              
              {/* SMS Notification Section */}
              <div className="flex items-center justify-between bg-tertiary-bg p-4 rounded-lg">
                <div>
                  <h4 className="font-primary font-medium">SMS Notifications</h4>
                  <p className="text-sm text-text-tertiary mt-1">Receive alerts via SMS</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    name="enable_sms"
                    checked={formValues.enable_sms}
                    onChange={handleChange}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-tertiary-bg peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                </label>
              </div>
              
              {formValues.enable_sms && (
                <div className="space-y-4">
                  <div className="bg-tertiary-bg p-4 rounded-lg">
                    <label className="block text-sm font-medium text-text-secondary mb-2">Phone Number</label>
                    <input
                      type="tel"
                      name="phone_number"
                      value={formValues.phone_number}
                      onChange={handleChange}
                      placeholder="Enter phone number (with country code)"
                      className="w-full bg-secondary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                      required
                    />
                    <p className="text-xs text-text-tertiary mt-2">Format: +1XXXXXXXXXX (include country code)</p>
                  </div>
                  
                  <div className="bg-tertiary-bg p-4 rounded-lg">
                    <h4 className="font-primary font-medium mb-3">SMS Alert Levels</h4>
                    <p className="text-xs text-text-tertiary mb-4">Select which alert levels should trigger SMS notifications</p>
                    
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="sms_critical"
                          name="sms_critical"
                          checked={formValues.sms_critical}
                          onChange={handleChange}
                          className="w-4 h-4 text-accent bg-tertiary-bg border-white/20 rounded focus:ring-accent focus:ring-1"
                        />
                        <label htmlFor="sms_critical" className="ml-2 text-sm font-medium text-danger">
                          Critical Alerts
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="sms_high"
                          name="sms_high"
                          checked={formValues.sms_high}
                          onChange={handleChange}
                          className="w-4 h-4 text-accent bg-tertiary-bg border-white/20 rounded focus:ring-accent focus:ring-1"
                        />
                        <label htmlFor="sms_high" className="ml-2 text-sm font-medium text-warning">
                          High Alerts
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="sms_medium"
                          name="sms_medium"
                          checked={formValues.sms_medium}
                          onChange={handleChange}
                          className="w-4 h-4 text-accent bg-tertiary-bg border-white/20 rounded focus:ring-accent focus:ring-1"
                        />
                        <label htmlFor="sms_medium" className="ml-2 text-sm font-medium text-success">
                          Medium Alerts
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="sms_low"
                          name="sms_low"
                          checked={formValues.sms_low}
                          onChange={handleChange}
                          className="w-4 h-4 text-accent bg-tertiary-bg border-white/20 rounded focus:ring-accent focus:ring-1"
                        />
                        <label htmlFor="sms_low" className="ml-2 text-sm font-medium text-info">
                          Low Alerts
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <button 
              className="mt-6 bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md px-6 py-2.5 transition duration-300"
              onClick={saveNotificationSettings}
            >
              Save Notification Settings
            </button>
          </div>
        </div>
      )}
      
      {/* Adafruit IO Settings */}
      {activeTab === 'adafruit' && (
        <div className="settings-panel">
          <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
            <h3 className="text-lg font-primary font-semibold mb-4">Adafruit IO Configuration</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">Adafruit IO Username</label>
                  <input
                    type="text"
                    name="adafruit_username"
                    value={formValues.adafruit_username}
                    onChange={handleChange}
                    className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">Adafruit IO Key</label>
                  <input
                    type="password"
                    name="adafruit_key"
                    value={formValues.adafruit_key}
                    onChange={handleChange}
                    className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">eCO2 Feed</label>
                  <input
                    type="text"
                    name="eco2_feed"
                    value={formValues.eco2_feed}
                    onChange={handleChange}
                    className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">TVOC Feed</label>
                  <input
                    type="text"
                    name="tvoc_feed"
                    value={formValues.tvoc_feed}
                    onChange={handleChange}
                    className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">EtOH Feed</label>
                  <input
                    type="text"
                    name="etoh_feed"
                    value={formValues.etoh_feed}
                    onChange={handleChange}
                    className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">IAQ Feed</label>
                  <input
                    type="text"
                    name="iaq_feed"
                    value={formValues.iaq_feed}
                    onChange={handleChange}
                    className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                    required
                  />
                </div>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-3 mt-6">
              <button 
                id="save-adafruit-settings"
                className="bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md px-6 py-2.5 transition duration-300"
                onClick={saveAdafruitSettings}
              >
                Save Adafruit Settings
              </button>
              
              <button 
                id="test-connection"
                className="bg-tertiary-bg hover:bg-opacity-80 text-text-secondary font-primary font-medium border border-accent/30 rounded-md px-6 py-2.5 transition duration-300"
                onClick={testConnection}
              >
                Test Connection
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Application Settings */}
      {activeTab === 'application' && (
        <div className="settings-panel">
          <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
            <h3 className="text-lg font-primary font-semibold mb-4">Application Settings</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">Data Refresh Interval (seconds)</label>
                <input
                  type="number"
                  name="refresh_interval"
                  value={formValues.refresh_interval}
                  onChange={handleChange}
                  min="5"
                  max="300"
                  className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                  required
                />
                <p className="text-xs text-text-tertiary mt-1">How often to fetch new sensor data (5-300 seconds)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">Prediction Update Interval (seconds)</label>
                <input
                  type="number"
                  name="prediction_interval"
                  value={formValues.prediction_interval}
                  onChange={handleChange}
                  min="60"
                  max="3600"
                  className="w-full bg-tertiary-bg border border-white/10 text-text-primary rounded-md py-2 px-3"
                  required
                />
                <p className="text-xs text-text-tertiary mt-1">How often to update crowd density predictions (60-3600 seconds)</p>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-3 mt-6">
              <button 
                id="save-app-settings"
                className="bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md px-6 py-2.5 transition duration-300"
                onClick={saveAppSettings}
              >
                Save App Settings
              </button>
              
              <button 
                id="reset-settings"
                className="bg-danger/10 hover:bg-danger/20 text-danger font-primary font-medium rounded-md px-6 py-2.5 transition duration-300"
                onClick={resetSettings}
              >
                Reset All Settings
              </button>
            </div>
          </div>
          
          <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
            <h3 className="text-lg font-primary font-semibold mb-4">About</h3>
            <div className="bg-tertiary-bg rounded-lg p-4">
              <div className="flex justify-center mb-4">
                <div className="text-center">
                  <h2 className="font-primary font-bold text-accent text-2xl">CROWD MONITOR</h2>
                  <p className="text-text-tertiary">Version 1.0.0</p>
                </div>
              </div>
              <p className="text-text-secondary text-center mb-3">
                A real-time crowd monitoring system using Renesas zmod4410 sensor data.
              </p>
              <div className="text-center text-text-tertiary text-sm">
                <p>Created for Varshini CB, Renesas</p>
                <p className="mt-1">© 2023 All Rights Reserved</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPage;
