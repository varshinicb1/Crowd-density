import React, { useState } from 'react';
import Sidebar from '../sidebar/Sidebar';
import MobileHeader from '../header/MobileHeader';
import { AlertModal } from '../alerts/AlertModal';

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [alertModalOpen, setAlertModalOpen] = useState(false);
  const [activeAlert, setActiveAlert] = useState<any>(null);
  
  const toggleMobileSidebar = () => {
    setMobileSidebarOpen(!mobileSidebarOpen);
  };
  
  const showAlertModal = (alert: any) => {
    setActiveAlert(alert);
    setAlertModalOpen(true);
  };
  
  return (
    <div className="flex min-h-screen">
      {/* Desktop Sidebar */}
      <Sidebar className="hidden lg:block" />
      
      {/* Mobile Header */}
      <MobileHeader 
        onMenuClick={toggleMobileSidebar} 
        className="lg:hidden"
      />
      
      {/* Mobile Sidebar Overlay */}
      {mobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        >
          <Sidebar 
            className="w-64 h-full transform transition-transform" 
            mobile={true}
          />
        </div>
      )}
      
      {/* Main Content */}
      <main className="flex-1 ml-0 lg:ml-64 pt-16 lg:pt-0 pb-8">
        {children}
      </main>
      
      {/* Alert Modal */}
      <AlertModal 
        open={alertModalOpen} 
        alert={activeAlert}
        onClose={() => setAlertModalOpen(false)} 
      />
    </div>
  );
};

export default MainLayout;
