import React, { useContext } from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { StatusIndicator } from '../ui/status-indicator';
import { AppContext } from '../../App';
import { formatTimeAgo } from '../../lib/sensor-utils';

interface SidebarProps {
  className?: string;
  mobile?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ className, mobile = false }) => {
  const [location, setLocation] = useLocation();
  const { state } = useContext(AppContext);
  
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fas fa-tachometer-alt' },
    { id: 'monitoring', label: 'Monitoring', icon: 'fas fa-chart-line' },
    { id: 'prediction', label: 'Prediction', icon: 'fas fa-chart-bar' },
    { id: 'alerts', label: 'Alerts', icon: 'fas fa-bell' },
    { id: 'settings', label: 'Settings', icon: 'fas fa-cog' }
  ];
  
  const currentPage = location.substring(1) || 'dashboard';
  
  return (
    <aside className={cn('fixed h-full w-64 bg-secondary-bg shadow-lg z-40', className)}>
      <div className="flex items-center justify-center h-16 border-b border-white/10">
        <h1 className="font-primary font-bold text-accent text-xl">CROWD MONITOR</h1>
      </div>
      
      <nav className="mt-6">
        <ul>
          {navItems.map(item => (
            <li key={item.id} className="mb-2">
              <Link 
                href={`/${item.id}`}
                onClick={() => {
                  if (mobile) {
                    // Close mobile sidebar if implemented
                  }
                }}
                className={cn(
                  'nav-link flex items-center px-6 py-3 text-text-secondary',
                  currentPage === item.id && 'active'
                )}
              >
                <i className={`${item.icon} w-5 mr-3`}></i>
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <div className="bg-tertiary-bg rounded-lg p-3">
          <div className="flex items-center mb-2 text-sm text-text-secondary">
            <i className="fas fa-server mr-2"></i>
            <span>Connection Status</span>
          </div>
          <StatusIndicator 
            status={state.connectionStatus === 'connected' ? 'connected' : 
                   state.connectionStatus === 'connecting' ? 'connecting' : 'error'} 
          />
          <div className="text-xs text-text-tertiary mt-2">
            Last updated: <span id="last-updated">
              {state.lastUpdated ? formatTimeAgo(state.lastUpdated) : 'never'}
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
