import React from 'react';
import { formatDate } from '../../lib/sensor-utils';

interface AlertModalProps {
  open: boolean;
  alert: any;
  onClose: () => void;
}

export const AlertModal: React.FC<AlertModalProps> = ({ open, alert, onClose }) => {
  if (!open || !alert) return null;
  
  // Determine alert type styling
  let borderClass = '';
  let colorClass = '';
  let title = '';
  
  switch (alert.alertType) {
    case 'critical':
      borderClass = 'danger';
      colorClass = 'text-danger';
      title = 'CRITICAL ALERT';
      break;
    case 'high':
      borderClass = 'warning';
      colorClass = 'text-warning';
      title = 'HIGH DENSITY WARNING';
      break;
    case 'prediction':
      borderClass = 'accent';
      colorClass = 'text-accent';
      title = 'PREDICTION ALERT';
      break;
  }
  
  // Format timestamp
  const timestamp = alert.timestamp ? new Date(alert.timestamp) : new Date();
  const formattedTime = formatDate(timestamp);
  
  // Extract details
  const { density = 0, crowdCount = 0 } = alert.details || {};
  
  return (
    <div 
      id="alert-modal" 
      className="fixed inset-0 flex items-center justify-center z-50"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="absolute inset-0 bg-black/80"></div>
      <div className={`bg-gradient-primary rounded-lg w-full max-w-md mx-4 z-10 card-border-top ${borderClass}`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className={`font-primary text-xl font-bold ${colorClass}`}>{title}</h3>
            <button 
              id="alert-modal-close" 
              className="text-text-tertiary hover:text-text-primary"
              onClick={onClose}
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
          <div className="mb-6">
            <p className="text-text-primary mb-4">{alert.message}</p>
            <div className={`bg-${alert.alertType === 'critical' ? 'danger' : alert.alertType === 'high' ? 'warning' : 'accent'}/10 p-4 rounded-md`}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-text-tertiary">Density</div>
                  <div className={`font-primary font-bold text-2xl ${colorClass}`}>
                    {typeof density === 'string' ? parseFloat(density).toFixed(2) : density.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-text-tertiary">Est. Count</div>
                  <div className="font-primary font-bold text-2xl">{crowdCount}</div>
                </div>
                <div>
                  <div className="text-xs text-text-tertiary">Location</div>
                  <div className="font-mono">Main Hall</div>
                </div>
                <div>
                  <div className="text-xs text-text-tertiary">Time</div>
                  <div className="font-mono">{formattedTime}</div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex space-x-3">
            <button 
              className={`bg-${alert.alertType === 'critical' ? 'danger' : alert.alertType === 'high' ? 'warning' : 'accent'} flex-1 hover:bg-opacity-80 text-white font-primary font-medium rounded-md py-2.5 transition duration-300`}
              onClick={onClose}
            >
              Take Action
            </button>
            <button 
              className="bg-tertiary-bg flex-1 hover:bg-opacity-80 text-text-secondary font-primary font-medium rounded-md py-2.5 transition duration-300"
              onClick={onClose}
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
