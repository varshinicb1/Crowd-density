import React, { useContext, useState } from 'react';
import { AppContext } from '../../App';
import AlertItem from '../dashboard/AlertItem';

type FilterType = 'all' | 'critical' | 'high' | 'prediction';

const AlertsPage: React.FC = () => {
  const { state, testAlert } = useContext(AppContext);
  const { alertHistory, settings } = state;
  
  const [filter, setFilter] = useState<FilterType>('all');
  const [testAlertType, setTestAlertType] = useState<string>('critical');
  
  // Filter alerts based on selected filter
  const filteredAlerts = alertHistory.filter(alert => {
    switch (filter) {
      case 'critical':
        return alert.alertType === 'critical';
      case 'high':
        return alert.alertType === 'critical' || alert.alertType === 'high';
      case 'prediction':
        return alert.alertType === 'prediction';
      default:
        return true;
    }
  });
  
  return (
    <div className="p-6">
      <div className="flex flex-wrap items-center justify-between mb-6">
        <h2 className="text-2xl font-primary font-semibold">Alert History</h2>
        <div className="flex items-center">
          <span className="text-sm text-text-secondary mr-2">Filter:</span>
          <select 
            id="alert-filter" 
            className="bg-tertiary-bg text-text-primary border border-white/10 rounded py-1 px-3 text-sm"
            value={filter}
            onChange={(e) => setFilter(e.target.value as FilterType)}
          >
            <option value="all">All Alerts</option>
            <option value="critical">Critical Only</option>
            <option value="high">High & Critical</option>
            <option value="prediction">Predictions Only</option>
          </select>
        </div>
      </div>

      {/* Alert List */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
        <div className="space-y-4">
          {filteredAlerts.length > 0 ? (
            filteredAlerts.map(alert => (
              <AlertItem key={alert.id} alert={alert} detailed={true} />
            ))
          ) : (
            <div className="text-center py-10 text-text-tertiary">
              <i className="fas fa-bell-slash text-4xl mb-3 block"></i>
              <p>No alerts found with the current filter</p>
            </div>
          )}
        </div>
      </div>

      {/* Test Alert */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
        <h3 className="text-lg font-primary font-semibold mb-4">Test Alerts</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-tertiary-bg rounded-lg p-4">
            <h4 className="font-primary text-accent mb-3">Generate Test Alert</h4>
            <div className="mb-4">
              <label className="block text-sm text-text-secondary mb-1">Alert Type</label>
              <select 
                id="test-alert-type" 
                className="w-full bg-secondary-bg text-text-primary border border-white/10 rounded py-2 px-3"
                value={testAlertType}
                onChange={(e) => setTestAlertType(e.target.value)}
              >
                <option value="critical">Critical Density</option>
                <option value="high">High Density</option>
                <option value="prediction">Prediction Alert</option>
              </select>
            </div>
            <button 
              id="test-alert" 
              className="w-full bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md py-2.5 transition duration-300"
              onClick={() => testAlert(testAlertType)}
            >
              Send Test Alert
            </button>
          </div>
          <div className="bg-tertiary-bg rounded-lg p-4">
            <h4 className="font-primary text-accent mb-3">Alert Notifications</h4>
            <p className="text-text-secondary mb-4">Test alert will be sent through your configured notification channels.</p>
            <div className="space-y-2">
              <div className="flex items-center justify-between py-2 border-b border-white/10">
                <span className="text-text-secondary">Browser Notifications</span>
                <span className={settings.enable_browser ? "text-success" : "text-danger"}>
                  {settings.enable_browser ? "Enabled" : "Disabled"}
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-white/10">
                <span className="text-text-secondary">Sound Alerts</span>
                <span className={settings.enable_sound ? "text-success" : "text-danger"}>
                  {settings.enable_sound ? "Enabled" : "Disabled"}
                </span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-text-secondary">Email Notifications</span>
                <span className={settings.enable_email ? "text-success" : "text-danger"}>
                  {settings.enable_email ? "Enabled" : "Disabled"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AlertsPage;
