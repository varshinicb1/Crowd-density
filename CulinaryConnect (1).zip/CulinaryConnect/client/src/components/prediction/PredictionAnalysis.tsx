import React from 'react';

interface PredictionAnalysisProps {
  peakDensity: number;
  peakTime: string;
  peakCount: number;
  status: string;
  willReachCritical: boolean;
  onUpdatePrediction: () => void;
}

const PredictionAnalysis: React.FC<PredictionAnalysisProps> = ({
  peakDensity,
  peakTime,
  peakCount,
  status,
  willReachCritical,
  onUpdatePrediction
}) => {
  // Generate analysis text based on prediction
  const generateSummary = () => {
    return `Crowd density is predicted to reach <span class="text-${status === 'Critical' ? 'danger' : status === 'High' ? 'warning' : 'accent'} font-semibold">${status.toLowerCase()} levels</span> in the next ${peakTime}, peaking at ${peakDensity.toFixed(2)} with approximately ${peakCount} people.`;
  };
  
  // Generate recommendations based on predicted status
  const getRecommendations = () => {
    if (status === 'Critical') {
      return [
        'Immediately restrict entrance to prevent overcrowding',
        'Open all available exits to facilitate movement',
        'Activate emergency ventilation systems',
        'Alert staff to potential safety concerns'
      ];
    } else if (status === 'High') {
      return [
        'Monitor venue entrances to manage inflow',
        'Prepare to open additional areas if density reaches critical',
        'Check ventilation systems for optimal operation',
        'Consider staggered entry if conditions worsen'
      ];
    } else if (status === 'Medium') {
      return [
        'Maintain normal operations with increased monitoring',
        'Ensure all staff are positioned correctly',
        'Prepare for potential increase in density',
        'Review emergency protocols as a precaution'
      ];
    } else {
      return [
        'Continue normal operations',
        'Regular monitoring of environmental conditions',
        'Periodic sensor status checks',
        'Maintain standard air quality levels'
      ];
    }
  };
  
  const recommendations = getRecommendations();
  
  return (
    <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
      <h3 className="text-lg font-primary font-semibold mb-4">Analysis</h3>
      <div className="bg-tertiary-bg rounded-lg p-4 mb-4">
        <div className="text-sm font-primary text-accent mb-2">PREDICTION SUMMARY</div>
        <p 
          className="text-text-secondary"
          dangerouslySetInnerHTML={{ __html: generateSummary() }}
        ></p>
      </div>
      <div className="bg-tertiary-bg rounded-lg p-4 mb-4">
        <div className={`text-sm font-primary text-${willReachCritical ? 'danger' : status === 'High' ? 'warning' : 'accent'} mb-2`}>
          RECOMMENDATIONS
        </div>
        <ul className="text-text-secondary space-y-2">
          {recommendations.map((rec, index) => (
            <li key={index} className="flex items-start">
              <i className="fas fa-arrow-right text-xs mt-1.5 mr-2"></i>
              <span>{rec}</span>
            </li>
          ))}
        </ul>
      </div>
      <button 
        onClick={onUpdatePrediction}
        className="w-full bg-gradient-accent hover:opacity-90 text-primary-bg font-primary font-medium rounded-md py-2.5 transition duration-300 mt-2"
        id="update-prediction-btn"
      >
        Generate New Prediction
      </button>
    </div>
  );
};

export default PredictionAnalysis;
