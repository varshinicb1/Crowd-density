import React, { useEffect, useRef } from 'react';
import { Chart } from 'chart.js';
import { generateTimeLabels } from '../../lib/sensor-utils';

interface PredictionDetailChartProps {
  predictionData: {
    timestamps: number[];
    density: number[];
    crowdCount: number[];
    confidence: number[];
  } | null;
  criticalThreshold: number;
  highThreshold: number;
}

const PredictionDetailChart: React.FC<PredictionDetailChartProps> = ({ 
  predictionData, 
  criticalThreshold,
  highThreshold
}) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  // Chart colors
  const chartColors = {
    primary: '#00E5FF',
    secondary: '#4E11A8',
    danger: '#FF5252',
    warning: '#FFD600',
    success: '#AEEA00',
    grid: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.7)'
  };
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Generate time labels
    const timeLabels = generateTimeLabels(21);
    
    // Prepare confidence area
    const confidenceArea = predictionData ? 
      predictionData.density.map((d, i) => {
        const conf = predictionData.confidence[i];
        return d * (1 + (1 - conf) * 0.3);
      }) : [];
    
    const confidenceAreaBottom = predictionData ? 
      predictionData.density.map((d, i) => {
        const conf = predictionData.confidence[i];
        return Math.max(0, d * (1 - (1 - conf) * 0.3));
      }) : [];
    
    // Create new chart
    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: timeLabels,
        datasets: [
          {
            label: 'Predicted Density',
            data: predictionData ? predictionData.density : [],
            borderColor: chartColors.primary,
            backgroundColor: 'rgba(0, 229, 255, 0.2)',
            borderWidth: 2,
            pointRadius: 3,
            pointBackgroundColor: chartColors.primary,
            tension: 0.4,
            fill: false,
            yAxisID: 'y'
          },
          {
            label: 'Confidence Range (Upper)',
            data: confidenceArea,
            borderColor: 'transparent',
            backgroundColor: 'rgba(0, 229, 255, 0.05)',
            borderWidth: 0,
            pointRadius: 0,
            tension: 0.4,
            fill: '+1',
            yAxisID: 'y'
          },
          {
            label: 'Confidence Range (Lower)',
            data: confidenceAreaBottom,
            borderColor: 'transparent',
            backgroundColor: 'rgba(0, 229, 255, 0.05)',
            borderWidth: 0,
            pointRadius: 0,
            tension: 0.4,
            fill: false,
            yAxisID: 'y'
          },
          {
            label: 'Crowd Count',
            data: predictionData ? predictionData.crowdCount : [],
            borderColor: chartColors.secondary,
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointRadius: 2,
            pointBackgroundColor: chartColors.secondary,
            borderDash: [5, 5],
            tension: 0.4,
            fill: false,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              filter: function(item) {
                // Hide confidence range datasets from legend
                return !item.text.includes('Confidence Range');
              },
              color: chartColors.text,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              },
              boxWidth: 12,
              usePointStyle: true,
              pointStyle: 'circle'
            }
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(20, 20, 50, 0.9)',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            borderColor: 'rgba(0, 229, 255, 0.3)',
            borderWidth: 1,
            callbacks: {
              label: function(context) {
                if (context.dataset.label?.includes('Confidence Range')) {
                  return '';
                }
                
                if (context.dataset.label === 'Predicted Density') {
                  const index = context.dataIndex;
                  const confidence = predictionData ? predictionData.confidence[index] * 100 : 0;
                  return `${context.dataset.label}: ${context.parsed.y.toFixed(2)} (${confidence.toFixed(0)}% confidence)`;
                }
                
                return `${context.dataset.label}: ${context.parsed.y}`;
              },
              afterBody: function(tooltipItems) {
                const index = tooltipItems[0].dataIndex;
                const confidence = predictionData ? predictionData.confidence[index] * 100 : 0;
                return `Confidence: ${confidence.toFixed(0)}%`;
              }
            }
          },
          annotation: {
            annotations: {
              criticalLine: {
                type: 'line',
                yMin: criticalThreshold,
                yMax: criticalThreshold,
                borderColor: chartColors.danger,
                borderWidth: 2,
                borderDash: [5, 5],
                yScaleID: 'y',
                label: {
                  display: true,
                  content: 'Critical',
                  position: 'end',
                  backgroundColor: 'rgba(255, 82, 82, 0.8)',
                  color: '#FFFFFF',
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                }
              },
              highLine: {
                type: 'line',
                yMin: highThreshold,
                yMax: highThreshold,
                borderColor: chartColors.warning,
                borderWidth: 2,
                borderDash: [5, 5],
                yScaleID: 'y',
                label: {
                  display: true,
                  content: 'High',
                  position: 'end',
                  backgroundColor: 'rgba(255, 214, 0, 0.8)',
                  color: '#FFFFFF',
                  font: {
                    family: "'Rajdhani', sans-serif",
                    size: 12
                  }
                }
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.text,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'Density',
              color: chartColors.primary,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              }
            },
            beginAtZero: true,
            max: 1.5,
            grid: {
              color: chartColors.grid
            },
            ticks: {
              color: chartColors.primary,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              },
              callback: function(value) {
                return value.toFixed(1);
              }
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'Count',
              color: chartColors.secondary,
              font: {
                family: "'Rajdhani', sans-serif",
                size: 12
              }
            },
            min: 0,
            max: 500,
            grid: {
              drawOnChartArea: false
            },
            ticks: {
              color: chartColors.secondary,
              font: {
                family: "'Share Tech Mono', monospace",
                size: 10
              }
            }
          }
        }
      }
    });
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [predictionData, criticalThreshold, highThreshold]);
  
  if (!predictionData) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-text-tertiary">
          <i className="fas fa-spinner fa-spin mr-2"></i>
          <span>Generating prediction...</span>
        </div>
      </div>
    );
  }
  
  return <canvas ref={chartRef}></canvas>;
};

export default PredictionDetailChart;
