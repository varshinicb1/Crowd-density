import React, { useContext, useEffect } from 'react';
import { AppContext } from '../../App';
import PredictionDetailChart from './PredictionDetailChart';
import PredictionAnalysis from './PredictionAnalysis';
import { StatusIndicator } from '../ui/status-indicator';
import { getDensityStatus, formatFullDate } from '../../lib/sensor-utils';

const PredictionPage: React.FC = () => {
  const { state, fetchSensorData, generatePrediction } = useContext(AppContext);
  const { currentData, predictionData, settings } = state;
  
  // Get current density status
  const densityStatus = currentData ? 
    getDensityStatus(
      parseFloat(currentData.density), 
      parseFloat(settings.critical_threshold), 
      parseFloat(settings.high_threshold)
    ) : 
    { class: 'status-low', text: 'Low' };
  
  // Find peak density and its time
  const findPeakDensity = () => {
    if (!predictionData) return { peakDensity: 0, peakIndex: 0, peakCount: 0 };
    
    let peakDensity = 0;
    let peakIndex = 0;
    
    predictionData.density.forEach((density, index) => {
      if (density > peakDensity) {
        peakDensity = density;
        peakIndex = index;
      }
    });
    
    return {
      peakDensity,
      peakIndex,
      peakCount: predictionData.crowdCount[peakIndex]
    };
  };
  
  const { peakDensity, peakIndex, peakCount } = findPeakDensity();
  
  // Format peak time
  const formatPeakTime = (index: number) => {
    if (index === 0) return 'now';
    if (index === 1) return '1 minute';
    return `${index} minutes`;
  };
  
  // Get peak density status
  const peakDensityStatus = getDensityStatus(
    peakDensity,
    parseFloat(settings.critical_threshold),
    parseFloat(settings.high_threshold)
  );
  
  // Calculate average confidence
  const avgConfidence = predictionData ?
    predictionData.confidence.reduce((sum, val) => sum + val, 0) / predictionData.confidence.length :
    0;
  
  // Refresh prediction data
  useEffect(() => {
    if (currentData && !predictionData) {
      generatePrediction();
    }
  }, [currentData, predictionData, generatePrediction]);
  
  return (
    <div className="p-6">
      <div className="flex flex-wrap items-center justify-between mb-6">
        <h2 className="text-2xl font-primary font-semibold">Crowd Density Prediction</h2>
        <button 
          onClick={() => fetchSensorData().then(() => generatePrediction())}
          className="bg-accent/10 hover:bg-accent/20 text-accent rounded-md px-4 py-2 flex items-center transition duration-300"
          id="prediction-refresh-btn"
        >
          <i className="fas fa-sync-alt mr-2"></i>
          <span>Refresh</span>
        </button>
      </div>

      {/* Current Status */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
        <h3 className="text-lg font-primary font-semibold mb-4">Current Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-tertiary-bg rounded-lg p-4">
            <div className="text-sm font-primary text-text-secondary mb-1">CURRENT DENSITY</div>
            <div className="flex items-center justify-between">
              <div className="font-primary font-bold text-3xl" id="current-density-value">
                {currentData ? parseFloat(currentData.density).toFixed(2) : "0.00"}
              </div>
              <StatusIndicator 
                status={densityStatus.class.replace('status-', '') as any}
                label={densityStatus.text}
                id="current-density-status"
              />
            </div>
          </div>
          <div className="bg-tertiary-bg rounded-lg p-4">
            <div className="text-sm font-primary text-text-secondary mb-1">CROWD COUNT</div>
            <div className="flex items-center justify-between">
              <div className="font-primary font-bold text-3xl" id="current-count-value">
                {currentData ? currentData.crowdCount : "0"}
              </div>
              <div className="text-text-tertiary">
                <i className="fas fa-users"></i>
              </div>
            </div>
          </div>
          <div className="bg-tertiary-bg rounded-lg p-4">
            <div className="text-sm font-primary text-text-secondary mb-1">LAST UPDATED</div>
            <div className="flex items-center justify-between">
              <div className="font-mono text-lg" id="prediction-timestamp">
                {state.lastUpdated ? formatFullDate(state.lastUpdated) : "Never"}
              </div>
              <div className="text-text-tertiary">
                <i className="fas fa-clock"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Prediction Chart */}
      <div className="bg-secondary-bg rounded-lg p-6 card-border-top mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-primary font-semibold">20 Minute Prediction</h3>
          <div className="flex items-center">
            <span className="text-sm text-text-secondary mr-2">Model:</span>
            <span className="font-primary text-accent">LSTM Real-time</span>
          </div>
        </div>
        <div className="chart-container h-80">
          <PredictionDetailChart 
            predictionData={predictionData}
            criticalThreshold={parseFloat(settings.critical_threshold)}
            highThreshold={parseFloat(settings.high_threshold)}
          />
        </div>
      </div>

      {/* Prediction Analysis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Peak Prediction */}
        <div className="bg-secondary-bg rounded-lg p-6 card-border-top">
          <h3 className="text-lg font-primary font-semibold mb-4">Peak Prediction</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-tertiary-bg rounded-lg p-4">
              <div className="text-sm font-primary text-text-secondary mb-1">PEAK DENSITY</div>
              <div className="font-primary font-bold text-3xl mb-2" id="peak-density-value">
                {peakDensity.toFixed(2)}
              </div>
              <StatusIndicator 
                status={peakDensityStatus.class.replace('status-', '') as any}
                label={peakDensityStatus.text}
                id="peak-density-status"
                size="sm"
              />
            </div>
            <div className="bg-tertiary-bg rounded-lg p-4">
              <div className="text-sm font-primary text-text-secondary mb-1">PREDICTED COUNT</div>
              <div className="font-primary font-bold text-3xl" id="predicted-count-value">
                {peakCount}
              </div>
              <div className="text-xs text-text-tertiary">people at peak</div>
            </div>
            <div className="bg-tertiary-bg rounded-lg p-4">
              <div className="text-sm font-primary text-text-secondary mb-1">TIME TO PEAK</div>
              <div className="font-primary font-bold text-3xl" id="peak-time">
                {formatPeakTime(peakIndex)}
              </div>
              <div className="text-xs text-text-tertiary">minutes from now</div>
            </div>
            <div className="bg-tertiary-bg rounded-lg p-4">
              <div className="text-sm font-primary text-text-secondary mb-1">CONFIDENCE</div>
              <div className="font-primary font-bold text-3xl" id="prediction-confidence-value">
                {Math.round(avgConfidence * 100)}%
              </div>
              <div className="mt-2 bg-white/10 h-1.5 rounded-full overflow-hidden w-full">
                <div 
                  className="confidence-level bg-accent h-full rounded-full" 
                  style={{ width: `${Math.round(avgConfidence * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Prediction Analysis */}
        <PredictionAnalysis 
          peakDensity={peakDensity} 
          peakTime={formatPeakTime(peakIndex)}
          peakCount={peakCount}
          status={peakDensityStatus.text}
          willReachCritical={predictionData ? 
            predictionData.density.some(d => d >= parseFloat(settings.critical_threshold)) : 
            false
          }
          onUpdatePrediction={() => generatePrediction()}
        />
      </div>
    </div>
  );
};

export default PredictionPage;
