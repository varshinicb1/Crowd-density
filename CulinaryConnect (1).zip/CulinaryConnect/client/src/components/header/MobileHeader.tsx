import React, { useContext } from 'react';
import { cn } from '@/lib/utils';
import { AppContext } from '../../App';

interface MobileHeaderProps {
  className?: string;
  onMenuClick: () => void;
}

const MobileHeader: React.FC<MobileHeaderProps> = ({ className, onMenuClick }) => {
  const { fetchSensorData } = useContext(AppContext);
  
  return (
    <div className={cn("fixed top-0 left-0 right-0 h-16 bg-secondary-bg shadow-lg z-30 flex items-center px-4", className)}>
      <button 
        onClick={onMenuClick}
        className="p-2 rounded-md text-text-secondary hover:bg-tertiary-bg"
      >
        <i className="fas fa-bars"></i>
      </button>
      
      <h1 className="font-primary font-bold text-accent text-xl ml-4">CROWD MONITOR</h1>
      
      <div className="ml-auto flex items-center space-x-2">
        <button 
          onClick={() => fetchSensorData()}
          className="p-2 rounded-md text-text-secondary hover:bg-tertiary-bg"
        >
          <i className="fas fa-sync-alt"></i>
        </button>
      </div>
    </div>
  );
};

export default MobileHeader;
