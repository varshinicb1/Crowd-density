import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const statusIndicatorVariants = cva(
  "flex items-center py-1 px-3 rounded-full text-sm inline-flex", 
  {
    variants: {
      status: {
        low: "bg-success/10 text-success",
        medium: "bg-success/10 text-success",
        high: "bg-warning/10 text-warning",
        critical: "bg-danger/10 text-danger",
        error: "bg-danger/10 text-danger",
        connecting: "bg-warning/10 text-warning",
        connected: "bg-success/10 text-success"
      },
      size: {
        sm: "py-0.5 px-2 text-xs",
        md: "py-1 px-3 text-sm",
        lg: "py-1.5 px-4 text-base"
      }
    },
    defaultVariants: {
      status: "low",
      size: "md"
    }
  }
);

export interface StatusIndicatorProps 
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof statusIndicatorVariants> {
  label?: string;
  icon?: boolean;
  pulse?: boolean;
}

const StatusIndicator = React.forwardRef<HTMLDivElement, StatusIndicatorProps>(
  ({ className, status, size, label, icon = true, pulse = false, ...props }, ref) => {
    let text = label;
    
    // Default label based on status if not provided
    if (!text) {
      switch (status) {
        case 'critical':
          text = 'Critical';
          break;
        case 'high':
          text = 'High';
          break;
        case 'medium':
          text = 'Medium';
          break;
        case 'low':
          text = 'Low';
          break;
        case 'error':
          text = 'Error';
          break;
        case 'connecting':
          text = 'Connecting';
          break;
        case 'connected':
          text = 'Connected';
          break;
      }
    }
    
    return (
      <div 
        ref={ref}
        className={cn(
          statusIndicatorVariants({ status, size }),
          pulse && status === 'critical' && 'status-pulse',
          className
        )}
        {...props}
      >
        {icon && (
          status === 'connecting' ? 
            <i className="fas fa-circle-notch fa-spin mr-2 text-xs"></i> :
            <i className="fas fa-circle mr-2 text-xs"></i>
        )}
        <span>{text}</span>
      </div>
    );
  }
);

StatusIndicator.displayName = 'StatusIndicator';

export { StatusIndicator, statusIndicatorVariants };
