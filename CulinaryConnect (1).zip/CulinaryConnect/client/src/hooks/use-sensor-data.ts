import { useQuery } from '@tanstack/react-query';
import { useState, useEffect } from 'react';
import { type SensorData } from '../App';

export function useSensorData() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Fetch the latest sensor data
  const { 
    data: sensorData, 
    isLoading,
    error,
    refetch 
  } = useQuery({
    queryKey: ['/api/sensor/latest'],
    refetchOnWindowFocus: false,
    refetchInterval: false
  });
  
  // Custom refresh function with loading state
  const refreshData = async () => {
    setIsRefreshing(true);
    try {
      // Fetch directly from Adafruit to ensure fresh data
      const response = await fetch('/api/adafruit/fetch');
      setIsRefreshing(false);
      return response.json();
    } catch (error) {
      console.error('Error refreshing sensor data:', error);
      setIsRefreshing(false);
      throw error;
    }
  };
  
  // Function to fetch historical data
  const fetchHistoricalData = async (period: string) => {
    try {
      const response = await fetch(`/api/adafruit/history/${period}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching historical data:', error);
      return null;
    }
  };
  
  return {
    sensorData,
    isLoading: isLoading || isRefreshing,
    error,
    refreshData,
    fetchHistoricalData
  };
}
