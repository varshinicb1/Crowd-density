import { useEffect, useRef, useState } from 'react';

export interface WebSocketMessage {
  data: string;
  type: string;
}

export interface UseWebSocketResult {
  sendMessage: (message: string | object) => void;
  lastMessage: WebSocketMessage | null;
  readyState: number;
  connectionStatus: 'connecting' | 'connected' | 'closed' | 'error';
}

export function useWebSocket(path: string): UseWebSocketResult {
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const [readyState, setReadyState] = useState<number>(WebSocket.CONNECTING);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'closed' | 'error'>('connecting');
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    // Create WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}${path}`;
    
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    // Connection opened
    socket.addEventListener('open', () => {
      setReadyState(WebSocket.OPEN);
      setConnectionStatus('connected');
      console.log('WebSocket connection established');
      
      // Request initial data refresh
      socket.send(JSON.stringify({ type: 'refresh' }));
    });

    // Listen for messages
    socket.addEventListener('message', (event) => {
      setLastMessage({ data: event.data, type: event.type });
    });

    // Connection closed
    socket.addEventListener('close', () => {
      setReadyState(WebSocket.CLOSED);
      setConnectionStatus('closed');
      console.log('WebSocket connection closed');
    });

    // Connection error
    socket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
      setConnectionStatus('error');
    });

    // Clean up on unmount
    return () => {
      socket.close();
    };
  }, [path]);

  // Send message function
  const sendMessage = (message: string | object) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      if (typeof message === 'string') {
        socketRef.current.send(message);
      } else {
        socketRef.current.send(JSON.stringify(message));
      }
    } else {
      console.error('WebSocket not connected');
    }
  };

  return {
    sendMessage,
    lastMessage,
    readyState,
    connectionStatus
  };
}
