import { useState } from 'react';
import { type SensorData } from '../App';

export interface PredictionData {
  timestamps: number[];
  density: number[];
  crowdCount: number[];
  confidence: number[];
}

export function usePrediction(currentData: SensorData | null) {
  const [predictionData, setPredictionData] = useState<PredictionData | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Generate a prediction based on current data
  const generatePrediction = async () => {
    if (!currentData) return null;

    setIsGenerating(true);
    
    try {
      // Get historical data - last 10 hours
      const historyResponse = await fetch('/api/sensor/history/10');
      const historyData = await historyResponse.json();

      // Prepare the sensor reading from current data
      const sensorReading = {
        eco2: currentData.eco2,
        tvoc: currentData.tvoc,
        etoh: currentData.etoh,
        iaq: currentData.iaq
      };
      
      // Call our enhanced prediction endpoint
      const response = await fetch('/api/prediction/enhanced', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          historicalData: historyData,
          currentReading: sensorReading,
          minutesAhead: 20
        })
      });
      
      if (!response.ok) {
        throw new Error(`Prediction API error: ${response.status}`);
      }
      
      const prediction = await response.json();
      
      setPredictionData(prediction);
      setIsGenerating(false);
      
      return prediction;
    } catch (error) {
      console.error('Error generating prediction:', error);
      
      // Fallback to simple prediction if advanced model fails
      try {
        // Create arrays for prediction
        const timestamps: number[] = [];
        const densityValues: number[] = [];
        const crowdCountValues: number[] = [];
        const confidenceValues: number[] = [];
        
        // Current values
        let currentDensity = parseFloat(currentData.density);
        let currentCrowdCount = currentData.crowdCount;
        const now = new Date();
        
        // Generate prediction for each minute
        for (let i = 0; i <= 20; i++) {
          // Add current timestamp
          const timestamp = now.getTime() + i * 60 * 1000;
          timestamps.push(timestamp);
          
          // Add current values
          densityValues.push(currentDensity);
          crowdCountValues.push(currentCrowdCount);
          
          // Calculate confidence (decreases with time)
          const confidence = Math.max(0.5, 1 - (i / 40));
          confidenceValues.push(confidence);
          
          // Update values for next minute with simple factors
          const randomFactor = (Math.random() - 0.5) * 0.03;
          currentDensity = Math.max(0, Math.min(1.5, currentDensity + randomFactor));
          currentCrowdCount = Math.round(currentDensity * 350);
        }
        
        const fallbackPrediction = {
          timestamps,
          density: densityValues,
          crowdCount: crowdCountValues,
          confidence: confidenceValues
        };
        
        setPredictionData(fallbackPrediction);
        return fallbackPrediction;
      } finally {
        setIsGenerating(false);
      }
    }
  };
  
  return {
    predictionData,
    isGenerating,
    generatePrediction
  };
}
