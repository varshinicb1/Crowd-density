/**
 * Sensor Data Processing Utilities
 * This file contains functions for processing sensor data
 */

export interface SensorReading {
  eco2: number;
  tvoc: number;
  etoh: number;
  iaq: number;
}

export interface ProcessedData {
  eco2: number;
  tvoc: number;
  etoh: number;
  iaq: number;
  density: number;
  crowdCount: number;
  timestamp: number;
}

export interface HistoricalData {
  timestamps: number[];
  eco2: number[];
  tvoc: number[];
  etoh: number[];
  iaq: number[];
  density: number[];
  crowdCount: number[];
}

/**
 * Normalize a value between 0 and 1
 * @param value - The value to normalize
 * @param min - The minimum value
 * @param max - The maximum value
 * @returns The normalized value
 */
export function normalizeValue(value: number, min: number, max: number): number {
  // Clamp value between min and max
  const clampedValue = Math.max(min, Math.min(max, value));
  
  // Normalize to 0-1 range
  return (clampedValue - min) / (max - min);
}

/**
 * Process sensor data to calculate crowd density
 * @param data - The sensor data
 * @returns The processed data
 */
export function processSensorData(data: SensorReading, timestamp: number = Date.now()): ProcessedData {
  // Extract values
  const { eco2, tvoc, etoh, iaq } = data;
  
  // Calculate crowd density using the algorithm from the provided code
  // Normalize values
  const normalizedEco2 = normalizeValue(eco2, 400, 2000);
  const normalizedTvoc = normalizeValue(tvoc, 0, 1000);
  const normalizedEtoh = normalizeValue(etoh, 0, 1000);
  const normalizedIaq = normalizeValue(iaq, 0, 500);
  
  // Calculate crowd density (weighted average)
  const density = (
    normalizedEco2 * 0.4 +
    normalizedTvoc * 0.3 +
    normalizedEtoh * 0.2 +
    normalizedIaq * 0.1
  );
  
  // Estimate crowd count based on density
  const crowdCount = Math.round(density * 350);
  
  return {
    eco2,
    tvoc,
    etoh,
    iaq,
    density,
    crowdCount,
    timestamp
  };
}

/**
 * Format date for display in Indian Standard Time (IST)
 * @param date - The date to format
 * @returns Formatted date string in IST
 */
export function formatDate(date: Date): string {
  // Format in Indian Standard Time (IST)
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  };
  
  return new Intl.DateTimeFormat('en-IN', options).format(date);
}

/**
 * Format full date and time for display in Indian Standard Time (IST)
 * @param date - The date to format
 * @returns Formatted date and time string in IST
 */
export function formatFullDate(date: Date): string {
  // Format in Indian Standard Time (IST)
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  };
  
  return new Intl.DateTimeFormat('en-IN', options).format(date);
}

/**
 * Format time ago
 * @param date - The date to format
 * @returns Time ago string (e.g. "2 minutes ago")
 */
export function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
  
  if (seconds < 60) {
    return 'just now';
  }
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  }
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  }
  
  const days = Math.floor(hours / 24);
  return `${days} day${days > 1 ? 's' : ''} ago`;
}

/**
 * Determine density status
 * @param density - The density value
 * @param criticalThreshold - The critical threshold
 * @param highThreshold - The high threshold
 * @returns Status object with class and text
 */
export function getDensityStatus(
  density: number, 
  criticalThreshold: number = 1.0, 
  highThreshold: number = 0.7
): { class: string; text: string } {
  if (density >= criticalThreshold) {
    return { class: 'status-critical', text: 'Critical' };
  } else if (density >= highThreshold) {
    return { class: 'status-high', text: 'High' };
  } else if (density >= 0.3) {
    return { class: 'status-medium', text: 'Medium' };
  } else {
    return { class: 'status-low', text: 'Low' };
  }
}

/**
 * Generate time labels for charts
 * @param count - Number of labels to generate
 * @param offset - Offset in minutes (negative for past, positive for future)
 * @returns Array of time labels
 */
export function generateTimeLabels(count: number, offset: number = 0): string[] {
  const labels = [];
  
  for (let i = 0; i < count; i++) {
    if (i === 0 && offset === 0) {
      labels.push('Now');
    } else {
      const value = i + offset;
      if (value === 0) {
        labels.push('Now');
      } else if (value > 0) {
        labels.push(`+${value} min`);
      } else {
        labels.push(`${value} min`);
      }
    }
  }
  
  return labels;
}
