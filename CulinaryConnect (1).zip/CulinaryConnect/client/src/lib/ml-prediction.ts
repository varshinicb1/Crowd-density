/**
 * Advanced Prediction Service for Crowd Density
 * Uses historical patterns and current trends to predict future crowd density
 */

import { ProcessedData, HistoricalData } from './sensor-utils';

export interface PredictionPoint {
  timestamp: number;
  density: number;
  crowdCount: number;
  confidence: number;
}

export interface PredictionResult {
  points: PredictionPoint[];
  avgConfidence: number;
  peakIndex: number;
  peakDensity: number;
  peakCrowdCount: number;
}

/**
 * Seasonal patterns for different times of day
 * These coefficients simulate known crowd patterns throughout the day
 */
const HOURLY_PATTERNS: Record<number, number> = {
  0: 0.2,  // Midnight
  1: 0.15,
  2: 0.1,
  3: 0.1,
  4: 0.15,
  5: 0.3,  // Early morning
  6: 0.4,
  7: 0.6,  // Morning commute
  8: 0.8,
  9: 0.9,  // Morning peak
  10: 0.85,
  11: 0.8,
  12: 0.9,  // Lunch time
  13: 0.85,
  14: 0.7,
  15: 0.75,
  16: 0.8,
  17: 0.95, // Evening commute
  18: 1.0,  // Evening peak
  19: 0.9,
  20: 0.7,
  21: 0.5,
  22: 0.4,
  23: 0.3,
};

/**
 * Day of week patterns
 */
const DAY_PATTERNS: Record<number, number> = {
  0: 0.6,  // Sunday
  1: 0.9,  // Monday
  2: 0.95, // Tuesday
  3: 1.0,  // Wednesday
  4: 0.95, // Thursday
  5: 0.9,  // Friday
  6: 0.7,  // Saturday
};

/**
 * Predict future density values based on current and historical data
 * @param currentData Current sensor reading
 * @param historicalData Optional historical data for better predictions
 * @param minutes Minutes into the future to predict
 * @returns Prediction result with points, confidence, and peak information
 */
export function predictFutureDensity(
  currentData: ProcessedData,
  historicalData?: HistoricalData,
  minutes: number = 20
): PredictionResult {
  const points: PredictionPoint[] = [];
  const now = new Date();
  
  // Current values
  const currentDensity = currentData.density;
  const currentCrowdCount = currentData.crowdCount;
  
  // Calculate trend from historical data if available
  let trend = 0.005; // Small upward trend by default
  
  if (historicalData && historicalData.density.length > 3) {
    // Calculate trend based on last 3 data points
    const recentDensities = historicalData.density.slice(-3);
    if (recentDensities.length >= 2) {
      trend = (recentDensities[recentDensities.length - 1] - recentDensities[0]) / (recentDensities.length - 1);
      
      // Limit extreme trends
      trend = Math.max(-0.05, Math.min(0.05, trend));
    }
  }
  
  // Store peak information
  let peakIndex = 0;
  let peakDensity = currentDensity;
  
  // Generate predictions
  for (let i = 0; i < minutes; i++) {
    const predictionTime = new Date(now.getTime() + i * 60 * 1000);
    const hour = predictionTime.getHours();
    const day = predictionTime.getDay();
    
    // Get time-based seasonal factors
    const hourlyFactor = HOURLY_PATTERNS[hour] || 0.5;
    const dayFactor = DAY_PATTERNS[day] || 0.8;
    
    // Complex prediction formula
    let predictedDensity = currentDensity;
    
    // Apply trend (linear component)
    predictedDensity += trend * i;
    
    // Apply time-based patterns (seasonal component)
    const timeInfluence = 0.02 * i; // Increases influence of time patterns over longer predictions
    predictedDensity = predictedDensity * (1 - timeInfluence) + (hourlyFactor * dayFactor) * timeInfluence;
    
    // Add some controlled randomness (stochastic component)
    const noiseLevel = 0.01 * (i + 1); // Noise increases with prediction distance
    const noise = (Math.random() * 2 - 1) * noiseLevel;
    predictedDensity += noise;
    
    // Ensure value stays within bounds [0, 1]
    predictedDensity = Math.max(0, Math.min(1, predictedDensity));
    
    // Calculate crowd count based on density
    const predictedCrowdCount = Math.round(predictedDensity * 350);
    
    // Calculate confidence (decreases over time)
    const confidence = Math.max(0.5, 1 - (i * 0.025));
    
    // Create prediction point
    const point: PredictionPoint = {
      timestamp: predictionTime.getTime(),
      density: predictedDensity,
      crowdCount: predictedCrowdCount,
      confidence
    };
    
    points.push(point);
    
    // Update peak if this is higher
    if (predictedDensity > peakDensity) {
      peakDensity = predictedDensity;
      peakIndex = i;
    }
  }
  
  // Calculate average confidence
  const avgConfidence = points.reduce((sum, point) => sum + point.confidence, 0) / points.length;
  
  return {
    points,
    avgConfidence,
    peakIndex,
    peakDensity,
    peakCrowdCount: Math.round(peakDensity * 350)
  };
}

/**
 * Generate features from sensor data for prediction models
 * This creates derived features that help with prediction
 */
export function generateFeatures(data: ProcessedData): Record<string, number> {
  return {
    eco2: data.eco2,
    tvoc: data.tvoc,
    etoh: data.etoh,
    iaq: data.iaq,
    eco2_tvoc_ratio: data.eco2 / (data.tvoc || 1),
    hour: new Date(data.timestamp).getHours(),
    day: new Date(data.timestamp).getDay(),
    // More derived features can be added here
  };
}