/**
 * Adafruit IO API Integration
 * This file contains utilities for fetching data from Adafruit IO
 */

// Adafruit IO API base URL
const ADAFRUIT_IO_URL = 'https://io.adafruit.com/api/v2';

// Function to convert UTC time to Indian Standard Time (IST)
export function convertToIST(utcDateString: string): string {
  const date = new Date(utcDateString);
  // IST is UTC+5:30
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  };
  
  return new Intl.DateTimeFormat('en-IN', options).format(date);
}

// Feed data interface
export interface FeedData {
  id: string;
  value: string;
  feed_id: number;
  feed_key: string;
  created_at: string;
  expiration: string;
  created_at_ist?: string; // Indian Standard Time formatted date
}

/**
 * Fetch latest data from a specific Adafruit IO feed
 * @param username - The Adafruit IO username
 * @param feed - The feed name
 * @param key - The Adafruit IO key
 * @returns The feed data
 */
export async function fetchFeedData(username: string, feed: string, key: string): Promise<FeedData> {
  const url = `${ADAFRUIT_IO_URL}/${username}/feeds/${feed}/data/last`;
  const response = await fetch(url, {
    headers: {
      'X-AIO-Key': key
    }
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  const data = await response.json();
  
  // Add IST formatted created_at timestamp
  if (data.created_at) {
    data.created_at_ist = convertToIST(data.created_at);
  }
  
  return data;
}

/**
 * Fetch historical data from a specific Adafruit IO feed
 * @param username - The Adafruit IO username
 * @param feed - The feed name
 * @param key - The Adafruit IO key
 * @param start - The start time (ISO string)
 * @param end - The end time (ISO string)
 * @returns The feed history data
 */
export async function fetchFeedHistory(
  username: string, 
  feed: string, 
  key: string, 
  start: string, 
  end: string
): Promise<FeedData[]> {
  const url = `${ADAFRUIT_IO_URL}/${username}/feeds/${feed}/data?start_time=${start}&end_time=${end}`;
  const response = await fetch(url, {
    headers: {
      'X-AIO-Key': key
    }
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  const dataArray = await response.json();
  
  // Add IST formatted timestamps for each data point
  return dataArray.map((data: FeedData) => {
    if (data.created_at) {
      data.created_at_ist = convertToIST(data.created_at);
    }
    return data;
  });
}

/**
 * Test connection to Adafruit IO
 * @param username - The Adafruit IO username
 * @param key - The Adafruit IO key
 * @returns Whether the connection was successful
 */
export async function testAdafruitConnection(username: string, key: string): Promise<boolean> {
  try {
    const url = `${ADAFRUIT_IO_URL}/${username}/dashboards`;
    const response = await fetch(url, {
      headers: {
        'X-AIO-Key': key
      }
    });
    
    return response.ok;
  } catch (error) {
    console.error('Error testing Adafruit IO connection:', error);
    return false;
  }
}
