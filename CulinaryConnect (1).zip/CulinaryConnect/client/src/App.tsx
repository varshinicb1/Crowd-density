import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { useState, useEffect } from "react";
import Home from "@/pages/home";
import NotFound from "@/pages/not-found";
import { useWebSocket } from "@/hooks/use-websocket";

// Types
export interface SensorData {
  eco2: number;
  tvoc: number;
  etoh: number;
  iaq: number;
  density: string;
  crowdCount: number;
  id?: number;
  timestamp?: Date;
}

export interface PredictionData {
  timestamps: number[];
  density: number[];
  crowdCount: number[];
  confidence: number[];
}

export interface Alert {
  id: number;
  timestamp: Date;
  alertType: 'critical' | 'high' | 'prediction';
  message: string;
  details: Record<string, any>;
  acknowledged: boolean;
}

export interface AppSettings {
  critical_threshold: string;
  high_threshold: string;
  medium_threshold: string;
  low_threshold: string;
  enable_sound: boolean;
  enable_browser: boolean;
  enable_email: boolean;
  email_address: string | null;
  enable_sms: boolean;
  phone_number: string | null;
  sms_critical: boolean;
  sms_high: boolean;
  sms_medium: boolean;
  sms_low: boolean;
  refresh_interval: number;
  prediction_interval: number;
  adafruit_username: string;
  adafruit_key: string;
  eco2_feed: string;
  tvoc_feed: string;
  etoh_feed: string;
  iaq_feed: string;
}

export interface AppState {
  currentData: SensorData | null;
  predictionData: PredictionData | null;
  alertHistory: Alert[];
  settings: AppSettings;
  lastUpdated: Date | null;
  connectionStatus: 'connected' | 'connecting' | 'error';
}

// Default settings
const defaultSettings: AppSettings = {
  critical_threshold: "1.0",
  high_threshold: "0.7",
  medium_threshold: "0.5",
  low_threshold: "0.3",
  enable_sound: true,
  enable_browser: true,
  enable_email: false,
  email_address: "",
  enable_sms: false,
  phone_number: "",
  sms_critical: true,
  sms_high: true,
  sms_medium: false,
  sms_low: false,
  refresh_interval: 30,
  prediction_interval: 300,
  adafruit_username: "varshinicb99",
  adafruit_key: "aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe",
  eco2_feed: "eCO2",
  tvoc_feed: "tvoc",
  etoh_feed: "EtOH",
  iaq_feed: "indoor-aqi"
};

// Create context for app state
import { createContext } from "react";

export const AppContext = createContext<{
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  fetchSensorData: () => Promise<void>;
  generatePrediction: () => Promise<void>;
  fetchHistoricalData: (period: string) => Promise<any>;
  testAlert: (type: string) => Promise<void>;
}>({
  state: {
    currentData: null,
    predictionData: null,
    alertHistory: [],
    settings: defaultSettings,
    lastUpdated: null,
    connectionStatus: 'connecting'
  },
  setState: () => {},
  fetchSensorData: async () => {},
  generatePrediction: async () => {},
  fetchHistoricalData: async () => ({}),
  testAlert: async () => {}
});

function App() {
  const [state, setState] = useState<AppState>({
    currentData: null,
    predictionData: null,
    alertHistory: [],
    settings: defaultSettings,
    lastUpdated: null,
    connectionStatus: 'connecting'
  });

  // Initialize WebSocket connection
  const { lastMessage } = useWebSocket('/ws');

  // Handle incoming WebSocket messages
  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage.data);
        
        if (data.type === 'sensor_data') {
          setState(prev => ({
            ...prev,
            currentData: data.data,
            lastUpdated: new Date(),
            connectionStatus: 'connected'
          }));
        } else if (data.type === 'alert') {
          // Add new alert to history
          setState(prev => ({
            ...prev,
            alertHistory: [data.data, ...prev.alertHistory]
          }));
          
          // Show notification if enabled
          if (state.settings.enable_browser) {
            showNotification(data.data);
          }
          
          // Play sound if enabled
          if (state.settings.enable_sound) {
            playAlertSound(data.data.alertType);
          }
        }
      } catch (error) {
        console.error("Failed to parse WebSocket message:", error);
      }
    }
  }, [lastMessage]);

  // Fetch initial data
  useEffect(() => {
    const initialize = async () => {
      try {
        // Fetch settings
        const settingsResponse = await fetch('/api/settings');
        if (settingsResponse.ok) {
          const settings = await settingsResponse.json();
          setState(prev => ({ ...prev, settings }));
        }
        
        // Fetch alerts
        const alertsResponse = await fetch('/api/alerts');
        if (alertsResponse.ok) {
          const alerts = await alertsResponse.json();
          setState(prev => ({ ...prev, alertHistory: alerts }));
        }
        
        // Fetch sensor data
        await fetchSensorData();
        
        // Generate initial prediction
        await generatePrediction();
        
        // Request notification permission
        if (state.settings.enable_browser) {
          requestNotificationPermission();
        }
      } catch (error) {
        console.error("Failed to initialize app:", error);
        setState(prev => ({ ...prev, connectionStatus: 'error' }));
      }
    };
    
    initialize();
    
    // Set up polling intervals
    const dataInterval = setInterval(() => {
      fetchSensorData();
    }, state.settings.refresh_interval * 1000);
    
    const predictionInterval = setInterval(() => {
      generatePrediction();
    }, state.settings.prediction_interval * 1000);
    
    return () => {
      clearInterval(dataInterval);
      clearInterval(predictionInterval);
    };
  }, []);

  // Fetch sensor data
  const fetchSensorData = async () => {
    try {
      setState(prev => ({ ...prev, connectionStatus: 'connecting' }));
      
      const response = await fetch('/api/adafruit/fetch');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      setState(prev => ({
        ...prev,
        currentData: data,
        lastUpdated: new Date(),
        connectionStatus: 'connected'
      }));
    } catch (error) {
      console.error("Failed to fetch sensor data:", error);
      setState(prev => ({ ...prev, connectionStatus: 'error' }));
    }
  };

  // Generate prediction
  const generatePrediction = async () => {
    try {
      if (!state.currentData) return;
      
      // In a real app, this would call an API endpoint
      // For now, we'll simulate a prediction based on current data
      
      // Create arrays for prediction
      const timestamps: number[] = [];
      const densityValues: number[] = [];
      const crowdCountValues: number[] = [];
      const confidenceValues: number[] = [];
      
      // Current values
      let currentDensity = parseFloat(state.currentData.density);
      let currentCrowdCount = state.currentData.crowdCount;
      const now = new Date();
      
      // Generate prediction for each minute
      for (let i = 0; i <= 20; i++) {
        // Add current timestamp
        const timestamp = now.getTime() + i * 60 * 1000;
        timestamps.push(timestamp);
        
        // Add current values
        densityValues.push(currentDensity);
        crowdCountValues.push(currentCrowdCount);
        
        // Calculate confidence (decreases with time)
        const confidence = Math.max(0.5, 1 - (i / 40));
        confidenceValues.push(confidence);
        
        // Update values for next minute
        // Time-based factors (simulating typical crowd patterns)
        const hourOfDay = (now.getHours() + Math.floor(i / 60)) % 24;
        const minuteOfHour = (now.getMinutes() + i % 60) % 60;
        
        // Simulate peak hours
        const isPeakHour = (hourOfDay >= 8 && hourOfDay <= 10) || 
                           (hourOfDay >= 12 && hourOfDay <= 14) || 
                           (hourOfDay >= 17 && hourOfDay <= 19);
        
        // Simulate random fluctuations
        const randomFactor = (Math.random() - 0.5) * 0.05;
        
        // Calculate density change
        let densityChange = randomFactor;
        
        if (isPeakHour) {
          // During peak hours, density tends to increase
          densityChange += 0.02;
        } else {
          // During off-peak hours, density tends to decrease
          densityChange -= 0.01;
        }
        
        // Apply change
        currentDensity = Math.max(0, Math.min(1.5, currentDensity + densityChange));
        
        // Update crowd count based on density
        currentCrowdCount = Math.round(currentDensity * 350);
      }
      
      setState(prev => ({
        ...prev,
        predictionData: {
          timestamps,
          density: densityValues,
          crowdCount: crowdCountValues,
          confidence: confidenceValues
        }
      }));
    } catch (error) {
      console.error("Failed to generate prediction:", error);
    }
  };

  // Fetch historical data
  const fetchHistoricalData = async (period: string) => {
    try {
      const response = await fetch(`/api/adafruit/history/${period}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error("Failed to fetch historical data:", error);
      return null;
    }
  };

  // Test alert
  const testAlert = async (type: string) => {
    try {
      let alertData;
      const now = new Date();
      
      if (!state.currentData) return;
      
      switch (type) {
        case 'critical':
          alertData = {
            alertType: 'critical',
            message: `Test Critical Alert: Density reached ${(parseFloat(state.currentData.density) + 0.3).toFixed(2)} (critical threshold)`,
            details: { 
              ...state.currentData, 
              density: (parseFloat(state.currentData.density) + 0.3).toString(),
              timestamp: now 
            }
          };
          break;
        case 'high':
          alertData = {
            alertType: 'high',
            message: `Test High Alert: Density reached ${(parseFloat(state.currentData.density) + 0.2).toFixed(2)} (high threshold)`,
            details: { 
              ...state.currentData, 
              density: (parseFloat(state.currentData.density) + 0.2).toString(),
              timestamp: now 
            }
          };
          break;
        case 'prediction':
          alertData = {
            alertType: 'prediction',
            message: `Test Prediction Alert: Critical density predicted in 15 minutes (confidence: 82%)`,
            details: { 
              timestamp: now, 
              confidence: 0.82,
              predictedDensity: 1.05,
              timeToEvent: '15 minutes'
            }
          };
          break;
        default:
          return;
      }
      
      const response = await fetch('/api/alerts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(alertData)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const alert = await response.json();
      
      // Add to alert history
      setState(prev => ({
        ...prev,
        alertHistory: [alert, ...prev.alertHistory]
      }));
      
      // Show notification if enabled
      if (state.settings.enable_browser) {
        showNotification(alert);
      }
      
      // Play sound if enabled
      if (state.settings.enable_sound) {
        playAlertSound(type);
      }
    } catch (error) {
      console.error("Failed to create test alert:", error);
    }
  };

  // Request notification permission
  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      console.log("This browser does not support desktop notification");
      return;
    }
    
    if (Notification.permission !== "granted") {
      await Notification.requestPermission();
    }
  };

  // Show notification
  const showNotification = (alert: Alert) => {
    if (Notification.permission !== "granted") return;
    
    let title = "Crowd Monitoring Alert";
    let options: NotificationOptions = {
      body: alert.message,
      icon: "/favicon.ico"
    };
    
    switch (alert.alertType) {
      case 'critical':
        title = "CRITICAL ALERT";
        break;
      case 'high':
        title = "High Density Warning";
        break;
      case 'prediction':
        title = "Prediction Alert";
        break;
    }
    
    new Notification(title, options);
  };

  // Play alert sound
  const playAlertSound = (type: string) => {
    let sound: HTMLAudioElement;
    
    switch (type) {
      case 'critical':
        sound = new Audio('https://cdn.freesound.org/previews/250/250629_4486188-lq.mp3');
        break;
      case 'high':
        sound = new Audio('https://cdn.freesound.org/previews/263/263133_4486188-lq.mp3');
        break;
      case 'prediction':
        sound = new Audio('https://cdn.freesound.org/previews/403/403013_5121236-lq.mp3');
        break;
      default:
        sound = new Audio('https://cdn.freesound.org/previews/263/263133_4486188-lq.mp3');
    }
    
    sound.play().catch(e => console.error("Failed to play alert sound:", e));
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AppContext.Provider value={{ 
        state, 
        setState, 
        fetchSensorData, 
        generatePrediction, 
        fetchHistoricalData,
        testAlert 
      }}>
        <Switch>
          <Route path="/" component={Home}/>
          <Route path="/dashboard" component={Home}/>
          <Route path="/monitoring" component={Home}/>
          <Route path="/prediction" component={Home}/>
          <Route path="/alerts" component={Home}/>
          <Route path="/settings" component={Home}/>
          <Route component={NotFound} />
        </Switch>
        <Toaster />
      </AppContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
