import React, { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import MainLayout from '../components/layouts/MainLayout';
import DashboardPage from '../components/dashboard/DashboardPage';
import MonitoringPage from '../components/monitoring/MonitoringPage';
import PredictionPage from '../components/prediction/PredictionPage';
import AlertsPage from '../components/alerts/AlertsPage';
import SettingsPage from '../components/settings/SettingsPage';

const Home: React.FC = () => {
  const [location, setLocation] = useLocation();
  const [currentPage, setCurrentPage] = useState('dashboard');
  
  // Set current page based on URL hash
  useEffect(() => {
    const route = location.substring(1);
    if (route) {
      setCurrentPage(route);
    } else {
      setLocation('/dashboard');
    }
  }, [location, setLocation]);
  
  // Render the correct page based on the current route
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'monitoring':
        return <MonitoringPage />;
      case 'prediction':
        return <PredictionPage />;
      case 'alerts':
        return <AlertsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };
  
  return (
    <MainLayout>
      {renderPage()}
    </MainLayout>
  );
};

export default Home;
