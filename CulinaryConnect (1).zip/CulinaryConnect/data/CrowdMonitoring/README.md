# Crowd Monitoring App - Final Report

## Overview
This document provides a comprehensive overview of the Crowd Monitoring Android application developed for Renesas. The app utilizes data from the Renesas zmod4410 sensor to monitor crowd density, provide alerts, and predict future crowd levels.

## Features Implemented

### Data Integration
- Successfully integrated with Adafruit IO using the provided credentials
- Implemented data fetching from four sensor feeds:
  - eCO2 (Carbon Dioxide)
  - TVOC (Total Volatile Organic Compounds)
  - EtOH (Ethanol)
  - IAQ (Indoor Air Quality)
- Created a robust data normalization system based on the provided ranges

### Crowd Density Monitoring
- Implemented real-time crowd density calculation using sensor data
- Created classification system for Low, Medium, High, and Critical density levels
- Added crowd count estimation based on density values
- Developed real-time graphing of crowd density trends

### Advanced Prediction System
- Implemented LSTM (Long Short-Term Memory) model for crowd density prediction
- Enabled 20-minute future predictions with confidence levels
- Created a prediction visualization system
- Added capability for model training with historical data

### Comprehensive Notification System
- Implemented Firebase Cloud Messaging for push notifications
- Added Twilio integration for SMS alerts
- Created in-app alarm system with sound and vibration
- Developed a critical alert screen with visual warnings

### Modern UI with Sci-Fi Dark Theme
- Implemented a sci-fi dark theme with the specified color palette:
  - Deep Space Blue (#1A1B4B)
  - Cosmic Purple (#4E11A8)
  - Neon Cyan (#00E5FF)
  - Dark Matter background (#121212)
- Used modern Jetpack Compose for all UI components
- Created responsive layouts for all screens
- Implemented custom typography with futuristic fonts

### App Screens
- Dashboard: Main overview with current status and quick stats
- Monitoring: Detailed view with real-time graphs and sensor readings
- Prediction: Future crowd density forecasts for the next 20 minutes
- Alarm: Critical alert screen with warning sounds
- Settings: Configuration options for notifications and thresholds

## Technical Implementation

### Architecture
- MVVM (Model-View-ViewModel) architecture
- Repository pattern for data management
- Clean separation of concerns between data, domain, and UI layers

### Technologies Used
- Kotlin programming language
- Jetpack Compose for modern UI
- Room database for local storage
- Retrofit for API communication
- WorkManager for background tasks
- TensorFlow Lite for ML model
- Firebase for push notifications
- Twilio for SMS alerts

## Building and Running the App

### Requirements
- Android Studio Arctic Fox or newer
- Android SDK 31 or higher
- Gradle 7.0 or higher

### Configuration
- The app is pre-configured with the provided Adafruit IO credentials
- Firebase configuration is included for push notifications
- Twilio credentials can be entered in the Settings screen

### Building the APK
1. Open the project in Android Studio
2. Select Build > Build Bundle(s) / APK(s) > Build APK(s)
3. The APK will be generated in app/build/outputs/apk/debug/

## Future Enhancements
- User authentication system
- Cloud-based data storage
- Enhanced prediction algorithms
- Integration with building management systems
- Augmented reality visualization of crowd density

## Credits
- App Developer: Varshini CB
- Company: Renesas
