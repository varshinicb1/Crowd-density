package com.renesas.crowdmonitoring.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.renesas.crowdmonitoring.data.CrowdMonitoringRepository
import com.renesas.crowdmonitoring.data.ProcessedSensorData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * ViewModel for the Monitoring screen
 */
class MonitoringViewModel(
    private val context: Context
) : ViewModel() {

    private val repository = CrowdMonitoringRepository(context)
    
    // UI state
    private val _uiState = MutableStateFlow(MonitoringUiState())
    val uiState: StateFlow<MonitoringUiState> = _uiState.asStateFlow()
    
    init {
        // Load sensor readings
        loadSensorReadings()
    }
    
    /**
     * Loads recent sensor readings from the repository
     */
    private fun loadSensorReadings() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isLoading = true)
                
                val readings = repository.getRecentSensorReadings(60).first()
                
                _uiState.value = MonitoringUiState(
                    isLoading = false,
                    sensorReadings = readings,
                    error = null
                )
            } catch (e: Exception) {
                _uiState.value = MonitoringUiState(
                    isLoading = false,
                    sensorReadings = emptyList(),
                    error = "Error loading sensor readings: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Refreshes sensor data
     */
    fun refreshData() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(
                    isLoading = true,
                    error = null
                )
                
                // Fetch latest data
                val result = repository.fetchLatestSensorData()
                
                if (result.isSuccess) {
                    // Reload readings
                    val readings = repository.getRecentSensorReadings(60).first()
                    
                    _uiState.value = MonitoringUiState(
                        isLoading = false,
                        sensorReadings = readings,
                        error = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = "Failed to fetch latest data: ${result.exceptionOrNull()?.message}"
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Error refreshing data: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Factory for creating MonitoringViewModel instances
     */
    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MonitoringViewModel::class.java)) {
                return MonitoringViewModel(context) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

/**
 * Data class representing the UI state for the monitoring screen
 */
data class MonitoringUiState(
    val isLoading: Boolean = true,
    val sensorReadings: List<ProcessedSensorData> = emptyList(),
    val error: String? = null
)
