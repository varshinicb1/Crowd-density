package com.renesas.crowdmonitoring.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.renesas.crowdmonitoring.ml.MonitoringStatus
import kotlinx.coroutines.tasks.await

/**
 * Manager class for handling push notifications
 */
class NotificationManager(private val context: Context) {

    companion object {
        private const val CHANNEL_ID_ALERTS = "crowd_alerts"
        private const val CHANNEL_ID_CRITICAL = "crowd_critical"
        private const val NOTIFICATION_ID_HIGH = 1001
        private const val NOTIFICATION_ID_CRITICAL = 1002
        private const val NOTIFICATION_ID_PREDICTION = 1003
        
        // FCM topics
        private const val TOPIC_CROWD_ALERTS = "crowd_alerts"
        private const val TOPIC_CRITICAL_ALERTS = "critical_alerts"
    }
    
    init {
        createNotificationChannels()
        subscribeToTopics()
    }
    
    /**
     * Creates notification channels for Android O and above
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Alert channel (high priority)
            val alertChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                "Crowd Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for high crowd density"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
            }
            
            // Critical channel (max priority with sound)
            val criticalChannel = NotificationChannel(
                CHANNEL_ID_CRITICAL,
                "Critical Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for critical crowd density"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)
                
                // Set alarm sound
                val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build()
                setSound(alarmSound, audioAttributes)
            }
            
            // Register channels
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(alertChannel)
            notificationManager.createNotificationChannel(criticalChannel)
        }
    }
    
    /**
     * Subscribes to FCM topics for receiving push notifications
     */
    private fun subscribeToTopics() {
        FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_CROWD_ALERTS)
        FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_CRITICAL_ALERTS)
    }
    
    /**
     * Shows a notification for high crowd density
     */
    fun showHighDensityNotification(status: MonitoringStatus) {
        val title = "High Crowd Density Alert"
        val message = "Current crowd density is high (${status.estimatedCrowdCount} people). " +
                "Consider crowd management measures."
        
        val intent = createMainActivityIntent()
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_HIGH, notification)
    }
    
    /**
     * Shows a notification for critical crowd density
     */
    fun showCriticalDensityNotification(status: MonitoringStatus) {
        val title = "CRITICAL CROWD DENSITY ALERT"
        val message = "Current crowd density has reached CRITICAL levels (${status.estimatedCrowdCount} people). " +
                "Immediate action required to reduce occupancy!"
        
        val intent = createAlarmActivityIntent()
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID_CRITICAL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pendingIntent)
            .setAutoCancel(false)
            .setOngoing(true)
            .build()
        
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_CRITICAL, notification)
    }
    
    /**
     * Shows a notification for predicted critical crowd density
     */
    fun showPredictedCriticalNotification(status: MonitoringStatus) {
        val timeUntilCritical = status.timeUntilCritical ?: 0
        val title = "Crowd Density Warning"
        val message = "Critical crowd density predicted in $timeUntilCritical minutes. " +
                "Prepare crowd management measures."
        
        val intent = createMainActivityIntent()
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_PREDICTION, notification)
    }
    
    /**
     * Cancels all active notifications
     */
    fun cancelAllNotifications() {
        NotificationManagerCompat.from(context).cancelAll()
    }
    
    /**
     * Creates an intent to launch the main activity
     */
    private fun createMainActivityIntent(): Intent {
        // In a real app, we would use the actual MainActivity class
        return Intent().apply {
            setClassName(context.packageName, "${context.packageName}.ui.MainActivity")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
    }
    
    /**
     * Creates an intent to launch the alarm activity
     */
    private fun createAlarmActivityIntent(): Intent {
        // In a real app, we would use the actual AlarmActivity class
        return Intent().apply {
            setClassName(context.packageName, "${context.packageName}.ui.AlarmActivity")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
    }
    
    /**
     * Gets the FCM token for this device
     */
    suspend fun getFcmToken(): String? {
        return try {
            FirebaseMessaging.getInstance().token.await()
        } catch (e: Exception) {
            null
        }
    }
}
