package com.renesas.crowdmonitoring.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.renesas.crowdmonitoring.data.CrowdPrediction
import com.renesas.crowdmonitoring.ui.theme.CrowdMonitoringTheme
import java.text.SimpleDateFormat
import java.util.*

/**
 * Activity for the Prediction screen
 */
class PredictionActivity : ComponentActivity() {
    
    private lateinit var viewModel: PredictionViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize ViewModel
        viewModel = ViewModelProvider(
            this,
            PredictionViewModel.Factory(applicationContext)
        )[PredictionViewModel::class.java]
        
        setContent {
            CrowdMonitoringTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PredictionScreen(viewModel)
                }
            }
        }
    }
}

/**
 * Prediction screen composable
 */
@Composable
fun PredictionScreen(viewModel: PredictionViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Screen header
        Text(
            text = "Crowd Density Prediction",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.padding(bottom = 24.dp)
        )
        
        // Prediction summary card
        PredictionSummaryCard(uiState)
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Prediction list
        Text(
            text = "Next 20 Minutes Forecast",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.tertiary)
            }
        } else if (uiState.predictions.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No prediction data available",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(uiState.predictions) { prediction ->
                    PredictionItem(prediction)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Update button
        Button(
            onClick = { viewModel.updatePredictions() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary
            )
        ) {
            Text("Update Predictions")
        }
        
        // Error message if any
        if (uiState.error != null) {
            Text(
                text = uiState.error!!,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

/**
 * Prediction summary card composable
 */
@Composable
fun PredictionSummaryCard(uiState: PredictionUiState) {
    val peakPrediction = uiState.predictions.maxByOrNull { it.predictedDensity }
    val criticalPrediction = uiState.predictions.find { it.predictionLevel == "Critical" }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Prediction Summary",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                if (peakPrediction != null) {
                    Text(
                        text = "Peak Density: ${String.format("%.2f", peakPrediction.predictedDensity)} (${peakPrediction.predictionLevel})",
                        style = MaterialTheme.typography.bodyLarge,
                        color = getPredictionColor(peakPrediction.predictionLevel)
                    )
                    
                    Text(
                        text = "Estimated Peak Count: ${peakPrediction.estimatedCrowdCount} people",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                if (criticalPrediction != null) {
                    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                    val criticalTime = timeFormat.format(Date(criticalPrediction.timestamp))
                    
                    Text(
                        text = "Critical Level Expected at $criticalTime",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "No Critical Levels Expected",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }
    }
}

/**
 * Prediction item composable
 */
@Composable
fun PredictionItem(prediction: CrowdPrediction) {
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val predictionTime = timeFormat.format(Date(prediction.timestamp))
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Time
            Text(
                text = predictionTime,
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.width(60.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Prediction details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = prediction.predictionLevel,
                    style = MaterialTheme.typography.titleMedium,
                    color = getPredictionColor(prediction.predictionLevel)
                )
                
                Text(
                    text = "Density: ${String.format("%.2f", prediction.predictedDensity)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Text(
                    text = "Est. Count: ${prediction.estimatedCrowdCount}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            
            // Confidence
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${(prediction.confidence * 100).toInt()}%",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.tertiary
                )
                
                Text(
                    text = "Confidence",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

/**
 * Helper function to get color based on prediction level
 */
@Composable
fun getPredictionColor(level: String): Color {
    return when (level) {
        "Critical" -> MaterialTheme.colorScheme.error
        "High" -> Color(0xFFFFD600) // Warning Yellow
        "Medium" -> Color(0xFFAEEA00) // Light Green
        else -> MaterialTheme.colorScheme.tertiary
    }
}
