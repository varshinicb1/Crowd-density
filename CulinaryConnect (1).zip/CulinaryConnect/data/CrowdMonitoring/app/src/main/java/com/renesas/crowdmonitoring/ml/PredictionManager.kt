package com.renesas.crowdmonitoring.ml

import android.content.Context
import com.renesas.crowdmonitoring.data.CrowdMonitoringRepository
import com.renesas.crowdmonitoring.data.CrowdPrediction
import com.renesas.crowdmonitoring.data.CrowdPredictionEntity
import com.renesas.crowdmonitoring.data.ProcessedSensorData
import com.renesas.crowdmonitoring.data.SensorDataProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Manager class for handling crowd density predictions
 */
class PredictionManager(private val context: Context) {
    
    private val repository = CrowdMonitoringRepository(context)
    private val predictionModel = CrowdPredictionModel(context)
    private val sensorDataProcessor = SensorDataProcessor()
    
    /**
     * Generates predictions for the next 20 minutes based on historical data
     * @return List of crowd predictions or null if prediction failed
     */
    suspend fun generatePredictions(): List<CrowdPrediction>? = withContext(Dispatchers.Default) {
        try {
            // Get recent sensor readings (at least 60 for the LSTM model)
            val recentReadings = repository.getRecentSensorReadings(120).first()
            
            if (recentReadings.size < 60) {
                // Not enough historical data for prediction
                return@withContext null
            }
            
            // Convert to normalized readings for the model
            val normalizedReadings = recentReadings.map { 
                NormalizedSensorReading(
                    eco2Normalized = it.eco2Normalized,
                    tvocNormalized = it.tvocNormalized,
                    etohNormalized = it.etohNormalized,
                    iaqNormalized = it.iaqNormalized,
                    timestamp = it.rawData.timestamp
                )
            }
            
            // Generate predictions using the LSTM model
            val densityPredictions = predictionModel.predictCrowdDensity(normalizedReadings)
            
            if (densityPredictions.isEmpty()) {
                return@withContext null
            }
            
            // Convert to CrowdPrediction objects
            val crowdPredictions = densityPredictions.map {
                val densityLevel = sensorDataProcessor.classifyCrowdDensity(it.predictedDensity)
                CrowdPrediction(
                    predictedDensity = it.predictedDensity,
                    predictionLevel = densityLevel,
                    confidence = it.confidence,
                    timestamp = it.timestamp,
                    estimatedCrowdCount = calculateCrowdCount(it.predictedDensity)
                )
            }
            
            // Save predictions to database
            savePredictions(crowdPredictions)
            
            return@withContext crowdPredictions
        } catch (e: Exception) {
            // Log error
            return@withContext null
        }
    }
    
    /**
     * Saves predictions to the database
     */
    private suspend fun savePredictions(predictions: List<CrowdPrediction>) = withContext(Dispatchers.IO) {
        val database = com.renesas.crowdmonitoring.data.AppDatabase.getDatabase(context)
        val predictionDao = database.crowdPredictionDao()
        
        // Convert to entities
        val entities = predictions.map {
            CrowdPredictionEntity(
                predictedDensity = it.predictedDensity,
                predictionLevel = it.predictionLevel,
                confidence = it.confidence,
                predictionTimestamp = it.timestamp
            )
        }
        
        // Insert into database
        predictionDao.insertPredictions(entities)
        
        // Clean up old predictions
        val oneDayAgo = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
        predictionDao.deleteOldPredictions(oneDayAgo)
    }
    
    /**
     * Checks if any predictions indicate a critical situation in the near future
     * @return The earliest critical prediction or null if none found
     */
    suspend fun checkForCriticalPredictions(): CrowdPrediction? = withContext(Dispatchers.Default) {
        val predictions = repository.getFuturePredictions().first()
        
        // Find the earliest critical prediction
        return@withContext predictions.find { it.predictionLevel == "Critical" }
    }
    
    /**
     * Calculates estimated crowd count based on density
     */
    private fun calculateCrowdCount(density: Double): Int {
        // Assuming a maximum capacity of 500 people for the venue
        val maxCapacity = 500
        return (density * maxCapacity).toInt()
    }
    
    /**
     * Analyzes current sensor data to determine if crowd density is at a critical level
     * @return True if current density is critical, false otherwise
     */
    suspend fun isCurrentDensityCritical(): Boolean = withContext(Dispatchers.Default) {
        val latestReading = repository.getLatestSensorReading().first()
        return@withContext latestReading?.crowdDensityLevel == "Critical"
    }
    
    /**
     * Analyzes current sensor data to determine if crowd density is at a high level
     * @return True if current density is high, false otherwise
     */
    suspend fun isCurrentDensityHigh(): Boolean = withContext(Dispatchers.Default) {
        val latestReading = repository.getLatestSensorReading().first()
        return@withContext latestReading?.crowdDensityLevel == "High"
    }
    
    /**
     * Gets the current crowd density status
     * @return Current processed sensor data or null if not available
     */
    suspend fun getCurrentStatus(): ProcessedSensorData? = withContext(Dispatchers.Default) {
        return@withContext repository.getLatestSensorReading().first()
    }
}
