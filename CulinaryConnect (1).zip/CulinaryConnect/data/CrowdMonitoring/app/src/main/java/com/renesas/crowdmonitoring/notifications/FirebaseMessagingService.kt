package com.renesas.crowdmonitoring.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Firebase Messaging Service for handling push notifications
 */
class FirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "FirebaseMessagingService"
    }
    
    /**
     * Called when a new token is generated
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM token: $token")
        
        // In a real app, we would send this token to our backend
    }
    
    /**
     * Called when a new message is received
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        
        Log.d(TAG, "From: ${remoteMessage.from}")
        
        // Check if message contains a notification payload
        remoteMessage.notification?.let {
            Log.d(TAG, "Message Notification Body: ${it.body}")
            
            // Process the notification
            processNotification(it.title, it.body)
        }
        
        // Check if message contains data payload
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Message data payload: ${remoteMessage.data}")
            
            // Process the data
            processData(remoteMessage.data)
        }
    }
    
    /**
     * Process notification payload
     */
    private fun processNotification(title: String?, body: String?) {
        // Create and show notification
        val notificationManager = NotificationManager(applicationContext)
        
        // Determine notification type based on title
        when {
            title?.contains("Critical", ignoreCase = true) == true -> {
                // Show critical notification
                val status = createDummyStatus(isCritical = true)
                notificationManager.showCriticalDensityNotification(status)
            }
            title?.contains("High", ignoreCase = true) == true -> {
                // Show high density notification
                val status = createDummyStatus(isHigh = true)
                notificationManager.showHighDensityNotification(status)
            }
            title?.contains("Prediction", ignoreCase = true) == true -> {
                // Show prediction notification
                val status = createDummyStatus(hasCriticalPrediction = true)
                notificationManager.showPredictedCriticalNotification(status)
            }
            else -> {
                // Default notification handling would go here
            }
        }
    }
    
    /**
     * Process data payload
     */
    private fun processData(data: Map<String, String>) {
        // Extract data values
        val densityLevel = data["density_level"]
        val crowdCount = data["crowd_count"]?.toIntOrNull() ?: 0
        
        // Process based on density level
        when (densityLevel) {
            "Critical" -> {
                // Handle critical density
                val status = createDummyStatus(isCritical = true, crowdCount = crowdCount)
                NotificationManager(applicationContext).showCriticalDensityNotification(status)
            }
            "High" -> {
                // Handle high density
                val status = createDummyStatus(isHigh = true, crowdCount = crowdCount)
                NotificationManager(applicationContext).showHighDensityNotification(status)
            }
            // Other cases would be handled here
        }
    }
    
    /**
     * Creates a dummy monitoring status for notification testing
     */
    private fun createDummyStatus(
        isCritical: Boolean = false,
        isHigh: Boolean = false,
        hasCriticalPrediction: Boolean = false,
        crowdCount: Int = 300
    ): com.renesas.crowdmonitoring.ml.MonitoringStatus {
        return com.renesas.crowdmonitoring.ml.MonitoringStatus(
            currentDensityLevel = when {
                isCritical -> "Critical"
                isHigh -> "High"
                else -> "Medium"
            },
            currentDensityValue = when {
                isCritical -> 1.2
                isHigh -> 0.8
                else -> 0.5
            },
            estimatedCrowdCount = crowdCount,
            isCritical = isCritical,
            isHigh = isHigh,
            hasCriticalPrediction = hasCriticalPrediction,
            timeUntilCritical = if (hasCriticalPrediction) 15L else null
        )
    }
}
