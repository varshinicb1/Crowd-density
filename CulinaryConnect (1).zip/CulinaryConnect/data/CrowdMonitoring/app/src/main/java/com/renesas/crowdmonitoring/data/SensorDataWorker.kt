package com.renesas.crowdmonitoring.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Background worker for fetching sensor data from Adafruit IO
 */
class SensorDataWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    private val adafruitIoRepository = AdafruitIoRepository()
    private val sensorDataProcessor = SensorDataProcessor()
    private val database = AppDatabase.getDatabase(context)
    private val sensorReadingDao = database.sensorReadingDao()
    
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            // Fetch sensor data from Adafruit IO
            val sensorDataResult = adafruitIoRepository.getAllSensorData().first()
            
            if (sensorDataResult.isSuccess) {
                val sensorData = sensorDataResult.getOrNull()
                if (sensorData != null) {
                    // Process sensor data
                    val processedData = sensorDataProcessor.processSensorData(sensorData)
                    
                    // Convert to entity and save to database
                    val sensorReadingEntity = sensorDataProcessor.toSensorReadingEntity(processedData)
                    sensorReadingDao.insertSensorReading(sensorReadingEntity)
                    
                    // Clean up old data (keep last 7 days)
                    val sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000)
                    sensorReadingDao.deleteOldReadings(sevenDaysAgo)
                    
                    return@withContext Result.success()
                }
            }
            
            // If we reach here, something went wrong
            return@withContext Result.retry()
        } catch (e: Exception) {
            // Log error
            return@withContext Result.failure()
        }
    }
}
