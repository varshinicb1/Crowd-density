package com.renesas.crowdmonitoring.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Sci-Fi Typography as specified in the UI design document
// In a real app, we would include the actual font files in the resources
// For this implementation, we'll use system fonts

// Define the font families
val exo2 = FontFamily.Default // In a real app: FontFamily(Font(R.font.exo2_regular))
val rajdhani = FontFamily.Default // In a real app: FontFamily(Font(R.font.rajdhani_regular))
val shareTechMono = FontFamily.Monospace // In a real app: FontFamily(Font(R.font.share_tech_mono))

// Set of Material typography styles
val SciFiTypography = Typography(
    // Large titles
    headlineLarge = TextStyle(
        fontFamily = exo2,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp,
        letterSpacing = 0.sp
    ),
    
    // Medium titles
    headlineMedium = TextStyle(
        fontFamily = exo2,
        fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp,
        lineHeight = 36.sp,
        letterSpacing = 0.sp
    ),
    
    // Small titles
    headlineSmall = TextStyle(
        fontFamily = exo2,
        fontWeight = FontWeight.Medium,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.sp
    ),
    
    // Large section titles
    titleLarge = TextStyle(
        fontFamily = rajdhani,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp
    ),
    
    // Medium section titles
    titleMedium = TextStyle(
        fontFamily = rajdhani,
        fontWeight = FontWeight.Medium,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.1.sp
    ),
    
    // Small section titles
    titleSmall = TextStyle(
        fontFamily = rajdhani,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    
    // Body text large
    bodyLarge = TextStyle(
        fontFamily = exo2,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    ),
    
    // Body text medium
    bodyMedium = TextStyle(
        fontFamily = exo2,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp
    ),
    
    // Body text small
    bodySmall = TextStyle(
        fontFamily = exo2,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.4.sp
    ),
    
    // Labels large
    labelLarge = TextStyle(
        fontFamily = rajdhani,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    
    // Labels medium
    labelMedium = TextStyle(
        fontFamily = rajdhani,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    ),
    
    // Labels small
    labelSmall = TextStyle(
        fontFamily = rajdhani,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    ),
    
    // Monospace for data display
    displayLarge = TextStyle(
        fontFamily = shareTechMono,
        fontWeight = FontWeight.Normal,
        fontSize = 20.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp
    ),
    
    // Monospace for data display
    displayMedium = TextStyle(
        fontFamily = shareTechMono,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.sp
    ),
    
    // Monospace for data display
    displaySmall = TextStyle(
        fontFamily = shareTechMono,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.sp
    )
)
