package com.renesas.crowdmonitoring.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.renesas.crowdmonitoring.ui.theme.CrowdMonitoringTheme
import kotlinx.coroutines.delay

/**
 * Activity for the Alarm screen that shows critical alerts
 */
class AlarmActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            CrowdMonitoringTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF4E0000) // Dark red background for alarm
                ) {
                    AlarmScreen(
                        crowdCount = intent.getIntExtra("crowd_count", 0),
                        onAcknowledge = { finish() }
                    )
                }
            }
        }
    }
}

/**
 * Alarm screen composable
 */
@Composable
fun AlarmScreen(
    crowdCount: Int,
    onAcknowledge: () -> Unit
) {
    // Pulsating effect for warning elements
    var isPulsating by remember { mutableStateOf(true) }
    val warningColor = if (isPulsating) Color(0xFFFF5252) else Color(0xFFFF8A80)
    
    LaunchedEffect(key1 = true) {
        while (true) {
            delay(500) // Toggle every 500ms
            isPulsating = !isPulsating
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF4E0000)) // Dark red background
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Warning icon (would be an actual icon in a real app)
        Text(
            text = "⚠️",
            fontSize = 64.sp,
            color = warningColor
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Pulsating warning text
        Text(
            text = "CRITICAL ALERT",
            style = MaterialTheme.typography.headlineLarge,
            color = warningColor,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Current crowd density has reached CRITICAL levels",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Estimated Count: $crowdCount people",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Text(
            text = "IMMEDIATE ACTION REQUIRED",
            style = MaterialTheme.typography.titleLarge,
            color = warningColor,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "• Reduce occupancy immediately\n• Enhance airflow\n• Implement crowd management protocols\n• Check ventilation systems",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Countdown timer since alert was triggered
        var secondsElapsed by remember { mutableStateOf(0) }
        
        LaunchedEffect(key1 = true) {
            while (true) {
                delay(1000)
                secondsElapsed++
            }
        }
        
        Text(
            text = "Alert active for: ${formatTime(secondsElapsed)}",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.7f)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { /* Would mute alarm sound */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF424242))
            ) {
                Text("Mute Alarm")
            }
            
            Button(
                onClick = onAcknowledge,
                colors = ButtonDefaults.buttonColors(containerColor = warningColor)
            ) {
                Text("Acknowledge")
            }
        }
    }
}

/**
 * Formats seconds into MM:SS format
 */
private fun formatTime(seconds: Int): String {
    val minutes = seconds / 60
    val remainingSeconds = seconds % 60
    return "%02d:%02d".format(minutes, remainingSeconds)
}
