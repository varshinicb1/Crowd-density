package com.renesas.crowdmonitoring.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.patrykandpatrick.vico.compose.axis.horizontal.bottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.startAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.style.ProvideChartStyle
import com.patrykandpatrick.vico.core.entry.entryModelOf
import com.patrykandpatrick.vico.core.entry.entryOf
import com.renesas.crowdmonitoring.data.ProcessedSensorData
import com.renesas.crowdmonitoring.ui.theme.CrowdMonitoringTheme
import java.text.SimpleDateFormat
import java.util.*

/**
 * Activity for the Monitoring screen
 */
class MonitoringActivity : ComponentActivity() {
    
    private lateinit var viewModel: MonitoringViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize ViewModel
        viewModel = ViewModelProvider(
            this,
            MonitoringViewModel.Factory(applicationContext)
        )[MonitoringViewModel::class.java]
        
        setContent {
            CrowdMonitoringTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MonitoringScreen(viewModel)
                }
            }
        }
    }
}

/**
 * Monitoring screen composable
 */
@Composable
fun MonitoringScreen(viewModel: MonitoringViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Screen header
        Text(
            text = "Real-time Monitoring",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.padding(bottom = 24.dp)
        )
        
        // Current status card
        CurrentStatusCard(uiState)
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Crowd density chart
        Text(
            text = "Crowd Density Trend",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.tertiary)
            }
        } else if (uiState.sensorReadings.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No sensor data available",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        } else {
            // Chart
            CrowdDensityChart(uiState.sensorReadings)
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Sensor readings
        Text(
            text = "Sensor Readings",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        if (uiState.sensorReadings.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(100.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No sensor data available",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        } else {
            // Latest sensor readings
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(uiState.sensorReadings) { reading ->
                    SensorReadingItem(reading)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Refresh button
        Button(
            onClick = { viewModel.refreshData() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary
            )
        ) {
            Text("Refresh Data")
        }
        
        // Error message if any
        if (uiState.error != null) {
            Text(
                text = uiState.error!!,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

/**
 * Current status card composable
 */
@Composable
fun CurrentStatusCard(uiState: MonitoringUiState) {
    val latestReading = uiState.sensorReadings.firstOrNull()
    
    val backgroundColor = when {
        latestReading?.crowdDensityLevel == "Critical" -> Color(0xFF4E0000) // Dark red
        latestReading?.crowdDensityLevel == "High" -> Color(0xFF4E3500) // Dark orange
        latestReading?.crowdDensityLevel == "Medium" -> Color(0xFF354E00) // Dark yellow-green
        else -> Color(0xFF003B4E) // Dark blue
    }
    
    val statusColor = when {
        latestReading?.crowdDensityLevel == "Critical" -> Color(0xFFFF5252) // Bright red
        latestReading?.crowdDensityLevel == "High" -> Color(0xFFFFD600) // Bright yellow
        latestReading?.crowdDensityLevel == "Medium" -> Color(0xFFAEEA00) // Bright green-yellow
        else -> Color(0xFF00E5FF) // Bright cyan
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            if (latestReading == null) {
                Text(
                    text = "No Data Available",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Current Status: ${latestReading.crowdDensityLevel}",
                        style = MaterialTheme.typography.titleLarge,
                        color = statusColor
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Density: ${String.format("%.2f", latestReading.crowdDensity)} | Count: ${latestReading.estimatedCrowdCount} people",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White
                    )
                    
                    // Format timestamp
                    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    val timeString = timeFormat.format(Date(latestReading.rawData.timestamp))
                    
                    Text(
                        text = "Last Updated: $timeString",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

/**
 * Crowd density chart composable
 */
@Composable
fun CrowdDensityChart(readings: List<ProcessedSensorData>) {
    // Prepare chart data
    val chartEntries = readings.mapIndexed { index, reading ->
        entryOf(index.toFloat(), reading.crowdDensity.toFloat())
    }
    
    val chartModel = entryModelOf(*chartEntries.toTypedArray())
    
    // Chart styling
    ProvideChartStyle {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
            ) {
                Chart(
                    chart = lineChart(
                        lines = listOf(
                            lineChart.lineSpec(
                                lineColor = MaterialTheme.colorScheme.tertiary,
                                lineBackgroundShader = null
                            )
                        )
                    ),
                    model = chartModel,
                    startAxis = startAxis(
                        label = { value, _ ->
                            val densityValue = value.toDouble()
                            when {
                                densityValue >= 1.0 -> "Critical"
                                densityValue >= 0.7 -> "High"
                                densityValue >= 0.3 -> "Medium"
                                else -> "Low"
                            }
                        }
                    ),
                    bottomAxis = bottomAxis(
                        label = { value, _ ->
                            if (readings.size > value.toInt()) {
                                val reading = readings[value.toInt()]
                                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                                timeFormat.format(Date(reading.rawData.timestamp))
                            } else {
                                ""
                            }
                        }
                    )
                )
            }
        }
    }
}

/**
 * Sensor reading item composable
 */
@Composable
fun SensorReadingItem(reading: ProcessedSensorData) {
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val timeString = timeFormat.format(Date(reading.rawData.timestamp))
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Time and status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = timeString,
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
                
                Text(
                    text = reading.crowdDensityLevel,
                    style = MaterialTheme.typography.titleMedium,
                    color = when (reading.crowdDensityLevel) {
                        "Critical" -> MaterialTheme.colorScheme.error
                        "High" -> Color(0xFFFFD600) // Warning Yellow
                        "Medium" -> Color(0xFFAEEA00) // Light Green
                        else -> MaterialTheme.colorScheme.tertiary
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Sensor values
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SensorValue("eCO2", "${reading.rawData.eco2.toInt()} ppm")
                SensorValue("TVOC", "${reading.rawData.tvoc.toInt()} ppb")
                SensorValue("EtOH", "${reading.rawData.etoh.toInt()} ppb")
                SensorValue("IAQ", "${reading.rawData.iaq.toInt()}")
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            // Density and count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Density: ${String.format("%.2f", reading.crowdDensity)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Text(
                    text = "Count: ${reading.estimatedCrowdCount}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/**
 * Sensor value composable
 */
@Composable
fun SensorValue(name: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.tertiary
        )
        
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
    }
}
