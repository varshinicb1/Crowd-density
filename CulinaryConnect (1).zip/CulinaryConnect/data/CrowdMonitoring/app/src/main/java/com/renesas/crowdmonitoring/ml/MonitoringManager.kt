package com.renesas.crowdmonitoring.ml

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.renesas.crowdmonitoring.data.CrowdMonitoringRepository
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.TimeUnit

/**
 * Manager class for monitoring crowd density and scheduling predictions
 */
class MonitoringManager(private val context: Context) {
    
    private val repository = CrowdMonitoringRepository(context)
    private val predictionManager = PredictionManager(context)
    
    /**
     * Starts the monitoring system
     * - Schedules periodic sensor data fetching
     * - Schedules periodic predictions
     */
    fun startMonitoring() {
        // Start sensor data fetching
        repository.startPeriodicDataFetching(intervalMinutes = 1)
        
        // Schedule periodic predictions
        schedulePredictions()
    }
    
    /**
     * Schedules periodic crowd density predictions
     */
    private fun schedulePredictions() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
            
        val periodicWorkRequest = PeriodicWorkRequestBuilder<PredictionWorker>(
            15, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .build()
            
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "crowd_prediction",
            ExistingPeriodicWorkPolicy.REPLACE,
            periodicWorkRequest
        )
    }
    
    /**
     * Gets the current monitoring status
     * @return MonitoringStatus object with current density and prediction info
     */
    suspend fun getCurrentStatus(): MonitoringStatus {
        val currentData = predictionManager.getCurrentStatus()
        val criticalPrediction = predictionManager.checkForCriticalPredictions()
        
        return MonitoringStatus(
            currentDensityLevel = currentData?.crowdDensityLevel ?: "Unknown",
            currentDensityValue = currentData?.crowdDensity ?: 0.0,
            estimatedCrowdCount = currentData?.estimatedCrowdCount ?: 0,
            isCritical = currentData?.crowdDensityLevel == "Critical",
            isHigh = currentData?.crowdDensityLevel == "High",
            hasCriticalPrediction = criticalPrediction != null,
            timeUntilCritical = criticalPrediction?.let {
                (it.timestamp - System.currentTimeMillis()) / (60 * 1000)
            }
        )
    }
    
    /**
     * Manually triggers a prediction update
     * @return True if prediction was successful, false otherwise
     */
    suspend fun updatePredictions(): Boolean {
        val predictions = predictionManager.generatePredictions()
        return predictions != null && predictions.isNotEmpty()
    }
}

/**
 * Data class representing the current monitoring status
 */
data class MonitoringStatus(
    val currentDensityLevel: String,
    val currentDensityValue: Double,
    val estimatedCrowdCount: Int,
    val isCritical: Boolean,
    val isHigh: Boolean,
    val hasCriticalPrediction: Boolean,
    val timeUntilCritical: Long? = null
)
