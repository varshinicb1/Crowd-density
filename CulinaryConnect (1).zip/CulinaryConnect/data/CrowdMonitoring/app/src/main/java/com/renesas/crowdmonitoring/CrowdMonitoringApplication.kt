package com.renesas.crowdmonitoring

import android.app.Application
import androidx.work.Configuration
import androidx.work.WorkManager
import com.renesas.crowdmonitoring.ml.MonitoringManager
import dagger.hilt.android.HiltAndroidApp

/**
 * Main application class for the Crowd Monitoring app
 */
@HiltAndroidApp
class CrowdMonitoringApplication : Application(), Configuration.Provider {

    private lateinit var monitoringManager: MonitoringManager
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize monitoring manager
        monitoringManager = MonitoringManager(applicationContext)
        
        // Start monitoring system
        monitoringManager.startMonitoring()
    }
    
    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
    }
}
