package com.renesas.crowdmonitoring.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for sensor readings
 */
@Dao
interface SensorReadingDao {
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSensorReading(sensorReading: SensorReadingEntity)
    
    @Query("SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1")
    fun getLatestSensorReading(): Flow<SensorReadingEntity?>
    
    @Query("SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentSensorReadings(limit: Int): Flow<List<SensorReadingEntity>>
    
    @Query("SELECT * FROM sensor_readings WHERE timestamp BETWEEN :startTime AND :endTime ORDER BY timestamp ASC")
    fun getSensorReadingsInTimeRange(startTime: Long, endTime: Long): Flow<List<SensorReadingEntity>>
    
    @Query("SELECT * FROM sensor_readings WHERE crowd_density_level = :densityLevel ORDER BY timestamp DESC LIMIT :limit")
    fun getSensorReadingsByDensityLevel(densityLevel: String, limit: Int): Flow<List<SensorReadingEntity>>
    
    @Query("DELETE FROM sensor_readings WHERE timestamp < :timestamp")
    suspend fun deleteOldReadings(timestamp: Long)
}

/**
 * Data Access Object for crowd predictions
 */
@Dao
interface CrowdPredictionDao {
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrediction(prediction: CrowdPredictionEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPredictions(predictions: List<CrowdPredictionEntity>)
    
    @Query("SELECT * FROM crowd_predictions WHERE prediction_timestamp > :currentTime ORDER BY prediction_timestamp ASC")
    fun getFuturePredictions(currentTime: Long): Flow<List<CrowdPredictionEntity>>
    
    @Query("SELECT * FROM crowd_predictions WHERE created_at = (SELECT MAX(created_at) FROM crowd_predictions)")
    fun getLatestPredictionBatch(): Flow<List<CrowdPredictionEntity>>
    
    @Query("DELETE FROM crowd_predictions WHERE prediction_timestamp < :timestamp")
    suspend fun deleteOldPredictions(timestamp: Long)
}
