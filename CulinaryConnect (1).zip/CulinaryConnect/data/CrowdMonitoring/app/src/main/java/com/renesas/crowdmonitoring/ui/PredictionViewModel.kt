package com.renesas.crowdmonitoring.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.renesas.crowdmonitoring.data.CrowdMonitoringRepository
import com.renesas.crowdmonitoring.data.CrowdPrediction
import com.renesas.crowdmonitoring.ml.PredictionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * ViewModel for the Prediction screen
 */
class PredictionViewModel(
    private val context: Context
) : ViewModel() {

    private val repository = CrowdMonitoringRepository(context)
    private val predictionManager = PredictionManager(context)
    
    // UI state
    private val _uiState = MutableStateFlow(PredictionUiState())
    val uiState: StateFlow<PredictionUiState> = _uiState.asStateFlow()
    
    init {
        // Load predictions
        loadPredictions()
    }
    
    /**
     * Loads predictions from the repository
     */
    private fun loadPredictions() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isLoading = true)
                
                val predictions = repository.getFuturePredictions().first()
                
                _uiState.value = PredictionUiState(
                    isLoading = false,
                    predictions = predictions,
                    error = null
                )
            } catch (e: Exception) {
                _uiState.value = PredictionUiState(
                    isLoading = false,
                    predictions = emptyList(),
                    error = "Error loading predictions: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Updates predictions by generating new ones
     */
    fun updatePredictions() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(
                    isLoading = true,
                    error = null
                )
                
                val success = predictionManager.generatePredictions() != null
                
                if (success) {
                    // Reload predictions
                    val predictions = repository.getFuturePredictions().first()
                    
                    _uiState.value = PredictionUiState(
                        isLoading = false,
                        predictions = predictions,
                        error = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = "Failed to generate predictions"
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Error updating predictions: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Factory for creating PredictionViewModel instances
     */
    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(PredictionViewModel::class.java)) {
                return PredictionViewModel(context) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

/**
 * Data class representing the UI state for the prediction screen
 */
data class PredictionUiState(
    val isLoading: Boolean = true,
    val predictions: List<CrowdPrediction> = emptyList(),
    val error: String? = null
)
