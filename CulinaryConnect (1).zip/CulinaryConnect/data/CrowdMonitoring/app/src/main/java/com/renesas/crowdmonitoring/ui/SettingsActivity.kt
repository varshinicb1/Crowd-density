package com.renesas.crowdmonitoring.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.renesas.crowdmonitoring.notifications.NotificationCoordinator
import com.renesas.crowdmonitoring.ui.theme.CrowdMonitoringTheme

/**
 * Activity for the Settings screen
 */
class SettingsActivity : ComponentActivity() {
    
    private lateinit var notificationCoordinator: NotificationCoordinator
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize notification coordinator
        notificationCoordinator = NotificationCoordinator(applicationContext)
        
        setContent {
            CrowdMonitoringTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SettingsScreen(
                        onNavigateBack = { finish() },
                        onSaveTwilioSettings = { accountSid, authToken, phoneNumber ->
                            // In a real app, we would securely store these credentials
                            notificationCoordinator.initialize(
                                twilioAccountSid = accountSid,
                                twilioAuthToken = authToken,
                                twilioPhoneNumber = phoneNumber
                            )
                        }
                    )
                }
            }
        }
    }
}

/**
 * Settings screen composable
 */
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onSaveTwilioSettings: (String, String, String) -> Unit
) {
    val scrollState = rememberScrollState()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        // Screen header
        Text(
            text = "Settings",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.padding(bottom = 24.dp)
        )
        
        // Notification settings
        SettingsSection(title = "Notification Settings") {
            SettingsSwitchItem(
                title = "Push Notifications",
                description = "Receive push notifications for crowd density alerts",
                initialValue = true
            )
            
            SettingsSwitchItem(
                title = "SMS Alerts",
                description = "Receive SMS alerts for critical situations",
                initialValue = true
            )
            
            SettingsSwitchItem(
                title = "In-App Alarms",
                description = "Play alarm sounds for critical alerts",
                initialValue = true
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Twilio settings
        SettingsSection(title = "Twilio SMS Settings") {
            var accountSid by remember { mutableStateOf("") }
            var authToken by remember { mutableStateOf("") }
            var phoneNumber by remember { mutableStateOf("") }
            
            OutlinedTextField(
                value = accountSid,
                onValueChange = { accountSid = it },
                label = { Text("Account SID") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                    focusedLabelColor = MaterialTheme.colorScheme.tertiary
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            OutlinedTextField(
                value = authToken,
                onValueChange = { authToken = it },
                label = { Text("Auth Token") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                    focusedLabelColor = MaterialTheme.colorScheme.tertiary
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                label = { Text("Twilio Phone Number") },
                placeholder = { Text("+1XXXXXXXXXX") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                    focusedLabelColor = MaterialTheme.colorScheme.tertiary
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = { onSaveTwilioSettings(accountSid, authToken, phoneNumber) },
                modifier = Modifier.align(Alignment.End),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Text("Save Twilio Settings")
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Alert settings
        SettingsSection(title = "Alert Settings") {
            var criticalThreshold by remember { mutableStateOf("1.0") }
            var highThreshold by remember { mutableStateOf("0.7") }
            
            Text(
                text = "Crowd Density Thresholds",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Critical:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.width(80.dp)
                )
                
                OutlinedTextField(
                    value = criticalThreshold,
                    onValueChange = { criticalThreshold = it },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = MaterialTheme.colorScheme.error,
                        focusedLabelColor = MaterialTheme.colorScheme.error
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "High:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.width(80.dp)
                )
                
                OutlinedTextField(
                    value = highThreshold,
                    onValueChange = { highThreshold = it },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFFFFD600),
                        focusedLabelColor = Color(0xFFFFD600)
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // App info
        SettingsSection(title = "App Information") {
            InfoItem(title = "App Name", value = "Crowd Monitoring")
            InfoItem(title = "Version", value = "1.0.0")
            InfoItem(title = "Developer", value = "Varshini CB")
            InfoItem(title = "Company", value = "Renesas")
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onNavigateBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back")
        }
    }
}

/**
 * Settings section composable
 */
@Composable
fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.tertiary,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            content()
        }
    }
}

/**
 * Settings switch item composable
 */
@Composable
fun SettingsSwitchItem(
    title: String,
    description: String,
    initialValue: Boolean
) {
    var isChecked by remember { mutableStateOf(initialValue) }
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
        
        Switch(
            checked = isChecked,
            onCheckedChange = { isChecked = it },
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.tertiary,
                checkedTrackColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.5f),
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                uncheckedTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
            )
        )
    }
}

/**
 * Info item composable
 */
@Composable
fun InfoItem(
    title: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.width(100.dp)
        )
        
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
