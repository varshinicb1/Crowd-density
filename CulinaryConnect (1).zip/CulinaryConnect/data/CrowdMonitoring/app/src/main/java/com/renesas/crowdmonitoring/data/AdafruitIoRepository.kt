package com.renesas.crowdmonitoring.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException

/**
 * Repository class for handling Adafruit IO data operations
 */
class AdafruitIoRepository {
    
    companion object {
        private const val BASE_URL = "https://io.adafruit.com/"
        private const val USERNAME = "varshinicb99"
        private const val API_KEY = "aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe"
        
        // Feed keys
        const val FEED_ECO2 = "eCO2"
        const val FEED_TVOC = "tvoc"
        const val FEED_ETOH = "EtOH"
        const val FEED_IAQ = "indoor-aqi"
    }
    
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    
    private val adafruitIoService = retrofit.create(AdafruitIoService::class.java)
    
    /**
     * Fetches the latest data from a specific feed
     * @param feedKey The key of the feed to fetch data from
     * @return Flow emitting the latest sensor reading or error
     */
    fun getLatestFeedData(feedKey: String): Flow<Result<Double>> = flow {
        try {
            val response = adafruitIoService.getFeedData(
                username = USERNAME,
                feed = feedKey,
                apiKey = API_KEY
            )
            
            if (response.isSuccessful) {
                val feedDataList = response.body()
                if (!feedDataList.isNullOrEmpty()) {
                    val latestData = feedDataList[0]
                    val value = latestData.value.toDoubleOrNull()
                    if (value != null) {
                        emit(Result.success(value))
                    } else {
                        emit(Result.failure(NumberFormatException("Invalid sensor value format")))
                    }
                } else {
                    emit(Result.failure(IOException("No data available for feed: $feedKey")))
                }
            } else {
                emit(Result.failure(IOException("Error fetching feed data: ${response.code()}")))
            }
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)
    
    /**
     * Fetches all available feeds for the user
     * @return Flow emitting the list of feeds or error
     */
    fun getAllFeeds(): Flow<Result<List<Feed>>> = flow {
        try {
            val response = adafruitIoService.getFeeds(
                username = USERNAME,
                apiKey = API_KEY
            )
            
            if (response.isSuccessful) {
                val feeds = response.body()
                if (feeds != null) {
                    emit(Result.success(feeds))
                } else {
                    emit(Result.failure(IOException("No feeds available")))
                }
            } else {
                emit(Result.failure(IOException("Error fetching feeds: ${response.code()}")))
            }
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)
    
    /**
     * Fetches all sensor data in a single call
     * @return Flow emitting SensorData object containing all sensor readings
     */
    fun getAllSensorData(): Flow<Result<SensorData>> = flow {
        try {
            val eco2Result = getLatestFeedData(FEED_ECO2).collect { result ->
                val tvocResult = getLatestFeedData(FEED_TVOC).collect { tvocResult ->
                    val etohResult = getLatestFeedData(FEED_ETOH).collect { etohResult ->
                        val iaqResult = getLatestFeedData(FEED_IAQ).collect { iaqResult ->
                            if (result.isSuccess && tvocResult.isSuccess && 
                                etohResult.isSuccess && iaqResult.isSuccess) {
                                
                                val sensorData = SensorData(
                                    eco2 = result.getOrNull() ?: 0.0,
                                    tvoc = tvocResult.getOrNull() ?: 0.0,
                                    etoh = etohResult.getOrNull() ?: 0.0,
                                    iaq = iaqResult.getOrNull() ?: 0.0,
                                    timestamp = System.currentTimeMillis()
                                )
                                emit(Result.success(sensorData))
                            } else {
                                val exception = result.exceptionOrNull() ?: 
                                    tvocResult.exceptionOrNull() ?: 
                                    etohResult.exceptionOrNull() ?: 
                                    iaqResult.exceptionOrNull() ?: 
                                    IOException("Unknown error fetching sensor data")
                                emit(Result.failure(exception))
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)
}

/**
 * Data class representing all sensor readings at a point in time
 */
data class SensorData(
    val eco2: Double,
    val tvoc: Double,
    val etoh: Double,
    val iaq: Double,
    val timestamp: Long
)
