package com.renesas.crowdmonitoring.ml

import android.content.Context
import android.content.res.AssetFileDescriptor
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * LSTM model for crowd density prediction
 */
class CrowdPredictionModel(private val context: Context) {
    
    private var interpreter: Interpreter? = null
    private val modelName = "crowd_density_lstm.tflite"
    
    // Model parameters
    private val sequenceLength = 60 // 60 minutes of historical data
    private val numFeatures = 4 // 4 normalized sensor values
    private val predictionSteps = 20 // Predict 20 minutes into the future
    
    init {
        try {
            val model = loadModelFile()
            val options = Interpreter.Options()
            interpreter = Interpreter(model, options)
        } catch (e: Exception) {
            // Log error
        }
    }
    
    /**
     * Predicts crowd density for the next 20 minutes based on historical data
     * @param historicalData List of normalized sensor readings (should contain at least 60 entries)
     * @return List of predictions for the next 20 minutes
     */
    fun predictCrowdDensity(
        historicalData: List<NormalizedSensorReading>
    ): List<DensityPrediction> {
        if (interpreter == null) {
            return emptyList()
        }
        
        // Ensure we have enough historical data
        if (historicalData.size < sequenceLength) {
            return emptyList()
        }
        
        // Use the most recent data points
        val recentData = historicalData.takeLast(sequenceLength)
        
        // Prepare input data
        val inputBuffer = ByteBuffer.allocateDirect(sequenceLength * numFeatures * 4) // 4 bytes per float
        inputBuffer.order(ByteOrder.nativeOrder())
        
        // Fill input buffer with normalized sensor values
        for (reading in recentData) {
            inputBuffer.putFloat(reading.eco2Normalized.toFloat())
            inputBuffer.putFloat(reading.tvocNormalized.toFloat())
            inputBuffer.putFloat(reading.etohNormalized.toFloat())
            inputBuffer.putFloat(reading.iaqNormalized.toFloat())
        }
        inputBuffer.rewind()
        
        // Prepare output buffer
        val outputBuffer = ByteBuffer.allocateDirect(predictionSteps * 4) // 4 bytes per float
        outputBuffer.order(ByteOrder.nativeOrder())
        
        // Run inference
        interpreter?.run(inputBuffer, outputBuffer)
        outputBuffer.rewind()
        
        // Process predictions
        val predictions = mutableListOf<DensityPrediction>()
        val currentTime = System.currentTimeMillis()
        val minuteInMillis = 60 * 1000L
        
        for (i in 0 until predictionSteps) {
            val predictedDensity = outputBuffer.float.toDouble()
            val confidence = calculateConfidence(i) // Confidence decreases as we predict further into the future
            
            predictions.add(
                DensityPrediction(
                    timestamp = currentTime + (i + 1) * minuteInMillis,
                    predictedDensity = predictedDensity,
                    confidence = confidence
                )
            )
        }
        
        return predictions
    }
    
    /**
     * Calculates confidence level based on how far into the future we're predicting
     * Confidence decreases linearly as we predict further into the future
     */
    private fun calculateConfidence(stepIndex: Int): Double {
        return 0.95 - (stepIndex.toDouble() / predictionSteps) * 0.4
    }
    
    /**
     * Loads the TFLite model file from assets
     */
    private fun loadModelFile(): MappedByteBuffer {
        val fileDescriptor: AssetFileDescriptor = context.assets.openFd(modelName)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }
    
    /**
     * Closes the interpreter when no longer needed
     */
    fun close() {
        interpreter?.close()
        interpreter = null
    }
}

/**
 * Data class representing normalized sensor readings for the model
 */
data class NormalizedSensorReading(
    val eco2Normalized: Double,
    val tvocNormalized: Double,
    val etohNormalized: Double,
    val iaqNormalized: Double,
    val timestamp: Long
)

/**
 * Data class representing a single density prediction
 */
data class DensityPrediction(
    val timestamp: Long,
    val predictedDensity: Double,
    val confidence: Double
)
