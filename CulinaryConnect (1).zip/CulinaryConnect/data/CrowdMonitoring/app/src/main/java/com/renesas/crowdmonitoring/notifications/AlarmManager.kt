package com.renesas.crowdmonitoring.notifications

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manager class for handling in-app alarms and alerts
 */
class AlarmManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    
    // Alarm state
    private val _alarmState = MutableStateFlow(AlarmState())
    val alarmState: StateFlow<AlarmState> = _alarmState.asStateFlow()
    
    init {
        // Initialize vibrator
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }
    
    /**
     * Starts the critical alarm with sound and vibration
     */
    fun startCriticalAlarm() {
        if (_alarmState.value.isAlarmActive) {
            return
        }
        
        // Start alarm sound
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        startAlarmSound(alarmSound)
        
        // Start vibration
        startVibration()
        
        // Update state
        _alarmState.value = AlarmState(
            isAlarmActive = true,
            alarmType = AlarmType.CRITICAL,
            startTime = System.currentTimeMillis()
        )
    }
    
    /**
     * Starts a high alert with less intense sound and vibration
     */
    fun startHighAlert() {
        if (_alarmState.value.isAlarmActive) {
            return
        }
        
        // Start alert sound
        val alertSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        startAlarmSound(alertSound)
        
        // Start mild vibration
        startMildVibration()
        
        // Update state
        _alarmState.value = AlarmState(
            isAlarmActive = true,
            alarmType = AlarmType.HIGH,
            startTime = System.currentTimeMillis()
        )
    }
    
    /**
     * Stops the currently active alarm or alert
     */
    fun stopAlarm() {
        // Stop sound
        mediaPlayer?.apply {
            if (isPlaying) {
                stop()
            }
            release()
        }
        mediaPlayer = null
        
        // Stop vibration
        vibrator?.cancel()
        
        // Update state
        _alarmState.value = AlarmState(
            isAlarmActive = false,
            alarmType = AlarmType.NONE,
            startTime = 0
        )
    }
    
    /**
     * Starts playing the alarm sound
     */
    private fun startAlarmSound(soundUri: Uri) {
        // Release any existing media player
        mediaPlayer?.release()
        
        // Create new media player
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build()
            )
            
            try {
                setDataSource(context, soundUri)
                setLooping(true)
                prepare()
                start()
            } catch (e: Exception) {
                // Log error
            }
        }
    }
    
    /**
     * Starts intense vibration pattern for critical alerts
     */
    private fun startVibration() {
        val pattern = longArrayOf(0, 500, 500, 500, 500, 500)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(
                VibrationEffect.createWaveform(
                    pattern,
                    0 // Repeat indefinitely
                )
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0) // Repeat indefinitely
        }
    }
    
    /**
     * Starts mild vibration pattern for high alerts
     */
    private fun startMildVibration() {
        val pattern = longArrayOf(0, 250, 250, 250)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(
                VibrationEffect.createWaveform(
                    pattern,
                    0 // Repeat indefinitely
                )
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0) // Repeat indefinitely
        }
    }
    
    /**
     * Releases resources when no longer needed
     */
    fun release() {
        stopAlarm()
        mediaPlayer = null
        vibrator = null
    }
}

/**
 * Enum representing different alarm types
 */
enum class AlarmType {
    NONE,
    HIGH,
    CRITICAL
}

/**
 * Data class representing the current alarm state
 */
data class AlarmState(
    val isAlarmActive: Boolean = false,
    val alarmType: AlarmType = AlarmType.NONE,
    val startTime: Long = 0
)
