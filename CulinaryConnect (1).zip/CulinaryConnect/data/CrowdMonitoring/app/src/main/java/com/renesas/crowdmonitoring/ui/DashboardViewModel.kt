package com.renesas.crowdmonitoring.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.renesas.crowdmonitoring.ml.MonitoringManager
import com.renesas.crowdmonitoring.ml.MonitoringStatus
import com.renesas.crowdmonitoring.notifications.NotificationCoordinator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Timer
import java.util.TimerTask

/**
 * ViewModel for the main dashboard screen
 */
class DashboardViewModel(
    private val context: Context
) : ViewModel() {

    private val monitoringManager = MonitoringManager(context)
    private val notificationCoordinator = NotificationCoordinator(context)
    
    // UI state
    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()
    
    // Timer for periodic updates
    private var updateTimer: Timer? = null
    
    init {
        // Start monitoring
        monitoringManager.startMonitoring()
        
        // Initialize notification system with Twilio credentials
        // In a real app, these would be securely stored and retrieved
        notificationCoordinator.initialize(
            twilioAccountSid = "YOUR_ACCOUNT_SID",
            twilioAuthToken = "YOUR_AUTH_TOKEN",
            twilioPhoneNumber = "YOUR_TWILIO_PHONE_NUMBER"
        )
        
        // Start periodic UI updates
        startPeriodicUpdates()
    }
    
    /**
     * Starts periodic UI updates
     */
    private fun startPeriodicUpdates() {
        updateTimer = Timer().apply {
            scheduleAtFixedRate(object : TimerTask() {
                override fun run() {
                    updateMonitoringStatus()
                }
            }, 0, 5000) // Update every 5 seconds
        }
    }
    
    /**
     * Updates the monitoring status and UI state
     */
    private fun updateMonitoringStatus() {
        viewModelScope.launch {
            try {
                val status = monitoringManager.getCurrentStatus()
                
                // Update UI state
                _uiState.value = DashboardUiState(
                    isLoading = false,
                    currentDensityLevel = status.currentDensityLevel,
                    currentDensityValue = status.currentDensityValue,
                    estimatedCrowdCount = status.estimatedCrowdCount,
                    isCritical = status.isCritical,
                    isHigh = status.isHigh,
                    hasCriticalPrediction = status.hasCriticalPrediction,
                    timeUntilCritical = status.timeUntilCritical,
                    error = null
                )
                
                // Process status for notifications
                notificationCoordinator.processMonitoringStatus(status)
                
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Error updating status: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Manually refreshes the monitoring status
     */
    fun refreshStatus() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        updateMonitoringStatus()
    }
    
    /**
     * Updates predictions
     */
    fun updatePredictions() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isUpdatingPredictions = true)
                
                val success = monitoringManager.updatePredictions()
                
                if (success) {
                    // Refresh status to get updated predictions
                    updateMonitoringStatus()
                } else {
                    _uiState.value = _uiState.value.copy(
                        isUpdatingPredictions = false,
                        error = "Failed to update predictions"
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isUpdatingPredictions = false,
                    error = "Error updating predictions: ${e.message}"
                )
            }
        }
    }
    
    /**
     * Acknowledges the current alert
     */
    fun acknowledgeAlert() {
        notificationCoordinator.acknowledgeAlert()
    }
    
    /**
     * Clears all active alerts
     */
    fun clearAlerts() {
        notificationCoordinator.clearAllAlerts()
    }
    
    override fun onCleared() {
        super.onCleared()
        updateTimer?.cancel()
        updateTimer = null
        notificationCoordinator.release()
    }
    
    /**
     * Factory for creating DashboardViewModel instances
     */
    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
                return DashboardViewModel(context) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

/**
 * Data class representing the UI state for the dashboard
 */
data class DashboardUiState(
    val isLoading: Boolean = true,
    val isUpdatingPredictions: Boolean = false,
    val currentDensityLevel: String = "Unknown",
    val currentDensityValue: Double = 0.0,
    val estimatedCrowdCount: Int = 0,
    val isCritical: Boolean = false,
    val isHigh: Boolean = false,
    val hasCriticalPrediction: Boolean = false,
    val timeUntilCritical: Long? = null,
    val error: String? = null
)
