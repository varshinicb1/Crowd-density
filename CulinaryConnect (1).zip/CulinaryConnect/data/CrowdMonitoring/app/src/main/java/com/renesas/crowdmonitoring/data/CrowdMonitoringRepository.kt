package com.renesas.crowdmonitoring.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit

/**
 * Main repository that coordinates data operations for the app
 */
class CrowdMonitoringRepository(private val context: Context) {
    
    private val database = AppDatabase.getDatabase(context)
    private val sensorReadingDao = database.sensorReadingDao()
    private val crowdPredictionDao = database.crowdPredictionDao()
    private val adafruitIoRepository = AdafruitIoRepository()
    private val sensorDataProcessor = SensorDataProcessor()
    
    /**
     * Starts periodic background data fetching
     * @param intervalMinutes How often to fetch data in minutes
     */
    fun startPeriodicDataFetching(intervalMinutes: Long = 1) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
            
        val periodicWorkRequest = PeriodicWorkRequestBuilder<SensorDataWorker>(
            intervalMinutes, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .build()
            
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "sensor_data_fetching",
            ExistingPeriodicWorkPolicy.REPLACE,
            periodicWorkRequest
        )
    }
    
    /**
     * Gets the latest processed sensor data
     */
    fun getLatestSensorReading(): Flow<ProcessedSensorData?> {
        return sensorReadingDao.getLatestSensorReading().map { entity ->
            entity?.let {
                ProcessedSensorData(
                    rawData = SensorData(
                        eco2 = it.eco2,
                        tvoc = it.tvoc,
                        etoh = it.etoh,
                        iaq = it.iaq,
                        timestamp = it.timestamp
                    ),
                    eco2Normalized = it.eco2Normalized,
                    tvocNormalized = it.tvocNormalized,
                    etohNormalized = it.etohNormalized,
                    iaqNormalized = it.iaqNormalized,
                    crowdDensity = it.crowdDensity,
                    crowdDensityLevel = it.crowdDensityLevel,
                    estimatedCrowdCount = calculateCrowdCount(it.crowdDensity)
                )
            }
        }
    }
    
    /**
     * Gets recent sensor readings for graphing
     * @param limit Number of readings to retrieve
     */
    fun getRecentSensorReadings(limit: Int = 60): Flow<List<ProcessedSensorData>> {
        return sensorReadingDao.getRecentSensorReadings(limit).map { entities ->
            entities.map { entity ->
                ProcessedSensorData(
                    rawData = SensorData(
                        eco2 = entity.eco2,
                        tvoc = entity.tvoc,
                        etoh = entity.etoh,
                        iaq = entity.iaq,
                        timestamp = entity.timestamp
                    ),
                    eco2Normalized = entity.eco2Normalized,
                    tvocNormalized = entity.tvocNormalized,
                    etohNormalized = entity.etohNormalized,
                    iaqNormalized = entity.iaqNormalized,
                    crowdDensity = entity.crowdDensity,
                    crowdDensityLevel = entity.crowdDensityLevel,
                    estimatedCrowdCount = calculateCrowdCount(entity.crowdDensity)
                )
            }
        }
    }
    
    /**
     * Gets future crowd predictions
     */
    fun getFuturePredictions(): Flow<List<CrowdPrediction>> {
        val currentTime = System.currentTimeMillis()
        return crowdPredictionDao.getFuturePredictions(currentTime).map { entities ->
            entities.map { entity ->
                CrowdPrediction(
                    predictedDensity = entity.predictedDensity,
                    predictionLevel = entity.predictionLevel,
                    confidence = entity.confidence,
                    timestamp = entity.predictionTimestamp,
                    estimatedCrowdCount = calculateCrowdCount(entity.predictedDensity)
                )
            }
        }
    }
    
    /**
     * Manually fetches latest sensor data from Adafruit IO
     * @return Result containing processed sensor data or error
     */
    suspend fun fetchLatestSensorData(): Result<ProcessedSensorData> {
        try {
            val sensorDataResult = adafruitIoRepository.getAllSensorData().collect { result ->
                if (result.isSuccess) {
                    val sensorData = result.getOrNull()
                    if (sensorData != null) {
                        // Process sensor data
                        val processedData = sensorDataProcessor.processSensorData(sensorData)
                        
                        // Convert to entity and save to database
                        val sensorReadingEntity = sensorDataProcessor.toSensorReadingEntity(processedData)
                        sensorReadingDao.insertSensorReading(sensorReadingEntity)
                        
                        return Result.success(processedData)
                    }
                }
                
                return Result.failure(result.exceptionOrNull() ?: Exception("Unknown error fetching sensor data"))
            }
            
            return Result.failure(Exception("Failed to collect sensor data"))
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }
    
    /**
     * Calculates estimated crowd count based on density
     */
    private fun calculateCrowdCount(density: Double): Int {
        // Assuming a maximum capacity of 500 people for the venue
        val maxCapacity = 500
        return (density * maxCapacity).toInt()
    }
}

/**
 * Data class representing a crowd density prediction
 */
data class CrowdPrediction(
    val predictedDensity: Double,
    val predictionLevel: String,
    val confidence: Double,
    val timestamp: Long,
    val estimatedCrowdCount: Int
)
