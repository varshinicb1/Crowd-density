package com.renesas.crowdmonitoring.notifications

import android.content.Context
import com.renesas.crowdmonitoring.ml.MonitoringStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Main notification coordinator that manages all notification types
 */
class NotificationCoordinator(private val context: Context) {

    private val notificationManager = NotificationManager(context)
    private val smsManager = SmsManager(context)
    private val alarmManager = AlarmManager(context)
    
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    
    // Alert state
    private val _alertState = MutableStateFlow(AlertState())
    val alertState: StateFlow<AlertState> = _alertState.asStateFlow()
    
    /**
     * Initializes the notification system
     * @param twilioAccountSid Twilio account SID
     * @param twilioAuthToken Twilio auth token
     * @param twilioPhoneNumber Twilio phone number
     */
    fun initialize(
        twilioAccountSid: String,
        twilioAuthToken: String,
        twilioPhoneNumber: String
    ) {
        // Initialize SMS manager
        smsManager.initialize(twilioAccountSid, twilioAuthToken)
    }
    
    /**
     * Processes the current monitoring status and triggers appropriate notifications
     * @param status Current monitoring status
     */
    fun processMonitoringStatus(status: MonitoringStatus) {
        scope.launch {
            // Check for critical density
            if (status.isCritical && !_alertState.value.criticalAlertActive) {
                triggerCriticalAlert(status)
            }
            // Check for high density
            else if (status.isHigh && !_alertState.value.highAlertActive && !_alertState.value.criticalAlertActive) {
                triggerHighAlert(status)
            }
            // Check for predicted critical density
            else if (status.hasCriticalPrediction && !_alertState.value.predictionAlertActive && 
                    !_alertState.value.criticalAlertActive) {
                triggerPredictionAlert(status)
            }
            // Clear alerts if density is normal
            else if (!status.isHigh && !status.isCritical && !status.hasCriticalPrediction) {
                clearAllAlerts()
            }
        }
    }
    
    /**
     * Triggers a critical alert with all notification types
     */
    private suspend fun triggerCriticalAlert(status: MonitoringStatus) {
        // Show push notification
        notificationManager.showCriticalDensityNotification(status)
        
        // Send SMS
        smsManager.sendCriticalDensityAlert(status.estimatedCrowdCount)
        
        // Start alarm
        alarmManager.startCriticalAlarm()
        
        // Update state
        _alertState.value = AlertState(
            criticalAlertActive = true,
            highAlertActive = false,
            predictionAlertActive = false,
            lastAlertTime = System.currentTimeMillis()
        )
    }
    
    /**
     * Triggers a high alert with push notification and SMS
     */
    private suspend fun triggerHighAlert(status: MonitoringStatus) {
        // Show push notification
        notificationManager.showHighDensityNotification(status)
        
        // Send SMS
        smsManager.sendHighDensityAlert(status.estimatedCrowdCount)
        
        // Start high alert sound
        alarmManager.startHighAlert()
        
        // Update state
        _alertState.value = AlertState(
            criticalAlertActive = false,
            highAlertActive = true,
            predictionAlertActive = false,
            lastAlertTime = System.currentTimeMillis()
        )
    }
    
    /**
     * Triggers a prediction alert with push notification
     */
    private suspend fun triggerPredictionAlert(status: MonitoringStatus) {
        // Show push notification
        notificationManager.showPredictedCriticalNotification(status)
        
        // Send SMS for prediction
        status.timeUntilCritical?.let {
            smsManager.sendPredictedCriticalAlert(it)
        }
        
        // Update state
        _alertState.value = AlertState(
            criticalAlertActive = false,
            highAlertActive = false,
            predictionAlertActive = true,
            lastAlertTime = System.currentTimeMillis()
        )
    }
    
    /**
     * Clears all active alerts
     */
    fun clearAllAlerts() {
        // Cancel notifications
        notificationManager.cancelAllNotifications()
        
        // Stop alarm
        alarmManager.stopAlarm()
        
        // Update state
        _alertState.value = AlertState()
    }
    
    /**
     * Acknowledges the current alert but keeps notifications active
     */
    fun acknowledgeAlert() {
        // Stop alarm sound but keep notifications
        alarmManager.stopAlarm()
        
        // Update state to keep alert flags but stop sound
        _alertState.value = _alertState.value.copy(
            soundAcknowledged = true
        )
    }
    
    /**
     * Releases resources when no longer needed
     */
    fun release() {
        alarmManager.release()
    }
}

/**
 * Data class representing the current alert state
 */
data class AlertState(
    val criticalAlertActive: Boolean = false,
    val highAlertActive: Boolean = false,
    val predictionAlertActive: Boolean = false,
    val soundAcknowledged: Boolean = false,
    val lastAlertTime: Long = 0
)
