package com.renesas.crowdmonitoring.data

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit service interface for Adafruit IO API
 */
interface AdafruitIoService {
    
    @GET("api/v2/{username}/feeds/{feed}/data")
    suspend fun getFeedData(
        @Path("username") username: String,
        @Path("feed") feed: String,
        @Query("limit") limit: Int = 1,
        @Query("x-aio-key") apiKey: String
    ): Response<List<FeedData>>
    
    @GET("api/v2/{username}/feeds")
    suspend fun getFeeds(
        @Path("username") username: String,
        @Query("x-aio-key") apiKey: String
    ): Response<List<Feed>>
}

/**
 * Data class representing a feed data point from Adafruit IO
 */
data class FeedData(
    val id: String,
    val value: String,
    val feed_id: Int,
    val created_at: String,
    val updated_at: String
)

/**
 * Data class representing a feed from Adafruit IO
 */
data class Feed(
    val id: Int,
    val name: String,
    val key: String,
    val description: String?,
    val created_at: String,
    val updated_at: String
)
