package com.renesas.crowdmonitoring.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo

/**
 * Entity class for storing sensor readings in Room database
 */
@Entity(tableName = "sensor_readings")
data class SensorReadingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    @ColumnInfo(name = "eco2")
    val eco2: Double,
    
    @ColumnInfo(name = "tvoc")
    val tvoc: Double,
    
    @ColumnInfo(name = "etoh")
    val etoh: Double,
    
    @ColumnInfo(name = "iaq")
    val iaq: Double,
    
    @ColumnInfo(name = "eco2_normalized")
    val eco2Normalized: Double,
    
    @ColumnInfo(name = "tvoc_normalized")
    val tvocNormalized: Double,
    
    @ColumnInfo(name = "etoh_normalized")
    val etohNormalized: Double,
    
    @ColumnInfo(name = "iaq_normalized")
    val iaqNormalized: Double,
    
    @ColumnInfo(name = "crowd_density")
    val crowdDensity: Double,
    
    @ColumnInfo(name = "crowd_density_level")
    val crowdDensityLevel: String,
    
    @ColumnInfo(name = "timestamp")
    val timestamp: Long
)

/**
 * Entity class for storing crowd density predictions in Room database
 */
@Entity(tableName = "crowd_predictions")
data class CrowdPredictionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    @ColumnInfo(name = "predicted_density")
    val predictedDensity: Double,
    
    @ColumnInfo(name = "prediction_level")
    val predictionLevel: String,
    
    @ColumnInfo(name = "confidence")
    val confidence: Double,
    
    @ColumnInfo(name = "prediction_timestamp")
    val predictionTimestamp: Long,
    
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
