package com.renesas.crowdmonitoring.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.renesas.crowdmonitoring.ui.theme.CrowdMonitoringTheme

/**
 * Main Activity for the Crowd Monitoring app
 */
class MainActivity : ComponentActivity() {
    
    private lateinit var viewModel: DashboardViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize ViewModel
        viewModel = ViewModelProvider(
            this,
            DashboardViewModel.Factory(applicationContext)
        )[DashboardViewModel::class.java]
        
        setContent {
            CrowdMonitoringTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CrowdMonitoringApp(viewModel)
                }
            }
        }
    }
}

/**
 * Main composable function for the app
 */
@Composable
fun CrowdMonitoringApp(viewModel: DashboardViewModel) {
    val navController = rememberNavController()
    
    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") {
            DashboardScreen(
                viewModel = viewModel,
                onNavigateToMonitoring = { navController.navigate("monitoring") },
                onNavigateToPrediction = { navController.navigate("prediction") },
                onNavigateToSettings = { navController.navigate("settings") }
            )
        }
        composable("monitoring") {
            MonitoringScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable("prediction") {
            PredictionScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable("settings") {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable("alarm") {
            AlarmScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
    
    // Check for critical alerts and navigate to alarm screen if needed
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    LaunchedEffect(uiState.isCritical) {
        if (uiState.isCritical) {
            navController.navigate("alarm")
        }
    }
}

/**
 * Dashboard screen composable
 */
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToMonitoring: () -> Unit,
    onNavigateToPrediction: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // App header
        Text(
            text = "Crowd Monitoring",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 24.dp)
        )
        
        // Current status card
        StatusCard(uiState)
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Quick stats row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            StatCard(
                title = "Crowd Count",
                value = "${uiState.estimatedCrowdCount}",
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            StatCard(
                title = "Density",
                value = String.format("%.2f", uiState.currentDensityValue),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            StatCard(
                title = "Status",
                value = uiState.currentDensityLevel,
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Navigation buttons
        Button(
            onClick = onNavigateToMonitoring,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View Monitoring Details")
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Button(
            onClick = onNavigateToPrediction,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View Predictions")
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Button(
            onClick = onNavigateToSettings,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Settings")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Error message if any
        if (uiState.error != null) {
            Text(
                text = uiState.error!!,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        
        // Loading indicator
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }
    }
}

/**
 * Status card composable
 */
@Composable
fun StatusCard(uiState: DashboardUiState) {
    val backgroundColor = when {
        uiState.isCritical -> Color(0xFF4E0000) // Dark red
        uiState.isHigh -> Color(0xFF4E3500) // Dark orange
        uiState.currentDensityLevel == "Medium" -> Color(0xFF354E00) // Dark yellow-green
        else -> Color(0xFF003B4E) // Dark blue
    }
    
    val statusColor = when {
        uiState.isCritical -> Color(0xFFFF5252) // Bright red
        uiState.isHigh -> Color(0xFFFFD600) // Bright yellow
        uiState.currentDensityLevel == "Medium" -> Color(0xFFAEEA00) // Bright green-yellow
        else -> Color(0xFF00E5FF) // Bright cyan
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Current Crowd Density",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = uiState.currentDensityLevel,
                    style = MaterialTheme.typography.headlineLarge,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Estimated Count: ${uiState.estimatedCrowdCount} people",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
                
                if (uiState.hasCriticalPrediction && uiState.timeUntilCritical != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Critical in ${uiState.timeUntilCritical} minutes",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFFF5252) // Bright red
                    )
                }
            }
        }
    }
}

/**
 * Stat card composable
 */
@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = Color.White
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = Color(0xFF00E5FF), // Cyan
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Placeholder composables for other screens
 */
@Composable
fun MonitoringScreen(
    viewModel: DashboardViewModel,
    onNavigateBack: () -> Unit
) {
    // Monitoring screen implementation will go here
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "Monitoring",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(onClick = onNavigateBack) {
            Text("Back")
        }
    }
}

@Composable
fun PredictionScreen(
    viewModel: DashboardViewModel,
    onNavigateBack: () -> Unit
) {
    // Prediction screen implementation will go here
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "Predictions",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(onClick = onNavigateBack) {
            Text("Back")
        }
    }
}

@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit
) {
    // Settings screen implementation will go here
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "Settings",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(onClick = onNavigateBack) {
            Text("Back")
        }
    }
}

@Composable
fun AlarmScreen(
    viewModel: DashboardViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF4E0000)) // Dark red background
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Pulsating warning text
        Text(
            text = "CRITICAL ALERT",
            style = MaterialTheme.typography.headlineLarge,
            color = Color(0xFFFF5252), // Bright red
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Current crowd density has reached CRITICAL levels",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Estimated Count: ${uiState.estimatedCrowdCount} people",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Text(
            text = "IMMEDIATE ACTION REQUIRED",
            style = MaterialTheme.typography.titleLarge,
            color = Color(0xFFFF5252), // Bright red
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = { viewModel.acknowledgeAlert() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
        ) {
            Text("Acknowledge Alarm")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = { 
                viewModel.clearAlerts()
                onNavigateBack()
            }
        ) {
            Text("Clear Alert and Return")
        }
    }
}
