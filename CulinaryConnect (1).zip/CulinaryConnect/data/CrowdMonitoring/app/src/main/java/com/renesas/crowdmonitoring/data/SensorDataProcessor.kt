package com.renesas.crowdmonitoring.data

/**
 * Utility class for normalizing sensor data and calculating crowd density
 */
class SensorDataProcessor {
    
    companion object {
        // Normalization ranges from the provided code
        private const val C_MIN = 400.0  // eCO2 (ppm)
        private const val C_MAX = 5000.0
        private const val V_MIN = 0.0    // TVOC (ppb)
        private const val V_MAX = 1000.0
        private const val E_MIN = 0.0    // EtOH (ppb)
        private const val E_MAX = 1000.0
        private const val I_MIN = 0.0    // IAQ (unitless)
        private const val I_MAX = 500.0
        
        // Crowd density classification thresholds
        private const val LOW_THRESHOLD = 0.3
        private const val MEDIUM_THRESHOLD = 0.7
        private const val HIGH_THRESHOLD = 1.0
        
        // Default model weights (will be replaced with trained model weights)
        private val DEFAULT_WEIGHTS = floatArrayOf(0.4f, 0.3f, 0.2f, 0.1f)
    }
    
    /**
     * Normalizes eCO2 value
     */
    fun normalizeEco2(eco2: Double): Double {
        return (eco2 - C_MIN) / (C_MAX - C_MIN)
    }
    
    /**
     * Normalizes TVOC value
     */
    fun normalizeTvoc(tvoc: Double): Double {
        return (tvoc - V_MIN) / (V_MAX - V_MIN)
    }
    
    /**
     * Normalizes EtOH value
     */
    fun normalizeEtoh(etoh: Double): Double {
        return (etoh - E_MIN) / (E_MAX - E_MIN)
    }
    
    /**
     * Normalizes IAQ value
     */
    fun normalizeIaq(iaq: Double): Double {
        return (iaq - I_MIN) / (I_MAX - I_MIN)
    }
    
    /**
     * Processes raw sensor data and returns normalized values with calculated crowd density
     */
    fun processSensorData(sensorData: SensorData, weights: FloatArray = DEFAULT_WEIGHTS): ProcessedSensorData {
        // Normalize sensor values
        val eco2Normalized = normalizeEco2(sensorData.eco2)
        val tvocNormalized = normalizeTvoc(sensorData.tvoc)
        val etohNormalized = normalizeEtoh(sensorData.etoh)
        val iaqNormalized = normalizeIaq(sensorData.iaq)
        
        // Calculate crowd density using linear model
        val crowdDensity = (weights[0] * eco2Normalized + 
                           weights[1] * tvocNormalized + 
                           weights[2] * etohNormalized + 
                           weights[3] * iaqNormalized).toDouble()
        
        // Classify crowd density
        val densityLevel = classifyCrowdDensity(crowdDensity)
        
        // Estimate crowd count (placeholder calculation, will be refined)
        val estimatedCrowdCount = calculateCrowdCount(crowdDensity)
        
        return ProcessedSensorData(
            rawData = sensorData,
            eco2Normalized = eco2Normalized,
            tvocNormalized = tvocNormalized,
            etohNormalized = etohNormalized,
            iaqNormalized = iaqNormalized,
            crowdDensity = crowdDensity,
            crowdDensityLevel = densityLevel,
            estimatedCrowdCount = estimatedCrowdCount
        )
    }
    
    /**
     * Classifies crowd density value into a level
     */
    fun classifyCrowdDensity(density: Double): String {
        return when {
            density < LOW_THRESHOLD -> "Low"
            density < MEDIUM_THRESHOLD -> "Medium"
            density < HIGH_THRESHOLD -> "High"
            else -> "Critical"
        }
    }
    
    /**
     * Calculates estimated crowd count based on density
     * This is a placeholder calculation that will be refined based on venue capacity
     */
    private fun calculateCrowdCount(density: Double): Int {
        // Assuming a maximum capacity of 500 people for the venue
        val maxCapacity = 500
        return (density * maxCapacity).toInt()
    }
    
    /**
     * Converts a ProcessedSensorData to a SensorReadingEntity for database storage
     */
    fun toSensorReadingEntity(processedData: ProcessedSensorData): SensorReadingEntity {
        return SensorReadingEntity(
            eco2 = processedData.rawData.eco2,
            tvoc = processedData.rawData.tvoc,
            etoh = processedData.rawData.etoh,
            iaq = processedData.rawData.iaq,
            eco2Normalized = processedData.eco2Normalized,
            tvocNormalized = processedData.tvocNormalized,
            etohNormalized = processedData.etohNormalized,
            iaqNormalized = processedData.iaqNormalized,
            crowdDensity = processedData.crowdDensity,
            crowdDensityLevel = processedData.crowdDensityLevel,
            timestamp = processedData.rawData.timestamp
        )
    }
}

/**
 * Data class representing processed sensor data with normalized values and crowd density
 */
data class ProcessedSensorData(
    val rawData: SensorData,
    val eco2Normalized: Double,
    val tvocNormalized: Double,
    val etohNormalized: Double,
    val iaqNormalized: Double,
    val crowdDensity: Double,
    val crowdDensityLevel: String,
    val estimatedCrowdCount: Int
)
