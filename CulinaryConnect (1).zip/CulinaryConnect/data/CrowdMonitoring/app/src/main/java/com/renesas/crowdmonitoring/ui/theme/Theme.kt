package com.renesas.crowdmonitoring.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Sci-Fi Dark Theme Color Scheme as specified in the UI design document
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF1A1B4B),        // Deep Space Blue
    secondary = Color(0xFF4E11A8),      // Cosmic Purple
    tertiary = Color(0xFF00E5FF),       // Neon Cyan
    background = Color(0xFF121212),     // Dark Matter
    surface = Color(0xFF1E1E1E),        // Dark Nebula
    error = Color(0xFFFF5252),          // Alert Red
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    onError = Color.White
)

// We only use dark theme for this app
@Composable
fun CrowdMonitoringTheme(
    darkTheme: Boolean = true, // Always use dark theme
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            dynamicDarkColorScheme(context)
        }
        else -> DarkColorScheme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = SciFiTypography,
        content = content
    )
}
