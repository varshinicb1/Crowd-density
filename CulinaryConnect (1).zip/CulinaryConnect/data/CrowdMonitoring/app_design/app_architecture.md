# Crowd Monitoring App Architecture

## Overview
The Crowd Monitoring app is designed to monitor crowd density using data from Renesas zmod4410 sensors via Adafruit IO. The app provides real-time monitoring, alerts, predictions, and notifications when crowd density reaches critical levels.

## Architecture Components

### 1. Data Layer
- **Remote Data Source**: Interfaces with Adafruit IO API to fetch sensor data (eCO2, TVOC, EtOH, IAQ)
- **Local Database**: Room database to store historical sensor data and predictions
- **Repository**: Mediates between data sources and the rest of the app

### 2. Domain Layer
- **Use Cases**: Business logic for crowd density calculation, prediction, and alert generation
- **Models**: Data models for sensor readings, crowd density, predictions, and alerts
- **ML Model**: LSTM model for crowd density prediction

### 3. Presentation Layer
- **ViewModels**: Manage UI state and business logic for each screen
- **UI Components**: Activities and Fragments for different screens
- **Real-time Graphs**: MPAndroidChart for visualizing crowd density trends

### 4. Service Layer
- **Firebase Cloud Messaging**: For push notifications
- **Twilio Service**: For SMS alerts
- **Background Service**: For continuous monitoring even when app is in background

## Data Flow

1. **Data Collection**:
   - App fetches sensor data from Adafruit IO at regular intervals
   - Raw sensor data is normalized using predefined ranges

2. **Crowd Density Calculation**:
   - Normalized sensor data is fed into the ML model
   - Model calculates current crowd density level
   - Result is classified into Low, Medium, High, or Critical

3. **Prediction**:
   - LSTM model uses historical data to predict crowd density for next 20 minutes
   - Predictions are stored and displayed on graphs

4. **Alerting System**:
   - When crowd density reaches High or Critical levels:
     - In-app alarm is triggered with warning sound
     - Push notification is sent via Firebase
     - SMS alert is sent via Twilio
     - Alert screen is displayed with recommendations

## Technical Stack

- **Language**: Kotlin
- **Architecture Pattern**: MVVM (Model-View-ViewModel)
- **Dependency Injection**: Hilt
- **Asynchronous Programming**: Kotlin Coroutines and Flow
- **Networking**: Retrofit for API calls
- **Local Database**: Room
- **UI Components**: Material Design Components
- **Charts**: MPAndroidChart
- **ML Framework**: TensorFlow Lite
- **Notifications**: Firebase Cloud Messaging
- **SMS**: Twilio API

## Screens

1. **Dashboard**: Main screen showing current crowd density, status, and quick stats
2. **Monitoring**: Detailed view with real-time graphs and numerical data
3. **Prediction**: Shows crowd density predictions for the next 20 minutes
4. **Alarm**: Triggered when crowd density is critical, with warning sound
5. **Settings**: Configure app settings, notification preferences, etc.

## Background Processing

- Background service to continuously monitor crowd density
- WorkManager for scheduling periodic data fetching
- Foreground service notification when actively monitoring

## Security Considerations

- API keys stored securely using the Android Keystore System
- Data encryption for locally stored sensitive information
- Secure communication with backend services using HTTPS
