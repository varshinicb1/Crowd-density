# Crowd Monitoring App UI Design

## Theme: Sci-Fi Dark Theme

### Color Palette
- **Primary Color**: #1A1B4B (Deep Space Blue)
- **Secondary Color**: #4E11A8 (Cosmic Purple)
- **Accent Color**: #00E5FF (Neon Cyan)
- **Background Color**: #121212 (Dark Matter)
- **Surface Color**: #1E1E1E (Dark Nebula)
- **Error Color**: #FF5252 (Alert Red)
- **Warning Color**: #FFD600 (Warning Yellow)
- **Success Color**: #00E676 (Safe Green)
- **Text Primary**: #FFFFFF (White)
- **Text Secondary**: #B0B0B0 (Light Gray)

### Typography
- **Primary Font**: "Exo 2" - A modern, geometric sans-serif font with a tech feel
- **Secondary Font**: "Rajdhani" - A futuristic font with uniform stroke widths
- **Monospace Font**: "Share Tech Mono" - For displaying sensor data and metrics

### UI Elements

#### Common Elements
- **Status Bar**: Transparent with white icons
- **Navigation Bar**: #121212 with glowing cyan accents
- **Buttons**: Gradient from #4E11A8 to #1A1B4B with cyan borders
- **Cards**: Semi-transparent #1E1E1E with subtle blue glow
- **Dividers**: Thin #00E5FF lines
- **Icons**: Outlined style with cyan glow effects
- **Switches**: Neon cyan when active, dark purple when inactive
- **Progress Indicators**: Pulsing cyan circular indicators

#### Dashboard Screen
- **Header**: App name "Crowd Monitoring" with futuristic logo
- **Current Status Card**: Large card showing current crowd density level
  - Low: Glowing green indicator
  - Medium: Glowing yellow indicator
  - High: Glowing orange indicator
  - Critical: Pulsing red indicator with warning symbols
- **Quick Stats**: Three smaller cards showing key metrics
  - Current crowd count (estimated)
  - Trend indicator (increasing/decreasing)
  - Time since last critical alert
- **Sensor Readings**: Horizontal scrollable cards showing raw sensor data
  - eCO2 levels with mini graph
  - TVOC levels with mini graph
  - EtOH levels with mini graph
  - IAQ levels with mini graph
- **Navigation**: Bottom navigation with glowing icons

#### Monitoring Screen
- **Real-time Graph**: Large graph showing crowd density over time
  - Dark background with grid lines
  - Gradient line from blue to cyan for normal levels
  - Gradient line from yellow to red for high/critical levels
  - Time markers with futuristic timestamp format
- **Current Readings**: Digital display with monospace font showing exact values
- **Time Controls**: Buttons to adjust time range (1h, 6h, 24h, 7d)
- **Export Options**: Share and download buttons for data

#### Prediction Screen
- **Prediction Graph**: Showing predicted crowd density for next 20 minutes
  - Current data in solid line
  - Predicted data in dashed line with confidence interval band
- **Prediction Stats**: Cards showing:
  - Peak predicted density
  - Time until next critical level
  - Confidence percentage
- **Historical Accuracy**: Small graph showing prediction accuracy over time

#### Alarm Screen
- **Warning Banner**: Large pulsing red banner with "CRITICAL ALERT" text
- **Alert Details**: Information about the current critical situation
- **Animated Warning Symbol**: Pulsing hazard symbol
- **Sound Controls**: Button to mute/unmute alarm sound
- **Action Buttons**: 
  - "Acknowledge" button
  - "View Details" button
  - "Emergency Contacts" button
- **Countdown Timer**: Time since alert was triggered

#### Settings Screen
- **Notification Settings**: Toggle switches for different alert types
- **Sound Settings**: Controls for alarm volume and tone
- **Display Settings**: Theme options and display preferences
- **Data Settings**: Frequency of data updates and storage options
- **Account Settings**: Twilio and other service configurations

### Animations and Effects
- **Transitions**: Smooth fade transitions between screens
- **Loading**: Sci-fi inspired loading animations with particle effects
- **Alerts**: Pulsing glow effects for critical alerts
- **Graphs**: Animated data points and smooth line animations
- **Buttons**: Subtle hover and press effects with glow

### Special Features
- **Holographic Elements**: 3D-like depth effects for important data
- **Particle Effects**: Background subtle particle animations
- **Data Visualization**: Advanced visualizations for crowd density
- **Augmented Reality View**: Optional AR view showing crowd heat map (future feature)

### Responsive Design
- **Phone Layout**: Optimized for portrait mode with scrollable content
- **Tablet Layout**: Two-column layout with expanded graphs and controls
- **Landscape Mode**: Reorganized layout with side-by-side panels

### Accessibility
- **High Contrast Mode**: Enhanced contrast option for visibility
- **Font Scaling**: Support for system font size adjustments
- **TalkBack Support**: Full screen reader compatibility
- **Alternative Alert Methods**: Visual, auditory, and haptic feedback options
