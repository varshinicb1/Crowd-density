# Crowd Monitoring App Data Flow

## Adafruit IO Integration

### Data Sources
- **eCO2 Feed**: varshinicb99/feeds/eCO2
- **EtOH Feed**: varshinicb99/feeds/EtOH
- **TVOC Feed**: varshinicb99/feeds/tvoc
- **Indoor AQI Feed**: varshinicb99/feeds/indoor-aqi

### Authentication
- **Username**: varshinicb99
- **API Key**: aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe

### Data Retrieval Process
1. **Initialization**:
   - App initializes Adafruit IO client with credentials
   - Establishes connection to the feeds

2. **Periodic Data Fetching**:
   - Background service fetches data at configurable intervals (default: 30 seconds)
   - Uses WorkManager for reliable scheduling even when app is in background

3. **Data Processing**:
   - Raw sensor data is parsed and validated
   - Values are normalized using predefined ranges:
     - eCO2 (ppm): 400 to 5000
     - TVOC (ppb): 0 to 1000
     - EtOH (ppb): 0 to 1000
     - IAQ (unitless): 0 to 500

4. **Storage**:
   - Raw and normalized data stored in local Room database
   - Timestamp added for time-series analysis
   - Historical data maintained for prediction model training

## Crowd Density Calculation

### Linear Model Implementation
1. **Feature Preparation**:
   - Normalized sensor values used as features:
     - C_norm: Normalized eCO2
     - V_norm: Normalized TVOC
     - E_norm: Normalized EtOH
     - I_norm: Normalized IAQ

2. **Model Application**:
   - Apply linear weights to normalized features:
     - Density = (w1 × C_norm) + (w2 × V_norm) + (w3 × E_norm) + (w4 × I_norm)
   - Weights determined from pre-trained model

3. **Classification**:
   - Classify calculated density into categories:
     - Low: < 0.3
     - Medium: 0.3 to < 0.7
     - High: 0.7 to < 1.0
     - Critical: ≥ 1.0

### LSTM Model for Prediction

1. **Input Preparation**:
   - Time series of historical normalized sensor data
   - Sequence length: Last 60 minutes of data (configurable)
   - Features: All four normalized sensor values

2. **Model Architecture**:
   - Input Layer: Shape (sequence_length, num_features)
   - LSTM Layer 1: 64 units with return sequences
   - Dropout Layer 1: 0.2 rate
   - LSTM Layer 2: 32 units
   - Dropout Layer 2: 0.2 rate
   - Dense Layer: 1 unit (output)

3. **Prediction Process**:
   - Model predicts crowd density for next 20 minutes
   - Predictions made at 1-minute intervals
   - Confidence intervals calculated based on model uncertainty

4. **Crowd Count Estimation**:
   - Crowd density converted to estimated people count
   - Uses calibration factor based on venue capacity
   - Formula: People Count = Density × Calibration Factor

## Data Visualization

### Real-time Graphs
1. **Time Series Graph**:
   - X-axis: Time (configurable range)
   - Y-axis: Crowd density value
   - Color-coded based on density classification
   - Moving average line for trend visualization

2. **Prediction Graph**:
   - Current data in solid line
   - Predicted data in dashed line
   - Confidence interval shown as shaded area
   - Critical threshold line highlighted

3. **Sensor Value Graphs**:
   - Individual graphs for each sensor value
   - Normalized and raw value options
   - Correlation visualization between sensors

### Dashboard Metrics
1. **Current Status**:
   - Latest crowd density value and classification
   - Trend indicator (increasing/decreasing/stable)
   - Time since last update

2. **Historical Stats**:
   - Daily/weekly/monthly averages
   - Peak times visualization
   - Pattern recognition insights

## Alert System Triggers

1. **Threshold-based Alerts**:
   - High level: Alert notification
   - Critical level: Full alarm with sound

2. **Prediction-based Alerts**:
   - Alert when prediction shows critical level within next 20 minutes
   - Confidence level included in alert

3. **Rate of Change Alerts**:
   - Alert on rapid increase in crowd density
   - Configurable sensitivity settings
