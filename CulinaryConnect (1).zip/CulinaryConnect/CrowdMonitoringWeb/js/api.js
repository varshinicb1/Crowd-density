/**
 * Crowd Monitoring Web Application - API Integration
 * Created by: Manus for Varshini CB, Renesas
 * 
 * This file contains the API integration for the Crowd Monitoring web application.
 * It handles communication with Adafruit IO and data processing.
 */

// Adafruit IO API base URL
const ADAFRUIT_IO_URL = 'https://io.adafruit.com/api/v2';

/**
 * Fetch latest data from Adafruit IO
 * @returns {Promise<Object>} The processed sensor data
 */
async function fetchLatestData() {
    try {
        // Get settings
        const settings = getAdafruitSettings();
        
        // Fetch data from each feed
        const [eco2Data, tvocData, etohData, iaqData] = await Promise.all([
            fetchFeedData(settings.username, settings.eco2Feed, settings.key),
            fetchFeedData(settings.username, settings.tvocFeed, settings.key),
            fetchFeedData(settings.username, settings.etohFeed, settings.key),
            fetchFeedData(settings.username, settings.iaqFeed, settings.key)
        ]);
        
        // Process data
        const processedData = processData(eco2Data, tvocData, etohData, iaqData);
        
        return processedData;
    } catch (error) {
        console.error('Error fetching data:', error);
        throw error;
    }
}

/**
 * Fetch historical data from Adafruit IO
 * @param {string} period - The time period to fetch (day, week, month)
 * @returns {Promise<Object>} The processed historical data
 */
async function fetchHistoricalData(period) {
    try {
        // Get settings
        const settings = getAdafruitSettings();
        
        // Determine start time based on period
        const endTime = new Date();
        let startTime;
        
        switch (period) {
            case 'day':
                startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000);
                break;
            case 'week':
                startTime = new Date(endTime.getTime() - 7 * 24 * 60 * 60 * 1000);
                break;
            case 'month':
                startTime = new Date(endTime.getTime() - 30 * 24 * 60 * 60 * 1000);
                break;
            default:
                startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000);
        }
        
        // Format times for API
        const startStr = startTime.toISOString();
        const endStr = endTime.toISOString();
        
        // Fetch data from each feed
        const [eco2History, tvocHistory, etohHistory, iaqHistory] = await Promise.all([
            fetchFeedHistory(settings.username, settings.eco2Feed, settings.key, startStr, endStr),
            fetchFeedHistory(settings.username, settings.tvocFeed, settings.key, startStr, endStr),
            fetchFeedHistory(settings.username, settings.etohFeed, settings.key, startStr, endStr),
            fetchFeedHistory(settings.username, settings.iaqFeed, settings.key, startStr, endStr)
        ]);
        
        // Process historical data
        const processedHistory = processHistoricalData(eco2History, tvocHistory, etohHistory, iaqHistory);
        
        return processedHistory;
    } catch (error) {
        console.error('Error fetching historical data:', error);
        throw error;
    }
}

/**
 * Fetch data from a specific Adafruit IO feed
 * @param {string} username - The Adafruit IO username
 * @param {string} feed - The feed name
 * @param {string} key - The Adafruit IO key
 * @returns {Promise<Object>} The feed data
 */
async function fetchFeedData(username, feed, key) {
    try {
        const url = `${ADAFRUIT_IO_URL}/${username}/feeds/${feed}/data/last`;
        const response = await fetch(url, {
            headers: {
                'X-AIO-Key': key
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error(`Error fetching feed ${feed}:`, error);
        throw error;
    }
}

/**
 * Fetch historical data from a specific Adafruit IO feed
 * @param {string} username - The Adafruit IO username
 * @param {string} feed - The feed name
 * @param {string} key - The Adafruit IO key
 * @param {string} start - The start time (ISO string)
 * @param {string} end - The end time (ISO string)
 * @returns {Promise<Array>} The feed history data
 */
async function fetchFeedHistory(username, feed, key, start, end) {
    try {
        const url = `${ADAFRUIT_IO_URL}/${username}/feeds/${feed}/data?start_time=${start}&end_time=${end}`;
        const response = await fetch(url, {
            headers: {
                'X-AIO-Key': key
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error(`Error fetching feed history for ${feed}:`, error);
        throw error;
    }
}

/**
 * Process sensor data to calculate crowd density
 * @param {Object} eco2Data - The eCO2 data
 * @param {Object} tvocData - The TVOC data
 * @param {Object} etohData - The EtOH data
 * @param {Object} iaqData - The IAQ data
 * @returns {Object} The processed data
 */
function processData(eco2Data, tvocData, etohData, iaqData) {
    // Extract values
    const eco2 = parseInt(eco2Data.value);
    const tvoc = parseInt(tvocData.value);
    const etoh = parseInt(etohData.value);
    const iaq = parseInt(iaqData.value);
    
    // Calculate crowd density using the algorithm from the provided code
    // This is a simplified version of the algorithm
    const normalizedEco2 = normalizeValue(eco2, 400, 2000);
    const normalizedTvoc = normalizeValue(tvoc, 0, 1000);
    const normalizedEtoh = normalizeValue(etoh, 0, 1000);
    const normalizedIaq = normalizeValue(iaq, 0, 500);
    
    // Calculate crowd density (weighted average)
    const density = (
        normalizedEco2 * 0.4 +
        normalizedTvoc * 0.3 +
        normalizedEtoh * 0.2 +
        normalizedIaq * 0.1
    );
    
    // Estimate crowd count based on density
    // This is a simplified model - in a real application, this would be calibrated
    const crowdCount = Math.round(density * 350);
    
    // Create timestamp
    const timestamp = new Date(eco2Data.created_at).getTime();
    
    return {
        eco2,
        tvoc,
        etoh,
        iaq,
        density,
        crowdCount,
        timestamp
    };
}

/**
 * Process historical sensor data
 * @param {Array} eco2History - The eCO2 history data
 * @param {Array} tvocHistory - The TVOC history data
 * @param {Array} etohHistory - The EtOH history data
 * @param {Array} iaqHistory - The IAQ history data
 * @returns {Object} The processed historical data
 */
function processHistoricalData(eco2History, tvocHistory, etohHistory, iaqHistory) {
    // Create arrays for each data type
    const timestamps = [];
    const eco2Values = [];
    const tvocValues = [];
    const etohValues = [];
    const iaqValues = [];
    const densityValues = [];
    const crowdCountValues = [];
    
    // Process each data point
    // Note: This assumes data points are roughly aligned in time
    // In a real application, you would need to align timestamps
    for (let i = 0; i < eco2History.length; i++) {
        if (i >= eco2History.length || i >= tvocHistory.length || 
            i >= etohHistory.length || i >= iaqHistory.length) {
            break;
        }
        
        const eco2 = parseInt(eco2History[i].value);
        const tvoc = parseInt(tvocHistory[i].value);
        const etoh = parseInt(etohHistory[i].value);
        const iaq = parseInt(iaqHistory[i].value);
        
        // Calculate normalized values
        const normalizedEco2 = normalizeValue(eco2, 400, 2000);
        const normalizedTvoc = normalizeValue(tvoc, 0, 1000);
        const normalizedEtoh = normalizeValue(etoh, 0, 1000);
        const normalizedIaq = normalizeValue(iaq, 0, 500);
        
        // Calculate crowd density
        const density = (
            normalizedEco2 * 0.4 +
            normalizedTvoc * 0.3 +
            normalizedEtoh * 0.2 +
            normalizedIaq * 0.1
        );
        
        // Estimate crowd count
        const crowdCount = Math.round(density * 350);
        
        // Add to arrays
        timestamps.push(new Date(eco2History[i].created_at).getTime());
        eco2Values.push(eco2);
        tvocValues.push(tvoc);
        etohValues.push(etoh);
        iaqValues.push(iaq);
        densityValues.push(density);
        crowdCountValues.push(crowdCount);
    }
    
    return {
        timestamps,
        eco2: eco2Values,
        tvoc: tvocValues,
        etoh: etohValues,
        iaq: iaqValues,
        density: densityValues,
        crowdCount: crowdCountValues
    };
}

/**
 * Normalize a value between 0 and 1
 * @param {number} value - The value to normalize
 * @param {number} min - The minimum value
 * @param {number} max - The maximum value
 * @returns {number} The normalized value
 */
function normalizeValue(value, min, max) {
    // Clamp value between min and max
    const clampedValue = Math.max(min, Math.min(max, value));
    
    // Normalize to 0-1 range
    return (clampedValue - min) / (max - min);
}

/**
 * Generate crowd density prediction
 * @param {Object} currentData - The current sensor data
 * @param {number} minutes - The number of minutes to predict
 * @returns {Promise<Object>} The prediction data
 */
async function generatePrediction(currentData, minutes) {
    try {
        if (!currentData) {
            throw new Error('No current data available for prediction');
        }
        
        // In a real application, this would use the LSTM model
        // For this demo, we'll use a simple simulation
        
        // Create arrays for prediction
        const timestamps = [];
        const densityValues = [];
        const crowdCountValues = [];
        const confidenceValues = [];
        
        // Current values
        let currentDensity = currentData.density;
        let currentCrowdCount = currentData.crowdCount;
        const now = new Date();
        
        // Generate prediction for each minute
        for (let i = 0; i <= minutes; i++) {
            // Add current timestamp
            const timestamp = new Date(now.getTime() + i * 60 * 1000).getTime();
            timestamps.push(timestamp);
            
            // Add current values
            densityValues.push(currentDensity);
            crowdCountValues.push(currentCrowdCount);
            
            // Calculate confidence (decreases with time)
            const confidence = Math.max(0.5, 1 - (i / (minutes * 2)));
            confidenceValues.push(confidence);
            
            // Update values for next minute
            // This is a simple simulation - in a real application, this would use the LSTM model
            // We'll simulate some realistic crowd behavior
            
            // Time-based factors (simulating typical crowd patterns)
            const hourOfDay = (now.getHours() + Math.floor(i / 60)) % 24;
            const minuteOfHour = (now.getMinutes() + i % 60) % 60;
            
            // Simulate peak hours
            const isPeakHour = (hourOfDay >= 8 && hourOfDay <= 10) || 
                              (hourOfDay >= 12 && hourOfDay <= 14) || 
                              (hourOfDay >= 17 && hourOfDay <= 19);
            
            // Simulate random fluctuations
            const randomFactor = (Math.random() - 0.5) * 0.05;
            
            // Calculate density change
            let densityChange = randomFactor;
            
            if (isPeakHour) {
                // During peak hours, density tends to increase
                densityChange += 0.02;
            } else {
                // During off-peak hours, density tends to decrease
                densityChange -= 0.01;
            }
            
            // Apply change
            currentDensity = Math.max(0, Math.min(1.5, currentDensity + densityChange));
            
            // Update crowd count based on density
            currentCrowdCount = Math.round(currentDensity * 350);
        }
        
        return {
            timestamps,
            density: densityValues,
            crowdCount: crowdCountValues,
            confidence: confidenceValues
        };
    } catch (error) {
        console.error('Error generating prediction:', error);
        throw error;
    }
}

/**
 * Test connection to Adafruit IO
 * @returns {Promise<boolean>} Whether the connection was successful
 */
async function testAdafruitConnection() {
    try {
        // Get settings
        const settings = getAdafruitSettings();
        
        // Test connection by fetching user info
        const url = `${ADAFRUIT_IO_URL}/${settings.username}`;
        const response = await fetch(url, {
            headers: {
                'X-AIO-Key': settings.key
            }
        });
        
        return response.ok;
    } catch (error) {
        console.error('Error testing connection:', error);
        return false;
    }
}

/**
 * Get Adafruit IO settings
 * @returns {Object} The Adafruit IO settings
 */
function getAdafruitSettings() {
    // Try to get settings from application state
    if (window.appState && window.appState.adafruitSettings) {
        return window.appState.adafruitSettings;
    }
    
    // Try to get settings from localStorage
    const savedSettings = localStorage.getItem('adafruitSettings');
    if (savedSettings) {
        return JSON.parse(savedSettings);
    }
    
    // Return default settings
    return {
        username: 'varshinicb99',
        key: 'aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe',
        eco2Feed: 'eCO2',
        tvocFeed: 'tvoc',
        etohFeed: 'EtOH',
        iaqFeed: 'indoor-aqi'
    };
}
