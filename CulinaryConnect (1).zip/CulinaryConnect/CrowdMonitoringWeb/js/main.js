/**
 * Crowd Monitoring Web Application - Main JavaScript
 * Created by: Manus for Varshini CB, Renesas
 * 
 * This file contains the main application logic for the Crowd Monitoring web application.
 */

// Application state
let appState = {
    currentPage: 'dashboard',
    currentData: null,
    predictionData: null,
    alertHistory: [],
    settings: {
        criticalThreshold: 1.0,
        highThreshold: 0.7,
        enableSound: true,
        enableBrowser: true,
        enableEmail: false,
        emailAddress: '',
        refreshInterval: 30,
        predictionInterval: 300
    },
    adafruitSettings: {
        username: 'varshinicb99',
        key: 'aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe',
        eco2Feed: 'eCO2',
        tvocFeed: 'tvoc',
        etohFeed: 'EtOH',
        iaqFeed: 'indoor-aqi'
    }
};

// DOM Elements
const pages = document.querySelectorAll('.page');
const navLinks = document.querySelectorAll('.nav-link');

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Crowd Monitoring Web Application...');
    
    // Initialize navigation
    initNavigation();
    
    // Initialize settings from localStorage
    loadSettings();
    
    // Initialize charts
    initDashboardCharts();
    initMonitoringCharts();
    initPredictionCharts();
    
    // Initialize event listeners
    initEventListeners();
    
    // Fetch initial data
    fetchData();
    
    // Start data polling
    startDataPolling();
    
    // Request notification permission
    if (appState.settings.enableBrowser) {
        requestNotificationPermission();
    }
    
    console.log('Application initialized successfully');
});

/**
 * Initialize navigation
 */
function initNavigation() {
    // Add click event listeners to navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.getAttribute('data-page');
            navigateToPage(page);
        });
    });
    
    // Check for hash in URL
    const hash = window.location.hash.substring(1);
    if (hash) {
        navigateToPage(hash);
    }
}

/**
 * Navigate to a specific page
 * @param {string} page - The page to navigate to
 */
function navigateToPage(page) {
    // Update active page
    pages.forEach(p => {
        p.classList.remove('active');
    });
    
    const targetPage = document.getElementById(`${page}-page`);
    if (targetPage) {
        targetPage.classList.add('active');
        appState.currentPage = page;
    }
    
    // Update active navigation link
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-page') === page) {
            link.classList.add('active');
        }
    });
    
    // Update URL hash
    window.location.hash = page;
    
    // Refresh charts if needed
    if (page === 'monitoring') {
        if (densityChart) densityChart.update();
        if (sensorChart) sensorChart.update();
        if (historyChart) historyChart.update();
    } else if (page === 'prediction') {
        if (predictionDetailChart) predictionDetailChart.update();
        updatePredictionPage();
    }
}

/**
 * Initialize event listeners
 */
function initEventListeners() {
    // Refresh button
    document.getElementById('refresh-btn').addEventListener('click', fetchData);
    
    // Monitoring refresh button
    document.getElementById('monitoring-refresh-btn').addEventListener('click', fetchData);
    
    // Update prediction button
    document.getElementById('update-prediction-btn').addEventListener('click', updatePrediction);
    
    // Prediction refresh button
    document.getElementById('prediction-refresh-btn').addEventListener('click', updatePrediction);
    
    // History period select
    document.getElementById('history-period').addEventListener('change', (e) => {
        fetchHistoricalData(e.target.value);
    });
    
    // Alert filter select
    document.getElementById('alert-filter').addEventListener('change', (e) => {
        filterAlerts(e.target.value);
    });
    
    // Critical threshold slider
    const criticalThresholdSlider = document.getElementById('critical-threshold');
    const criticalThresholdValue = document.getElementById('critical-threshold-value');
    
    criticalThresholdSlider.addEventListener('input', (e) => {
        const value = parseFloat(e.target.value);
        criticalThresholdValue.textContent = value.toFixed(2);
    });
    
    // High threshold slider
    const highThresholdSlider = document.getElementById('high-threshold');
    const highThresholdValue = document.getElementById('high-threshold-value');
    
    highThresholdSlider.addEventListener('input', (e) => {
        const value = parseFloat(e.target.value);
        highThresholdValue.textContent = value.toFixed(2);
    });
    
    // Save alert settings button
    document.getElementById('save-alert-settings').addEventListener('click', saveAlertSettings);
    
    // Test alert button
    document.getElementById('test-alert').addEventListener('click', testAlert);
    
    // Save Adafruit settings button
    document.getElementById('save-adafruit-settings').addEventListener('click', saveAdafruitSettings);
    
    // Test connection button
    document.getElementById('test-connection').addEventListener('click', testConnection);
    
    // Save app settings button
    document.getElementById('save-app-settings').addEventListener('click', saveAppSettings);
    
    // Reset settings button
    document.getElementById('reset-settings').addEventListener('click', resetSettings);
    
    // Alert modal close button
    document.getElementById('alert-modal-close').addEventListener('click', closeAlertModal);
}

/**
 * Start polling for data
 */
function startDataPolling() {
    // Set up interval for data refresh
    setInterval(() => {
        fetchData();
    }, appState.settings.refreshInterval * 1000);
    
    // Set up interval for prediction update
    setInterval(() => {
        updatePrediction();
    }, appState.settings.predictionInterval * 1000);
}

/**
 * Fetch latest data
 */
async function fetchData() {
    try {
        // Show loading state
        document.getElementById('connection-status').innerHTML = '<i class="fas fa-circle-notch fa-spin"></i><span>Fetching...</span>';
        
        // Fetch data from API
        const data = await fetchLatestData();
        
        // Update application state
        appState.currentData = data;
        
        // Update UI
        updateUI(data);
        
        // Check for alerts
        checkAlerts(data);
        
        // Update connection status
        document.getElementById('connection-status').innerHTML = '<i class="fas fa-circle"></i><span>Connected</span>';
        document.getElementById('connection-status').className = 'status-indicator status-low';
        
        // Update last updated time
        document.getElementById('last-updated').textContent = 'just now';
        
        console.log('Data updated:', data);
    } catch (error) {
        console.error('Error fetching data:', error);
        
        // Update connection status
        document.getElementById('connection-status').innerHTML = '<i class="fas fa-exclamation-circle"></i><span>Error</span>';
        document.getElementById('connection-status').className = 'status-indicator status-critical';
    }
}

/**
 * Update the UI with new data
 * @param {Object} data - The sensor data
 */
function updateUI(data) {
    // Update dashboard values
    document.getElementById('density-value').textContent = data.density.toFixed(2);
    document.getElementById('count-value').textContent = data.crowdCount;
    
    // Update density status
    updateDensityStatus(data.density, 'density-status');
    updateDensityStatus(data.density, 'monitoring-density-status');
    updateDensityStatus(data.density, 'current-density-status');
    
    // Update sensor values
    document.getElementById('eco2-value').textContent = data.eco2;
    document.getElementById('tvoc-value').textContent = data.tvoc;
    document.getElementById('etoh-value').textContent = data.etoh;
    document.getElementById('iaq-value').textContent = data.iaq;
    
    // Update current density in prediction page
    document.getElementById('current-density-value').textContent = data.density.toFixed(2);
    
    // Update monitoring charts
    updateMonitoringCharts(data);
}

/**
 * Update density status indicator
 * @param {number} density - The density value
 * @param {string} elementId - The ID of the status element
 */
function updateDensityStatus(density, elementId) {
    const statusElement = document.getElementById(elementId);
    let statusClass = 'status-low';
    let statusText = 'Low';
    
    if (density >= appState.settings.criticalThreshold) {
        statusClass = 'status-critical';
        statusText = 'Critical';
    } else if (density >= appState.settings.highThreshold) {
        statusClass = 'status-high';
        statusText = 'High';
    } else if (density >= 0.3) {
        statusClass = 'status-medium';
        statusText = 'Medium';
    }
    
    statusElement.className = `status-indicator ${statusClass}`;
    statusElement.innerHTML = `<i class="fas fa-circle"></i><span>${statusText}</span>`;
}

/**
 * Update prediction data
 */
async function updatePrediction() {
    try {
        // Fetch prediction data
        const prediction = await generatePrediction(appState.currentData, 20);
        
        // Update application state
        appState.predictionData = prediction;
        
        // Update prediction charts
        updatePredictionCharts();
        
        // Update prediction page if active
        if (appState.currentPage === 'prediction') {
            updatePredictionPage();
        }
        
        // Update dashboard prediction value
        const peakDensity = Math.max(...prediction.density);
        document.getElementById('prediction-value').textContent = peakDensity.toFixed(2);
        
        // Update confidence value
        const avgConfidence = prediction.confidence.reduce((sum, val) => sum + val, 0) / prediction.confidence.length;
        document.getElementById('confidence-value').textContent = `${Math.round(avgConfidence * 100)}%`;
        
        console.log('Prediction updated:', prediction);
    } catch (error) {
        console.error('Error updating prediction:', error);
    }
}

/**
 * Update prediction page with latest prediction data
 */
function updatePredictionPage() {
    if (!appState.predictionData) return;
    
    const prediction = appState.predictionData;
    
    // Update timestamp
    const now = new Date();
    document.getElementById('prediction-timestamp').textContent = now.toLocaleString();
    
    // Find peak density and its time
    let peakDensity = 0;
    let peakIndex = 0;
    
    prediction.density.forEach((density, index) => {
        if (density > peakDensity) {
            peakDensity = density;
            peakIndex = index;
        }
    });
    
    // Update peak density value
    document.getElementById('peak-density-value').textContent = peakDensity.toFixed(2);
    
    // Update peak density status
    updateDensityStatus(peakDensity, 'peak-density-status');
    
    // Update peak time
    const peakTime = peakIndex === 0 ? 'now' : 
                    peakIndex === 1 ? '1 minute' : 
                    `${peakIndex} minutes`;
    document.getElementById('peak-time').textContent = peakTime;
    
    // Update predicted count
    const peakCount = prediction.crowdCount[peakIndex];
    document.getElementById('predicted-count-value').textContent = peakCount;
    
    // Update confidence
    const avgConfidence = prediction.confidence.reduce((sum, val) => sum + val, 0) / prediction.confidence.length;
    document.getElementById('prediction-confidence-value').textContent = `${Math.round(avgConfidence * 100)}%`;
    document.querySelector('.confidence-level').style.width = `${Math.round(avgConfidence * 100)}%`;
    
    // Update prediction analysis
    const densityLevel = peakDensity >= appState.settings.criticalThreshold ? 'Critical' :
                        peakDensity >= appState.settings.highThreshold ? 'High' :
                        peakDensity >= 0.3 ? 'Medium' : 'Low';
    
    const willReachCritical = prediction.density.some(d => d >= appState.settings.criticalThreshold);
    
    let analysisText = `Based on current sensor readings and historical patterns, crowd density is expected to ${peakDensity > appState.currentData.density ? 'increase' : 'decrease'} over the next 20 minutes, reaching a peak of approximately ${peakDensity.toFixed(2)} (${densityLevel}) in about ${peakTime}. This corresponds to an estimated ${peakCount} people in the monitored area.`;
    
    analysisText += `\n\nThe prediction model has ${avgConfidence >= 0.8 ? 'high' : 'moderate'} confidence (${Math.round(avgConfidence * 100)}%) in this forecast. `;
    
    if (willReachCritical) {
        analysisText += 'Critical density levels are expected during this period. Immediate action is recommended to manage crowd flow.';
    } else if (peakDensity >= appState.settings.highThreshold) {
        analysisText += 'No critical density levels are expected, but crowd density will reach high levels. Monitoring and preparation for crowd management is recommended.';
    } else {
        analysisText += 'No critical density levels are expected during this period, but monitoring should continue as conditions may change.';
    }
    
    document.getElementById('prediction-analysis').textContent = analysisText;
}

/**
 * Check for alert conditions
 * @param {Object} data - The sensor data
 */
function checkAlerts(data) {
    // Check for critical alert
    if (data.density >= appState.settings.criticalThreshold) {
        triggerAlert({
            type: 'critical',
            message: 'Crowd density has reached CRITICAL level!',
            density: data.density,
            crowdCount: data.crowdCount,
            timestamp: new Date().getTime()
        });
    }
    // Check for high alert
    else if (data.density >= appState.settings.highThreshold) {
        triggerAlert({
            type: 'high',
            message: 'Crowd density has reached HIGH level!',
            density: data.density,
            crowdCount: data.crowdCount,
            timestamp: new Date().getTime()
        });
    }
    
    // Check prediction for potential alerts
    if (appState.predictionData) {
        const criticalIndex = appState.predictionData.density.findIndex(d => d >= appState.settings.criticalThreshold);
        
        if (criticalIndex !== -1 && data.density < appState.settings.criticalThreshold) {
            const timeToMinutes = criticalIndex;
            const timeString = timeToMinutes === 0 ? 'now' : 
                              timeToMinutes === 1 ? '1 minute' : 
                              `${timeToMinutes} minutes`;
            
            triggerAlert({
                type: 'prediction',
                message: `Critical crowd density predicted in ${timeString}!`,
                density: appState.predictionData.density[criticalIndex],
                crowdCount: appState.predictionData.crowdCount[criticalIndex],
                timeToMinutes: timeToMinutes,
                confidence: appState.predictionData.confidence[criticalIndex],
                timestamp: new Date().getTime()
            });
        }
    }
}

/**
 * Trigger an alert
 * @param {Object} alertData - The alert data
 */
function triggerAlert(alertData) {
    console.log('Alert triggered:', alertData);
    
    // Add to alert history
    appState.alertHistory.unshift(alertData);
    
    // Limit history size
    if (appState.alertHistory.length > 100) {
        appState.alertHistory.pop();
    }
    
    // Update alert history display
    updateAlertHistory();
    
    // Update recent alerts on dashboard
    updateRecentAlerts();
    
    // Show alert modal for critical alerts
    if (alertData.type === 'critical') {
        showAlertModal(alertData);
    }
    
    // Play sound if enabled
    if (appState.settings.enableSound) {
        playAlertSound(alertData.type);
    }
    
    // Show browser notification if enabled
    if (appState.settings.enableBrowser) {
        showBrowserNotification(alertData);
    }
    
    // Send email notification if enabled
    if (appState.settings.enableEmail && appState.settings.emailAddress) {
        // In a real application, this would send an email
        console.log('Email notification would be sent to:', appState.settings.emailAddress);
    }
}

/**
 * Play alert sound
 * @param {string} alertType - The type of alert
 */
function playAlertSound(alertType) {
    if (alertType === 'critical') {
        document.getElementById('critical-alert-sound').play();
    } else if (alertType === 'high') {
        document.getElementById('high-alert-sound').play();
    }
}

/**
 * Show browser notification
 * @param {Object} alertData - The alert data
 */
function showBrowserNotification(alertData) {
    if (!('Notification' in window)) {
        console.log('Browser does not support notifications');
        return;
    }
    
    if (Notification.permission === 'granted') {
        const title = alertData.type === 'critical' ? 'CRITICAL ALERT' :
                     alertData.type === 'high' ? 'HIGH ALERT' :
                     'Prediction Alert';
        
        const options = {
            body: alertData.message,
            icon: 'https://cdn-icons-png.flaticon.com/512/1680/1680012.png',
            vibrate: [200, 100, 200]
        };
        
        new Notification(title, options);
    }
}

/**
 * Request notification permission
 */
function requestNotificationPermission() {
    if (!('Notification' in window)) {
        console.log('Browser does not support notifications');
        return;
    }
    
    if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
        Notification.requestPermission();
    }
}

/**
 * Show alert modal
 * @param {Object} alertData - The alert data
 */
function showAlertModal(alertData) {
    const modal = document.getElementById('alert-modal');
    const title = document.getElementById('alert-modal-title');
    const message = document.getElementById('alert-modal-message');
    const density = document.getElementById('alert-modal-density');
    const count = document.getElementById('alert-modal-count');
    
    title.textContent = alertData.type === 'critical' ? 'CRITICAL ALERT' :
                       alertData.type === 'high' ? 'HIGH ALERT' :
                       'Prediction Alert';
    
    message.textContent = alertData.message;
    density.textContent = alertData.density.toFixed(2);
    count.textContent = alertData.crowdCount;
    
    modal.style.display = 'block';
}

/**
 * Close alert modal
 */
function closeAlertModal() {
    const modal = document.getElementById('alert-modal');
    modal.style.display = 'none';
    
    // Stop alert sound
    document.getElementById('critical-alert-sound').pause();
    document.getElementById('critical-alert-sound').currentTime = 0;
    document.getElementById('high-alert-sound').pause();
    document.getElementById('high-alert-sound').currentTime = 0;
}

/**
 * Update alert history display
 */
function updateAlertHistory() {
    const alertHistoryElement = document.getElementById('alert-history');
    const alertFilter = document.getElementById('alert-filter').value;
    
    // Filter alerts
    let filteredAlerts = appState.alertHistory;
    if (alertFilter !== 'all') {
        filteredAlerts = appState.alertHistory.filter(alert => alert.type === alertFilter);
    }
    
    // Clear current content
    alertHistoryElement.innerHTML = '';
    
    // Check if there are any alerts
    if (filteredAlerts.length === 0) {
        alertHistoryElement.innerHTML = `
            <div class="text-center text-tertiary">
                <i class="fas fa-check-circle fs-xl mb-2"></i>
                <p>No alerts in history</p>
            </div>
        `;
        return;
    }
    
    // Create alert items
    filteredAlerts.forEach(alert => {
        const alertDate = new Date(alert.timestamp);
        const timeString = alertDate.toLocaleTimeString();
        const dateString = alertDate.toLocaleDateString();
        
        const alertClass = alert.type === 'critical' ? 'card-danger' :
                          alert.type === 'high' ? 'card-warning' : '';
        
        const alertIcon = alert.type === 'critical' ? 'exclamation-triangle' :
                         alert.type === 'high' ? 'exclamation-circle' :
                         'chart-line';
        
        const alertItem = document.createElement('div');
        alertItem.className = `card ${alertClass} mb-2`;
        
        alertItem.innerHTML = `
            <div class="card-header">
                <h4 class="card-title">
                    <i class="fas fa-${alertIcon}"></i>
                    ${alert.type === 'critical' ? 'Critical Alert' :
                     alert.type === 'high' ? 'High Alert' :
                     'Prediction Alert'}
                </h4>
                <div class="font-mono fs-sm">${timeString} - ${dateString}</div>
            </div>
            <div class="card-body">
                <p>${alert.message}</p>
                <div class="d-flex justify-between mt-2">
                    <div>
                        <span class="font-mono fw-bold">${alert.density.toFixed(2)}</span>
                        <span class="fs-sm">Density</span>
                    </div>
                    <div>
                        <span class="font-mono fw-bold">${alert.crowdCount}</span>
                        <span class="fs-sm">People</span>
                    </div>
                    ${alert.type === 'prediction' ? `
                        <div>
                            <span class="font-mono fw-bold">${Math.round(alert.confidence * 100)}%</span>
                            <span class="fs-sm">Confidence</span>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
        
        alertHistoryElement.appendChild(alertItem);
    });
}

/**
 * Filter alerts by type
 * @param {string} type - The alert type to filter by
 */
function filterAlerts(type) {
    updateAlertHistory();
}

/**
 * Update recent alerts on dashboard
 */
function updateRecentAlerts() {
    const recentAlertsElement = document.getElementById('recent-alerts');
    
    // Get 3 most recent alerts
    const recentAlerts = appState.alertHistory.slice(0, 3);
    
    // Clear current content
    recentAlertsElement.innerHTML = '';
    
    // Check if there are any alerts
    if (recentAlerts.length === 0) {
        recentAlertsElement.innerHTML = `
            <div class="text-center text-tertiary">
                <i class="fas fa-check-circle fs-xl mb-2"></i>
                <p>No recent alerts</p>
            </div>
        `;
        return;
    }
    
    // Create alert items
    recentAlerts.forEach(alert => {
        const alertDate = new Date(alert.timestamp);
        const timeString = alertDate.toLocaleTimeString();
        
        const alertClass = alert.type === 'critical' ? 'text-danger' :
                          alert.type === 'high' ? 'text-warning' :
                          'text-accent';
        
        const alertIcon = alert.type === 'critical' ? 'exclamation-triangle' :
                         alert.type === 'high' ? 'exclamation-circle' :
                         'chart-line';
        
        const alertItem = document.createElement('div');
        alertItem.className = 'mb-2 pb-2';
        alertItem.style.borderBottom = '1px solid rgba(255, 255, 255, 0.1)';
        
        alertItem.innerHTML = `
            <div class="d-flex justify-between mb-1">
                <div class="${alertClass}">
                    <i class="fas fa-${alertIcon}"></i>
                    ${alert.type === 'critical' ? 'Critical Alert' :
                     alert.type === 'high' ? 'High Alert' :
                     'Prediction Alert'}
                </div>
                <div class="font-mono fs-sm">${timeString}</div>
            </div>
            <p class="mb-1">${alert.message}</p>
            <div class="d-flex justify-between">
                <div>
                    <span class="font-mono fw-bold">${alert.density.toFixed(2)}</span>
                    <span class="fs-sm">Density</span>
                </div>
                <div>
                    <span class="font-mono fw-bold">${alert.crowdCount}</span>
                    <span class="fs-sm">People</span>
                </div>
            </div>
        `;
        
        recentAlertsElement.appendChild(alertItem);
    });
}

/**
 * Save alert settings
 */
function saveAlertSettings() {
    // Get values from form
    const criticalThreshold = parseFloat(document.getElementById('critical-threshold').value);
    const highThreshold = parseFloat(document.getElementById('high-threshold').value);
    const enableSound = document.getElementById('enable-sound').checked;
    const enableBrowser = document.getElementById('enable-browser').checked;
    const enableEmail = document.getElementById('enable-email').checked;
    const emailAddress = document.getElementById('email-address').value;
    
    // Update application state
    appState.settings.criticalThreshold = criticalThreshold;
    appState.settings.highThreshold = highThreshold;
    appState.settings.enableSound = enableSound;
    appState.settings.enableBrowser = enableBrowser;
    appState.settings.enableEmail = enableEmail;
    appState.settings.emailAddress = emailAddress;
    
    // Save to localStorage
    saveSettings();
    
    // Request notification permission if enabled
    if (enableBrowser) {
        requestNotificationPermission();
    }
    
    // Show success message
    alert('Alert settings saved successfully');
}

/**
 * Test alert
 */
function testAlert() {
    // Create test alert
    const alertData = {
        type: 'critical',
        message: 'This is a test alert',
        density: appState.settings.criticalThreshold,
        crowdCount: Math.floor(appState.settings.criticalThreshold * 350),
        timestamp: new Date().getTime()
    };
    
    // Trigger alert
    triggerAlert(alertData);
}

/**
 * Save Adafruit settings
 */
function saveAdafruitSettings() {
    // Get values from form
    const username = document.getElementById('adafruit-username').value;
    const key = document.getElementById('adafruit-key').value;
    const eco2Feed = document.getElementById('eco2-feed').value;
    const tvocFeed = document.getElementById('tvoc-feed').value;
    const etohFeed = document.getElementById('etoh-feed').value;
    const iaqFeed = document.getElementById('iaq-feed').value;
    
    // Update application state
    appState.adafruitSettings.username = username;
    appState.adafruitSettings.key = key;
    appState.adafruitSettings.eco2Feed = eco2Feed;
    appState.adafruitSettings.tvocFeed = tvocFeed;
    appState.adafruitSettings.etohFeed = etohFeed;
    appState.adafruitSettings.iaqFeed = iaqFeed;
    
    // Save to localStorage
    localStorage.setItem('adafruitSettings', JSON.stringify(appState.adafruitSettings));
    
    // Show success message
    alert('Adafruit IO settings saved successfully');
}

/**
 * Test connection to Adafruit IO
 */
async function testConnection() {
    try {
        // Show loading state
        document.getElementById('test-connection').innerHTML = '<i class="fas fa-circle-notch fa-spin"></i><span>Testing...</span>';
        
        // Test connection
        const result = await testAdafruitConnection();
        
        // Show result
        if (result) {
            alert('Connection successful! Your Adafruit IO credentials are working correctly.');
        } else {
            alert('Connection failed. Please check your Adafruit IO credentials and try again.');
        }
        
        // Reset button
        document.getElementById('test-connection').innerHTML = '<i class="fas fa-plug"></i><span>Test Connection</span>';
    } catch (error) {
        console.error('Error testing connection:', error);
        
        // Show error
        alert('Error testing connection: ' + error.message);
        
        // Reset button
        document.getElementById('test-connection').innerHTML = '<i class="fas fa-plug"></i><span>Test Connection</span>';
    }
}

/**
 * Save application settings
 */
function saveAppSettings() {
    // Get values from form
    const refreshInterval = parseInt(document.getElementById('refresh-interval').value);
    const predictionInterval = parseInt(document.getElementById('prediction-interval').value);
    
    // Update application state
    appState.settings.refreshInterval = refreshInterval;
    appState.settings.predictionInterval = predictionInterval;
    
    // Save to localStorage
    saveSettings();
    
    // Show success message
    alert('Application settings saved successfully');
}

/**
 * Reset settings to defaults
 */
function resetSettings() {
    // Confirm reset
    if (!confirm('Are you sure you want to reset all settings to defaults?')) {
        return;
    }
    
    // Reset settings
    appState.settings = {
        criticalThreshold: 1.0,
        highThreshold: 0.7,
        enableSound: true,
        enableBrowser: true,
        enableEmail: false,
        emailAddress: '',
        refreshInterval: 30,
        predictionInterval: 300
    };
    
    appState.adafruitSettings = {
        username: 'varshinicb99',
        key: 'aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe',
        eco2Feed: 'eCO2',
        tvocFeed: 'tvoc',
        etohFeed: 'EtOH',
        iaqFeed: 'indoor-aqi'
    };
    
    // Save to localStorage
    saveSettings();
    localStorage.setItem('adafruitSettings', JSON.stringify(appState.adafruitSettings));
    
    // Update form values
    document.getElementById('critical-threshold').value = appState.settings.criticalThreshold;
    document.getElementById('critical-threshold-value').textContent = appState.settings.criticalThreshold.toFixed(2);
    document.getElementById('high-threshold').value = appState.settings.highThreshold;
    document.getElementById('high-threshold-value').textContent = appState.settings.highThreshold.toFixed(2);
    document.getElementById('enable-sound').checked = appState.settings.enableSound;
    document.getElementById('enable-browser').checked = appState.settings.enableBrowser;
    document.getElementById('enable-email').checked = appState.settings.enableEmail;
    document.getElementById('email-address').value = appState.settings.emailAddress;
    document.getElementById('refresh-interval').value = appState.settings.refreshInterval;
    document.getElementById('prediction-interval').value = appState.settings.predictionInterval;
    
    document.getElementById('adafruit-username').value = appState.adafruitSettings.username;
    document.getElementById('adafruit-key').value = appState.adafruitSettings.key;
    document.getElementById('eco2-feed').value = appState.adafruitSettings.eco2Feed;
    document.getElementById('tvoc-feed').value = appState.adafruitSettings.tvocFeed;
    document.getElementById('etoh-feed').value = appState.adafruitSettings.etohFeed;
    document.getElementById('iaq-feed').value = appState.adafruitSettings.iaqFeed;
    
    // Show success message
    alert('Settings reset to defaults');
}

/**
 * Load settings from localStorage
 */
function loadSettings() {
    try {
        // Load settings
        const savedSettings = localStorage.getItem('settings');
        if (savedSettings) {
            appState.settings = JSON.parse(savedSettings);
        }
        
        // Load Adafruit settings
        const savedAdafruitSettings = localStorage.getItem('adafruitSettings');
        if (savedAdafruitSettings) {
            appState.adafruitSettings = JSON.parse(savedAdafruitSettings);
        }
        
        // Update form values
        document.getElementById('critical-threshold').value = appState.settings.criticalThreshold;
        document.getElementById('critical-threshold-value').textContent = appState.settings.criticalThreshold.toFixed(2);
        document.getElementById('high-threshold').value = appState.settings.highThreshold;
        document.getElementById('high-threshold-value').textContent = appState.settings.highThreshold.toFixed(2);
        document.getElementById('enable-sound').checked = appState.settings.enableSound;
        document.getElementById('enable-browser').checked = appState.settings.enableBrowser;
        document.getElementById('enable-email').checked = appState.settings.enableEmail;
        document.getElementById('email-address').value = appState.settings.emailAddress;
        document.getElementById('refresh-interval').value = appState.settings.refreshInterval;
        document.getElementById('prediction-interval').value = appState.settings.predictionInterval;
        
        document.getElementById('adafruit-username').value = appState.adafruitSettings.username;
        document.getElementById('adafruit-key').value = appState.adafruitSettings.key;
        document.getElementById('eco2-feed').value = appState.adafruitSettings.eco2Feed;
        document.getElementById('tvoc-feed').value = appState.adafruitSettings.tvocFeed;
        document.getElementById('etoh-feed').value = appState.adafruitSettings.etohFeed;
        document.getElementById('iaq-feed').value = appState.adafruitSettings.iaqFeed;
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

/**
 * Save settings to localStorage
 */
function saveSettings() {
    try {
        localStorage.setItem('settings', JSON.stringify(appState.settings));
    } catch (error) {
        console.error('Error saving settings:', error);
    }
}
