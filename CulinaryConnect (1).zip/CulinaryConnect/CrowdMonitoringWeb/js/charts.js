/**
 * Crowd Monitoring Web Application - Charts
 * Created by: Manus for Varshini CB, Renesas
 * 
 * This file contains the chart initialization and update functions for the Crowd Monitoring web application.
 */

// Chart objects
let predictionChart = null;
let densityChart = null;
let sensorChart = null;
let historyChart = null;
let predictionDetailChart = null;

// Chart colors
const chartColors = {
    primary: '#00E5FF',
    secondary: '#4E11A8',
    danger: '#FF5252',
    warning: '#FFD600',
    success: '#AEEA00',
    eco2: '#00E5FF',
    tvoc: '#FF5252',
    etoh: '#FFD600',
    iaq: '#AEEA00',
    grid: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.7)'
};

// Critical and high thresholds
const criticalThreshold = 1.0;
const highThreshold = 0.7;

/**
 * Initialize dashboard charts
 */
function initDashboardCharts() {
    // Initialize prediction chart
    const predictionCtx = document.getElementById('prediction-chart').getContext('2d');
    
    predictionChart = new Chart(predictionCtx, {
        type: 'line',
        data: {
            labels: generateTimeLabels(20),
            datasets: [{
                label: 'Predicted Density',
                data: [],
                borderColor: chartColors.primary,
                backgroundColor: 'rgba(0, 229, 255, 0.1)',
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: chartColors.primary,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(20, 20, 50, 0.9)',
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF',
                    borderColor: 'rgba(0, 229, 255, 0.3)',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `Density: ${context.raw.toFixed(2)}`;
                        }
                    }
                },
                annotation: {
                    annotations: {
                        criticalLine: {
                            type: 'line',
                            yMin: criticalThreshold,
                            yMax: criticalThreshold,
                            borderColor: chartColors.danger,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'Critical',
                                position: 'end',
                                backgroundColor: 'rgba(255, 82, 82, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        },
                        highLine: {
                            type: 'line',
                            yMin: highThreshold,
                            yMax: highThreshold,
                            borderColor: chartColors.warning,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'High',
                                position: 'end',
                                backgroundColor: 'rgba(255, 214, 0, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 1.5,
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        },
                        callback: function(value) {
                            return value.toFixed(1);
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize monitoring charts
 */
function initMonitoringCharts() {
    // Initialize density chart
    const densityCtx = document.getElementById('density-chart').getContext('2d');
    
    densityChart = new Chart(densityCtx, {
        type: 'line',
        data: {
            labels: generateTimeLabels(30, -1),
            datasets: [{
                label: 'Crowd Density',
                data: [],
                borderColor: chartColors.primary,
                backgroundColor: 'rgba(0, 229, 255, 0.1)',
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: chartColors.primary,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(20, 20, 50, 0.9)',
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF',
                    borderColor: 'rgba(0, 229, 255, 0.3)',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `Density: ${context.raw.toFixed(2)}`;
                        }
                    }
                },
                annotation: {
                    annotations: {
                        criticalLine: {
                            type: 'line',
                            yMin: criticalThreshold,
                            yMax: criticalThreshold,
                            borderColor: chartColors.danger,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'Critical',
                                position: 'end',
                                backgroundColor: 'rgba(255, 82, 82, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        },
                        highLine: {
                            type: 'line',
                            yMin: highThreshold,
                            yMax: highThreshold,
                            borderColor: chartColors.warning,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'High',
                                position: 'end',
                                backgroundColor: 'rgba(255, 214, 0, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 1.5,
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        },
                        callback: function(value) {
                            return value.toFixed(1);
                        }
                    }
                }
            }
        }
    });
    
    // Initialize sensor chart
    const sensorCtx = document.getElementById('sensor-chart').getContext('2d');
    
    sensorChart = new Chart(sensorCtx, {
        type: 'line',
        data: {
            labels: generateTimeLabels(30, -1),
            datasets: [
                {
                    label: 'eCO2 (ppm)',
                    data: [],
                    borderColor: chartColors.eco2,
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    pointRadius: 2,
                    pointBackgroundColor: chartColors.eco2,
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: 'TVOC (ppb)',
                    data: [],
                    borderColor: chartColors.tvoc,
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    pointRadius: 2,
                    pointBackgroundColor: chartColors.tvoc,
                    tension: 0.4,
                    yAxisID: 'y1'
                },
                {
                    label: 'EtOH (ppb)',
                    data: [],
                    borderColor: chartColors.etoh,
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    pointRadius: 2,
                    pointBackgroundColor: chartColors.etoh,
                    tension: 0.4,
                    yAxisID: 'y1'
                },
                {
                    label: 'IAQ (index)',
                    data: [],
                    borderColor: chartColors.iaq,
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    pointRadius: 2,
                    pointBackgroundColor: chartColors.iaq,
                    tension: 0.4,
                    yAxisID: 'y2'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: chartColors.text,
                        font: {
                            family: "'Rajdhani', sans-serif",
                            size: 12
                        },
                        boxWidth: 12,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(20, 20, 50, 0.9)',
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF',
                    borderColor: 'rgba(0, 229, 255, 0.3)',
                    borderWidth: 1
                }
            },
            scales: {
                x: {
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'eCO2 (ppm)',
                        color: chartColors.eco2,
                        font: {
                            family: "'Rajdhani', sans-serif",
                            size: 12
                        }
                    },
                    min: 400,
                    max: 2000,
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'TVOC/EtOH (ppb)',
                        color: chartColors.tvoc,
                        font: {
                            family: "'Rajdhani', sans-serif",
                            size: 12
                        }
                    },
                    min: 0,
                    max: 1000,
                    grid: {
                        drawOnChartArea: false
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y2: {
                    type: 'linear',
                    display: false,
                    min: 0,
                    max: 500
                }
            }
        }
    });
    
    // Initialize history chart
    const historyCtx = document.getElementById('history-chart').getContext('2d');
    
    historyChart = new Chart(historyCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Crowd Density',
                data: [],
                borderColor: chartColors.primary,
                backgroundColor: 'rgba(0, 229, 255, 0.1)',
                borderWidth: 2,
                pointRadius: 0,
                pointHoverRadius: 3,
                pointBackgroundColor: chartColors.primary,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(20, 20, 50, 0.9)',
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF',
                    borderColor: 'rgba(0, 229, 255, 0.3)',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `Density: ${context.raw.toFixed(2)}`;
                        }
                    }
                },
                annotation: {
                    annotations: {
                        criticalLine: {
                            type: 'line',
                            yMin: criticalThreshold,
                            yMax: criticalThreshold,
                            borderColor: chartColors.danger,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'Critical',
                                position: 'end',
                                backgroundColor: 'rgba(255, 82, 82, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        },
                        highLine: {
                            type: 'line',
                            yMin: highThreshold,
                            yMax: highThreshold,
                            borderColor: chartColors.warning,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'High',
                                position: 'end',
                                backgroundColor: 'rgba(255, 214, 0, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'hour',
                        displayFormats: {
                            hour: 'HH:mm'
                        }
                    },
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 1.5,
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        },
                        callback: function(value) {
                            return value.toFixed(1);
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize prediction charts
 */
function initPredictionCharts() {
    // Initialize prediction detail chart
    const predictionDetailCtx = document.getElementById('prediction-detail-chart').getContext('2d');
    
    predictionDetailChart = new Chart(predictionDetailCtx, {
        type: 'line',
        data: {
            labels: generateTimeLabels(20),
            datasets: [
                {
                    label: 'Predicted Density',
                    data: [],
                    borderColor: chartColors.primary,
                    backgroundColor: 'rgba(0, 229, 255, 0.1)',
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: chartColors.primary,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Confidence',
                    data: [],
                    borderColor: chartColors.secondary,
                    backgroundColor: 'transparent',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    pointRadius: 0,
                    tension: 0.4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: chartColors.text,
                        font: {
                            family: "'Rajdhani', sans-serif",
                            size: 12
                        },
                        boxWidth: 12,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(20, 20, 50, 0.9)',
                    titleColor: '#FFFFFF',
                    bodyColor: '#FFFFFF',
                    borderColor: 'rgba(0, 229, 255, 0.3)',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            if (context.dataset.label === 'Predicted Density') {
                                return `Density: ${context.raw.toFixed(2)}`;
                            } else if (context.dataset.label === 'Confidence') {
                                return `Confidence: ${(context.raw * 100).toFixed(0)}%`;
                            }
                            return context.dataset.label + ': ' + context.raw;
                        }
                    }
                },
                annotation: {
                    annotations: {
                        criticalLine: {
                            type: 'line',
                            yMin: criticalThreshold,
                            yMax: criticalThreshold,
                            borderColor: chartColors.danger,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'Critical',
                                position: 'end',
                                backgroundColor: 'rgba(255, 82, 82, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        },
                        highLine: {
                            type: 'line',
                            yMin: highThreshold,
                            yMax: highThreshold,
                            borderColor: chartColors.warning,
                            borderWidth: 2,
                            borderDash: [5, 5],
                            label: {
                                display: true,
                                content: 'High',
                                position: 'end',
                                backgroundColor: 'rgba(255, 214, 0, 0.8)',
                                color: '#FFFFFF',
                                font: {
                                    family: "'Rajdhani', sans-serif",
                                    size: 12
                                }
                            }
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    max: 1.5,
                    grid: {
                        color: chartColors.grid
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        },
                        callback: function(value) {
                            return value.toFixed(1);
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    min: 0,
                    max: 1,
                    grid: {
                        drawOnChartArea: false
                    },
                    ticks: {
                        color: chartColors.text,
                        font: {
                            family: "'Share Tech Mono', monospace",
                            size: 10
                        },
                        callback: function(value) {
                            return (value * 100) + '%';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Update monitoring charts with new data
 * @param {Object} data - The sensor data
 */
function updateMonitoringCharts(data) {
    if (!data) return;
    
    // Update density chart
    if (densityChart) {
        // Add new data point
        densityChart.data.datasets[0].data.push(data.density);
        
        // Remove oldest data point if we have more than 30
        if (densityChart.data.datasets[0].data.length > 30) {
            densityChart.data.datasets[0].data.shift();
        }
        
        // Update chart
        densityChart.update();
    }
    
    // Update sensor chart
    if (sensorChart) {
        // Add new data points
        sensorChart.data.datasets[0].data.push(data.eco2);
        sensorChart.data.datasets[1].data.push(data.tvoc);
        sensorChart.data.datasets[2].data.push(data.etoh);
        sensorChart.data.datasets[3].data.push(data.iaq);
        
        // Remove oldest data points if we have more than 30
        if (sensorChart.data.datasets[0].data.length > 30) {
            sensorChart.data.datasets[0].data.shift();
            sensorChart.data.datasets[1].data.shift();
            sensorChart.data.datasets[2].data.shift();
            sensorChart.data.datasets[3].data.shift();
        }
        
        // Update chart
        sensorChart.update();
    }
    
    // Update detailed sensor values
    document.getElementById('eco2-value-detail').textContent = data.eco2;
    document.getElementById('tvoc-value-detail').textContent = data.tvoc;
    document.getElementById('etoh-value-detail').textContent = data.etoh;
    document.getElementById('iaq-value-detail').textContent = data.iaq;
}

/**
 * Update prediction charts
 */
function updatePredictionCharts() {
    if (!appState.predictionData) return;
    
    const prediction = appState.predictionData;
    
    // Update dashboard prediction chart
    if (predictionChart) {
        predictionChart.data.datasets[0].data = prediction.density;
        predictionChart.update();
    }
    
    // Update prediction detail chart
    if (predictionDetailChart) {
        predictionDetailChart.data.datasets[0].data = prediction.density;
        predictionDetailChart.data.datasets[1].data = prediction.confidence;
        predictionDetailChart.update();
    }
}

/**
 * Update history chart with historical data
 * @param {Object} data - The historical data
 */
function updateHistoryChart(data) {
    if (!data || !historyChart) return;
    
    // Create labels from timestamps
    const labels = data.timestamps.map(ts => new Date(ts));
    
    // Update chart data
    historyChart.data.labels = labels;
    historyChart.data.datasets[0].data = data.density;
    
    // Update chart
    historyChart.update();
}

/**
 * Generate time labels for charts
 * @param {number} count - The number of labels to generate
 * @param {number} direction - The direction of time (1 for future, -1 for past, 0 for centered)
 * @returns {Array} The time labels
 */
function generateTimeLabels(count, direction = 1) {
    const labels = [];
    const now = new Date();
    
    if (direction === 1) {
        // Future times
        for (let i = 0; i <= count; i++) {
            if (i === 0) {
                labels.push('Now');
            } else if (i === 1) {
                labels.push('1 min');
            } else {
                labels.push(`${i} min`);
            }
        }
    } else if (direction === -1) {
        // Past times
        for (let i = count; i >= 0; i--) {
            if (i === 0) {
                labels.push('Now');
            } else if (i === 1) {
                labels.push('1 min ago');
            } else {
                labels.push(`${i} min ago`);
            }
        }
        labels.reverse();
    } else {
        // Centered (past and future)
        const half = Math.floor(count / 2);
        for (let i = -half; i <= half; i++) {
            if (i === 0) {
                labels.push('Now');
            } else if (i === -1) {
                labels.push('1 min ago');
            } else if (i === 1) {
                labels.push('1 min');
            } else if (i < 0) {
                labels.push(`${Math.abs(i)} min ago`);
            } else {
                labels.push(`${i} min`);
            }
        }
    }
    
    return labels;
}
