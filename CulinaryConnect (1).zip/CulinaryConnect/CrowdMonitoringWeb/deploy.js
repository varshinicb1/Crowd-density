/**
 * Crowd Monitoring Web Application - Deployment Script
 * Created by: Manus for Varshini CB, Renesas
 * 
 * This file contains the deployment script for the Crowd Monitoring web application.
 */

// Import required modules
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Deployment configuration
const DEPLOY_DIR = path.join(__dirname, 'deploy');
const STATIC_DIR = path.join(__dirname);
const REQUIRED_FILES = [
  'index.html',
  'server.js',
  'adafruit-io.js',
  'prediction-model.js',
  'notification-system.js',
  'package.json',
  '.env',
  'css/style.css',
  'js/main.js',
  'js/charts.js',
  'js/api.js'
];

/**
 * Prepare the deployment directory
 */
function prepareDeploymentDirectory() {
  console.log('Preparing deployment directory...');
  
  // Create deployment directory if it doesn't exist
  if (!fs.existsSync(DEPLOY_DIR)) {
    fs.mkdirSync(DEPLOY_DIR, { recursive: true });
  } else {
    // Clear existing files
    const files = fs.readdirSync(DEPLOY_DIR);
    for (const file of files) {
      const filePath = path.join(DEPLOY_DIR, file);
      if (fs.lstatSync(filePath).isDirectory()) {
        fs.rmSync(filePath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(filePath);
      }
    }
  }
  
  console.log('Deployment directory prepared.');
}

/**
 * Copy required files to deployment directory
 */
function copyFiles() {
  console.log('Copying files to deployment directory...');
  
  for (const file of REQUIRED_FILES) {
    const sourcePath = path.join(STATIC_DIR, file);
    const destPath = path.join(DEPLOY_DIR, file);
    
    // Create directory if it doesn't exist
    const destDir = path.dirname(destPath);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    
    // Copy file
    if (fs.existsSync(sourcePath)) {
      fs.copyFileSync(sourcePath, destPath);
      console.log(`Copied ${file}`);
    } else {
      console.warn(`Warning: File not found: ${file}`);
    }
  }
  
  console.log('Files copied to deployment directory.');
}

/**
 * Install dependencies in deployment directory
 */
function installDependencies() {
  console.log('Installing dependencies...');
  
  try {
    execSync('npm install --production', { cwd: DEPLOY_DIR, stdio: 'inherit' });
    console.log('Dependencies installed successfully.');
  } catch (error) {
    console.error('Error installing dependencies:', error.message);
    throw error;
  }
}

/**
 * Create a deployment package (zip file)
 */
function createDeploymentPackage() {
  console.log('Creating deployment package...');
  
  const packageName = `crowd-monitoring-web-${new Date().toISOString().split('T')[0]}.zip`;
  const packagePath = path.join(__dirname, packageName);
  
  try {
    execSync(`zip -r "${packagePath}" .`, { cwd: DEPLOY_DIR, stdio: 'inherit' });
    console.log(`Deployment package created: ${packagePath}`);
    return packagePath;
  } catch (error) {
    console.error('Error creating deployment package:', error.message);
    throw error;
  }
}

/**
 * Deploy to production environment
 */
async function deployToProduction() {
  try {
    console.log('=== DEPLOYING CROWD MONITORING WEB APPLICATION ===');
    
    // Prepare deployment directory
    prepareDeploymentDirectory();
    
    // Copy files
    copyFiles();
    
    // Install dependencies
    installDependencies();
    
    // Create deployment package
    const packagePath = createDeploymentPackage();
    
    console.log('\n✅ Deployment preparation completed successfully!');
    console.log(`\nTo deploy the application to a production server:`);
    console.log(`1. Transfer the deployment package: ${packagePath}`);
    console.log(`2. Unzip the package on the server`);
    console.log(`3. Install dependencies: npm install --production`);
    console.log(`4. Start the application: npm start`);
    
    return packagePath;
  } catch (error) {
    console.error('\n❌ Deployment failed:', error.message);
    throw error;
  }
}

// Run deployment if this file is executed directly
if (require.main === module) {
  deployToProduction();
}

// Export deployment function
module.exports = {
  deployToProduction
};
