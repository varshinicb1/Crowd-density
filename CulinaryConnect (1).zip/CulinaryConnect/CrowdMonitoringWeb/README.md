# Crowd Monitoring Web Application

A comprehensive web application for monitoring crowd density using Renesas zmod4410 sensor data.

## Created By
- **Developer**: Varshini CB
- **Company**: Renesas

## Features

- Real-time monitoring of crowd density using Renesas zmod4410 sensor data
- Classification of crowd density into Low, Medium, High, and Critical levels
- Advanced LSTM prediction model for forecasting crowd density 20 minutes ahead
- Push notifications and alerts when crowd density exceeds critical limits
- SMS notifications for critical alerts
- Audio alarms with visual warnings
- Real-time graphs and data visualization
- Crowd count estimation
- Modern sci-fi dark theme UI with responsive design

## Technical Architecture

### Frontend
- HTML5, CSS3, and JavaScript
- Responsive design for mobile and desktop
- Interactive charts using Chart.js
- Real-time updates using Socket.IO

### Backend
- Node.js with Express.js
- Socket.IO for real-time communication
- TensorFlow.js for LSTM prediction model
- Integration with Adafruit IO for sensor data
- Nodemailer for email notifications

## Installation

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Configure environment variables in `.env` file:
   ```
   PORT=3000
   ADAFRUIT_IO_USERNAME=varshinicb99
   ADAFRUIT_IO_KEY=aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe
   ECO2_FEED=eCO2
   TVOC_FEED=tvoc
   ETOH_FEED=EtOH
   IAQ_FEED=indoor-aqi
   EMAIL_SERVICE=gmail
   EMAIL_USER=your-email@gmail.com
   EMAIL_PASS=your-app-password
   ```
4. Start the application:
   ```
   npm start
   ```

## Deployment

### Option 1: Deploy to Heroku
1. Create a Heroku account and install the Heroku CLI
2. Login to Heroku:
   ```
   heroku login
   ```
3. Create a new Heroku app:
   ```
   heroku create crowd-monitoring-app
   ```
4. Push to Heroku:
   ```
   git push heroku main
   ```
5. Configure environment variables in Heroku dashboard

### Option 2: Deploy to DigitalOcean
1. Create a DigitalOcean account
2. Create a new Droplet with Node.js
3. Clone the repository on the Droplet
4. Install dependencies and start the application
5. Set up Nginx as a reverse proxy

### Option 3: Deploy to Vercel
1. Create a Vercel account
2. Install Vercel CLI:
   ```
   npm install -g vercel
   ```
3. Deploy the application:
   ```
   vercel
   ```

## Usage

1. Open the application in a web browser
2. The dashboard shows the current crowd density and status
3. Navigate to the Monitoring page to see detailed sensor readings
4. Check the Prediction page to see forecasted crowd density
5. Configure notification settings in the Settings page

## File Structure

```
crowd-monitoring-web/
├── css/
│   └── style.css
├── js/
│   ├── main.js
│   ├── charts.js
│   └── api.js
├── index.html
├── server.js
├── adafruit-io.js
├── prediction-model.js
├── notification-system.js
├── package.json
└── .env
```

## API Endpoints

- `GET /api/data/latest` - Get latest sensor data
- `GET /api/data/history` - Get historical sensor data
- `GET /api/prediction` - Get crowd density prediction
- `GET /api/test-connection` - Test Adafruit IO connection

## Customization

### Alert Thresholds
You can customize the alert thresholds in the `.env` file:
```
CRITICAL_THRESHOLD=1.0
HIGH_THRESHOLD=0.7
```

### UI Theme
The UI theme can be customized in `css/style.css`.

## Troubleshooting

### Connection Issues
If you experience connection issues with Adafruit IO:
1. Verify your Adafruit IO credentials
2. Check that your feeds exist and are correctly named
3. Test the connection using the Settings page

### Prediction Model
If the prediction model is not working correctly:
1. Ensure you have enough historical data
2. Check the console for TensorFlow.js errors
3. Try retraining the model with more data

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

## Contact

For support or inquiries, please contact Varshini CB at Renesas.
