import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Existing users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Sensor Data schema
export const sensorData = pgTable("sensor_data", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  eco2: integer("eco2").notNull(), // Carbon dioxide equivalent in ppm
  tvoc: integer("tvoc").notNull(), // Total volatile organic compounds in ppb
  etoh: integer("etoh").notNull(), // Ethanol in ppb
  iaq: integer("iaq").notNull(), // Indoor air quality index
  density: text("density").notNull(), // Calculated crowd density
  crowdCount: integer("crowd_count").notNull(), // Estimated crowd count
});

export const insertSensorDataSchema = createInsertSchema(sensorData).omit({
  id: true,
  timestamp: true,
});

// Alerts schema
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  alertType: text("alert_type").notNull(), // 'critical', 'high', 'prediction'
  message: text("message").notNull(),
  details: jsonb("details").notNull(), // Contains sensor readings at alert time
  acknowledged: boolean("acknowledged").notNull().default(false),
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  timestamp: true,
  acknowledged: true,
});

// Settings schema
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  critical_threshold: text("critical_threshold").notNull().default("1.0"),
  high_threshold: text("high_threshold").notNull().default("0.7"),
  medium_threshold: text("medium_threshold").notNull().default("0.3"),
  low_threshold: text("low_threshold").notNull().default("0.1"),
  enable_sound: boolean("enable_sound").notNull().default(true),
  enable_browser: boolean("enable_browser").notNull().default(true),
  enable_email: boolean("enable_email").notNull().default(false),
  email_address: text("email_address"),
  enable_sms: boolean("enable_sms").notNull().default(false),
  phone_number: text("phone_number"),
  sms_critical: boolean("sms_critical").notNull().default(true),
  sms_high: boolean("sms_high").notNull().default(true),
  sms_medium: boolean("sms_medium").notNull().default(false),
  sms_low: boolean("sms_low").notNull().default(false),
  refresh_interval: integer("refresh_interval").notNull().default(30),
  prediction_interval: integer("prediction_interval").notNull().default(300),
  adafruit_username: text("adafruit_username").notNull(),
  adafruit_key: text("adafruit_key").notNull(),
  eco2_feed: text("eco2_feed").notNull(),
  tvoc_feed: text("tvoc_feed").notNull(),
  etoh_feed: text("etoh_feed").notNull(),
  iaq_feed: text("iaq_feed").notNull(),
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSensorData = z.infer<typeof insertSensorDataSchema>;
export type SensorData = typeof sensorData.$inferSelect;

export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;
