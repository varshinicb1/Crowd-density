/**
 * SMS Service
 * This service handles sending SMS notifications for alerts using a 3rd party SMS API
 * For Indian numbers, it falls back to a demo service since TextBelt blocks free SMS to India
 */

import axios from 'axios';
import { Alert } from '../../shared/schema';
import { sendDemoSms } from './demo-sms';

// Using TextBelt API for SMS - free tier allows one text message per day
const SMS_API_URL = 'https://textbelt.com/text';

// Function to format time in IST
export function formatTimeIST(timestamp: Date | number | string): string {
  try {
    const date = new Date(timestamp);
    // Check if date is valid
    if (isNaN(date.getTime())) {
      console.error('Invalid date for formatTimeIST:', timestamp);
      // Return current time as fallback
      return new Intl.DateTimeFormat('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        day: '2-digit',
        month: 'short'
      }).format(new Date());
    }
    
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      day: '2-digit',
      month: 'short'
    }).format(date);
  } catch (error) {
    console.error('Error formatting time in IST:', error);
    // Return current time as fallback
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
      day: '2-digit',
      month: 'short'
    }).format(new Date());
  }
}

/**
 * Generate SMS message for alert
 * @param alert - The alert object
 * @returns string - The SMS message
 */
export function generateAlertSmsMessage(alert: Alert): string {
  const timestamp = formatTimeIST(alert.timestamp);
  const alertTypeUpper = alert.alertType.toUpperCase();
  
  let message = `${alertTypeUpper} ALERT: Crowd Monitor - ${alert.message} (${timestamp})`;
  
  // Add density info if available in details
  if (alert.details && typeof alert.details === 'object') {
    const details = alert.details as Record<string, any>;
    
    if (details.density !== undefined) {
      message += ` Density: ${details.density}`;
    }
    
    // Add crowd count if available in details
    if (details.crowdCount !== undefined) {
      message += `, Est. Count: ${details.crowdCount}`;
    }
    
    // Add prediction info if available
    if (alert.alertType === 'prediction') {
      if (details.timeToEvent !== undefined) {
        message += ` - Time to event: ${details.timeToEvent}`;
      }
      
      if (details.confidence !== undefined) {
        const confidencePercent = Math.round(details.confidence * 100);
        message += ` (${confidencePercent}% confidence)`;
      }
    }
  }
  
  return message;
}

/**
 * Send SMS notification
 * @param phoneNumber - The phone number to send SMS to
 * @param alert - The alert object
 * @returns Promise<boolean> - Whether the SMS was sent successfully
 */
export async function sendSms(phoneNumber: string, alert: Alert): Promise<boolean> {
  try {
    // Don't send if phone number is invalid
    if (!phoneNumber || !phoneNumber.trim() || phoneNumber.length < 8) {
      console.error('Invalid phone number for SMS:', phoneNumber);
      return false;
    }
    
    // Clean up the phone number - remove spaces
    const cleanNumber = phoneNumber.replace(/\s+/g, '');
    
    // Check if it's an Indian number
    const isIndianNumber = cleanNumber.startsWith('+91') || cleanNumber.startsWith('91');
    
    const message = generateAlertSmsMessage(alert);
    
    // For Indian numbers, use the demo service since TextBelt blocks free SMS to India
    if (isIndianNumber) {
      console.log('Using Demo SMS service for Indian number:', cleanNumber);
      const result = await sendDemoSms(cleanNumber, message);
      return result.success;
    }
    
    // For non-Indian numbers, try using TextBelt
    // TextBelt free tier allows 1 message per day with 'textbelt' as key
    const response = await axios.post(SMS_API_URL, {
      phone: cleanNumber,
      message: message,
      key: 'textbelt'
    });
    
    const success = response.data && response.data.success;
    if (!success && response.data.error) {
      console.error('SMS service error:', response.data.error);
      
      // If country is blocked by TextBelt, fall back to demo service
      if (response.data.error.includes('disabled for this country')) {
        console.log('TextBelt blocked this country. Using Demo SMS service instead.');
        const result = await sendDemoSms(cleanNumber, message);
        return result.success;
      }
    }
    
    return success || false;
  } catch (error) {
    console.error('Error sending SMS:', error);
    return false;
  }
}

/**
 * Test SMS service by sending a test message
 * @param phoneNumber - The phone number to send the test SMS to
 * @returns Promise<boolean> - Whether the test SMS was sent successfully
 */
export async function sendTestSms(phoneNumber: string): Promise<boolean> {
  try {
    // Create a test alert
    const testAlert: Alert = {
      id: 0,
      timestamp: new Date(),
      alertType: 'test',
      message: 'This is a test message from Crowd Monitoring System',
      details: {
        timestamp: new Date(),
        density: 0.5,
        crowdCount: 175
      },
      acknowledged: false
    };
    
    return await sendSms(phoneNumber, testAlert);
  } catch (error) {
    console.error('Error sending test SMS:', error);
    return false;
  }
}