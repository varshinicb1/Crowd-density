/**
 * WhatsApp Service
 * Handles sending WhatsApp messages using whatsapp-web.js (unofficial)
 */
import { Client } from 'whatsapp-web.js';
import qrcode from 'qrcode-terminal';
import { Alert } from '@shared/schema';
import { formatTimeIST } from './sms';

// Client instance
let client: Client | null = null;
let clientReady = false;
let lastQRCode = '';

// Store pending messages that should be sent once client is ready
const pendingMessages: Array<{to: string, message: string}> = [];

/**
 * Initialize WhatsApp client
 */
export function initWhatsAppClient() {
  if (client) {
    return;
  }
  
  console.log('Initializing WhatsApp client...');
  
  // Create a new client
  client = new Client({
    puppeteer: {
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
  });
  
  client.on('qr', (qr) => {
    // Generate and display QR code in the terminal
    lastQRCode = qr;
    console.log('WhatsApp QR Code:');
    qrcode.generate(qr, { small: true });
    console.log('Scan this QR code with your WhatsApp app to enable WhatsApp notifications');
  });
  
  client.on('ready', () => {
    console.log('WhatsApp client is ready!');
    clientReady = true;
    
    // Send any pending messages
    if (pendingMessages.length > 0) {
      console.log(`Sending ${pendingMessages.length} pending WhatsApp messages...`);
      pendingMessages.forEach(async ({ to, message }) => {
        await sendWhatsAppMessage(to, message);
      });
      
      // Clear pending messages
      pendingMessages.length = 0;
    }
  });
  
  client.on('authenticated', () => {
    console.log('WhatsApp client authenticated');
  });
  
  client.on('auth_failure', (msg) => {
    console.error('WhatsApp authentication failed:', msg);
    clientReady = false;
  });
  
  client.on('disconnected', (reason) => {
    console.log('WhatsApp client disconnected:', reason);
    clientReady = false;
    
    // Attempt reconnection after 5 seconds
    setTimeout(() => {
      if (client) {
        console.log('Attempting to reconnect WhatsApp client...');
        client.initialize();
      }
    }, 5000);
  });
  
  // Initialize client
  client.initialize();
}

/**
 * Get the current QR code for WhatsApp authentication
 * @returns The current QR code string
 */
export function getWhatsAppQRCode(): string {
  return lastQRCode;
}

/**
 * Check if WhatsApp client is ready
 * @returns Whether the client is authenticated and ready to send messages
 */
export function isWhatsAppReady(): boolean {
  return clientReady;
}

/**
 * Formats alert message for WhatsApp
 * @param alert - The alert object
 * @returns The formatted message
 */
export function formatWhatsAppAlertMessage(alert: Alert): string {
  let message = `*${getAlertPrefix(alert.alertType)}*\n`;
  message += `🔔 *Crowd Monitor Alert*\n\n`;
  message += `📅 *Time*: ${formatTimeIST(alert.timestamp)}\n`;
  message += `📝 *Message*: ${alert.message}\n\n`;
  
  // Add alert details
  const details = alert.details as any;
  message += '*Sensor Data*:\n';
  
  if (details.density !== undefined) {
    message += `- Crowd Density: ${details.density.toFixed(2)}\n`;
  }
  
  if (details.crowdCount !== undefined) {
    message += `- Est. Count: ${details.crowdCount}\n`;
  }
  
  if (details.eco2 !== undefined) {
    message += `- eCO2: ${details.eco2} ppm\n`;
  }
  
  if (details.tvoc !== undefined) {
    message += `- TVOC: ${details.tvoc} ppb\n`;
  }
  
  if (details.etoh !== undefined) {
    message += `- EtOH: ${details.etoh}\n`;
  }
  
  if (details.iaq !== undefined) {
    message += `- IAQ: ${details.iaq}\n`;
  }
  
  if (details.location) {
    message += `- Location: ${details.location}\n`;
  }
  
  // Add prediction-specific details
  if (alert.alertType === 'prediction' && details.timeToEvent) {
    message += `\n*Prediction*:\n`;
    message += `- Time to Event: ${details.timeToEvent}\n`;
    if (details.confidence) {
      message += `- Confidence: ${Math.round(details.confidence * 100)}%\n`;
    }
  }
  
  message += '\n_Sent from Crowd Monitoring System_';
  
  return message;
}

/**
 * Gets the prefix for the alert type
 * @param alertType - The type of alert
 * @returns The alert prefix
 */
function getAlertPrefix(alertType: string): string {
  switch (alertType) {
    case 'critical':
      return '🚨 CRITICAL ALERT 🚨';
    case 'high':
      return '⚠️ HIGH ALERT ⚠️';
    case 'medium':
      return '📊 MEDIUM ALERT';
    case 'low':
      return '📌 LOW ALERT';
    case 'prediction':
      return '🔮 PREDICTION ALERT';
    default:
      return '🔔 ALERT';
  }
}

/**
 * Send a WhatsApp message
 * @param to - The phone number to send the message to (with country code)
 * @param message - The message to send
 * @returns Promise resolving to success status
 */
export async function sendWhatsAppMessage(to: string, message: string): Promise<boolean> {
  try {
    // Make sure client is initialized
    if (!client) {
      console.log('WhatsApp client not initialized, initializing now...');
      initWhatsAppClient();
      
      // Queue message to be sent when client is ready
      pendingMessages.push({ to, message });
      return false;
    }
    
    // If client is not ready, queue the message
    if (!clientReady) {
      console.log('WhatsApp client not ready, queuing message');
      pendingMessages.push({ to, message });
      return false;
    }
    
    // Format the phone number (remove spaces, ensure it starts with country code)
    let formattedNumber = to.replace(/\s+/g, '');
    
    // If number doesn't start with +, add it
    if (!formattedNumber.startsWith('+')) {
      formattedNumber = '+' + formattedNumber;
    }
    
    // Format as international number with @c.us suffix required by WhatsApp Web API
    const chatId = formattedNumber.substring(1) + '@c.us';
    
    console.log(`Sending WhatsApp message to ${formattedNumber} (${chatId})`);
    
    // Send the message
    const response = await client.sendMessage(chatId, message);
    
    console.log(`WhatsApp message sent successfully to ${formattedNumber}`);
    console.log(`Message ID: ${response.id.id}`);
    
    return true;
  } catch (error) {
    console.error('Error sending WhatsApp message:', error);
    return false;
  }
}

/**
 * Send alert notification via WhatsApp
 * @param phoneNumber - The destination phone number
 * @param alert - The alert object
 * @returns Promise resolving to success status
 */
export async function sendWhatsAppAlert(phoneNumber: string, alert: Alert): Promise<boolean> {
  const message = formatWhatsAppAlertMessage(alert);
  return sendWhatsAppMessage(phoneNumber, message);
}

/**
 * Send a test message via WhatsApp
 * @param phoneNumber - The destination phone number
 * @returns Promise resolving to success status
 */
export async function sendWhatsAppTest(phoneNumber: string): Promise<boolean> {
  const message = `🧪 *Test Alert from Crowd Monitoring System*\n\n` +
    `This is a test message to verify WhatsApp notifications are working correctly.\n\n` +
    `📅 Time: ${formatTimeIST(new Date())}\n\n` +
    `_Sent from Crowd Monitoring System_`;
  
  return sendWhatsAppMessage(phoneNumber, message);
}