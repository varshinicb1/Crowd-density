/**
 * Twilio SMS Service
 * Handles sending SMS messages using the Twilio API
 */
import { Alert } from '@shared/schema';
import { formatTimeIST } from './sms';

// Twilio Configuration
const TWILIO_ACCOUNT_SID = 'ACbed65f2e921ece9ca06354d5f10afd91';
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
const TWILIO_MESSAGING_SERVICE_SID = 'MG799208e7b30e42c6b215c3a252017fbe';

// Debug message for environment variables
console.log('Twilio Environment Variables:');
console.log(`- TWILIO_ACCOUNT_SID: ${TWILIO_ACCOUNT_SID}`);
console.log(`- TWILIO_AUTH_TOKEN: ${TWILIO_AUTH_TOKEN ? '[PROVIDED]' : '[NOT_PROVIDED]'}`);
console.log(`- TWILIO_MESSAGING_SERVICE_SID: ${TWILIO_MESSAGING_SERVICE_SID}`);

/**
 * Formats the alert message for SMS
 * @param alert - The alert object
 * @returns The formatted message
 */
export function formatTwilioAlertMessage(alert: Alert): string {
  const alertPrefix = getAlertPrefix(alert.alertType);
  const timestamp = formatTimeIST(alert.timestamp);
  
  let message = `${alertPrefix}: Crowd Monitor - ${alert.message} (${timestamp})`;
  
  if (alert.alertType === 'prediction') {
    // Add prediction-specific details
    const details = alert.details as any;
    message += ` Density: ${details.density?.toFixed(2)}, Est. Count: ${details.crowdCount}`;
    message += ` - Time to event: ${details.timeToEvent} (${Math.round(details.confidence * 100)}% confidence)`;
  } else {
    // Add standard alert details
    const details = alert.details as any;
    message += ` Density: ${details.density}, Est. Count: ${details.crowdCount}`;
  }
  
  return message;
}

/**
 * Gets the prefix for the alert type
 * @param alertType - The type of alert
 * @returns The alert prefix
 */
function getAlertPrefix(alertType: string): string {
  switch (alertType) {
    case 'critical':
      return 'CRITICAL ALERT';
    case 'high':
      return 'HIGH ALERT';
    case 'medium':
      return 'MEDIUM ALERT';
    case 'low':
      return 'LOW ALERT';
    case 'prediction':
      return 'PREDICTION ALERT';
    default:
      return 'ALERT';
  }
}

/**
 * Send SMS using Twilio API
 * @param phoneNumber - The destination phone number (with country code)
 * @param message - The message to send
 * @returns Promise resolving to success status
 */
export async function sendTwilioSms(phoneNumber: string, message: string): Promise<boolean> {
  try {
    // Clean up phone number format if needed
    const formattedPhoneNumber = phoneNumber.replace(/\s+/g, '');
    
    console.log(`Sending Twilio SMS to ${formattedPhoneNumber}`);
    console.log(`SMS Content: ${message}`);
    
    // Get the Twilio auth token from environment
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    if (!authToken) {
      console.error('TWILIO_AUTH_TOKEN is not set in environment variables');
      return false;
    }
    
    // Prepare API request
    const formData = new URLSearchParams();
    formData.append('To', formattedPhoneNumber);
    formData.append('MessagingServiceSid', TWILIO_MESSAGING_SERVICE_SID);
    formData.append('Body', message);
    
    // Authentication credentials
    const auth = Buffer.from(`${TWILIO_ACCOUNT_SID}:${authToken}`).toString('base64');
    
    // Make API request to Twilio
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Basic ${auth}`
        },
        body: formData.toString()
      }
    );
    
    const result = await response.json();
    
    if (response.ok) {
      console.log(`Twilio SMS sent successfully to ${formattedPhoneNumber}`);
      console.log(`Twilio Message SID: ${result.sid}`);
      return true;
    } else {
      console.error('Twilio SMS sending failed:', result);
      return false;
    }
  } catch (error) {
    console.error('Error sending Twilio SMS:', error);
    return false;
  }
}

/**
 * Send alert notification via Twilio SMS
 * @param phoneNumber - The destination phone number
 * @param alert - The alert object
 * @returns Promise resolving to success status
 */
export async function sendTwilioAlertSms(phoneNumber: string, alert: Alert): Promise<boolean> {
  const message = formatTwilioAlertMessage(alert);
  return sendTwilioSms(phoneNumber, message);
}

/**
 * Send a test message via Twilio 
 * @param phoneNumber - The destination phone number
 * @returns Promise resolving to success status
 */
export async function sendTwilioTestSms(phoneNumber: string): Promise<boolean> {
  const message = `Test alert from Crowd Monitoring System! Time: ${formatTimeIST(new Date())}`;
  return sendTwilioSms(phoneNumber, message);
}