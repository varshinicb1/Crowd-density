/**
 * Enhanced Model Trainer Service
 * Based on the CrowdMonitoring dataset implementation examples
 * Uses real Adafruit IO data to train and improve the prediction model
 */

import { SensorData } from '../../shared/schema';

// Normalization constants from research and dataset examples
const NORMALIZATION_CONSTANTS = {
  ECO2: {
    MIN: 400.0,  // Background CO2 level (ppm)
    MAX: 5000.0  // Maximum expected CO2 level
  },
  TVOC: {
    MIN: 0.0,    // Minimum TVOC level (ppb)
    MAX: 1000.0  // Maximum expected TVOC level
  },
  ETOH: {
    MIN: 0.0,    // Minimum ethanol level (ppb)
    MAX: 1000.0  // Maximum expected ethanol level
  },
  IAQ: {
    MIN: 0.0,    // Minimum IAQ index
    MAX: 500.0   // Maximum expected IAQ index
  }
};

// Interface for normalized reading
export interface NormalizedReading {
  timestamp: number;
  eco2Normalized: number;
  tvocNormalized: number;
  etohNormalized: number;
  iaqNormalized: number;
  density: number;
  crowdCount: number;
}

// Model weights (will be trained)
export interface ModelWeights {
  eco2Weight: number;
  tvocWeight: number;
  etohWeight: number;
  iaqWeight: number;
  timeFactors: {
    morning: number;   // 6-11 AM
    noon: number;      // 11 AM-2 PM
    afternoon: number; // 2-5 PM
    evening: number;   // 5-10 PM
    night: number;     // 10 PM-6 AM
  };
}

// Default initial weights based on research
const defaultModelWeights: ModelWeights = {
  eco2Weight: 0.40,
  tvocWeight: 0.25,
  etohWeight: 0.20,
  iaqWeight: 0.15,
  timeFactors: {
    morning: 1.1,   // Morning busy time
    noon: 1.3,      // Lunch peak
    afternoon: 1.0, // Standard
    evening: 1.5,   // Evening peak
    night: 0.7      // Night time (less crowded)
  }
};

// Default training parameters
const TRAINING_PARAMS = {
  learningRate: 0.01,
  epochs: 10,
  batchSize: 32,
  validationSplit: 0.2,
  earlyStoppingPatience: 3
};

/**
 * Normalizes a sensor reading for model input
 * @param reading - Raw sensor reading
 * @returns Normalized values
 */
export function normalizeSensorReading(reading: {
  eco2: number;
  tvoc: number;
  etoh: number;
  iaq: number;
}): {
  eco2Normalized: number;
  tvocNormalized: number;
  etohNormalized: number;
  iaqNormalized: number;
} {
  return {
    eco2Normalized: normalizeValue(reading.eco2, NORMALIZATION_CONSTANTS.ECO2.MIN, NORMALIZATION_CONSTANTS.ECO2.MAX),
    tvocNormalized: normalizeValue(reading.tvoc, NORMALIZATION_CONSTANTS.TVOC.MIN, NORMALIZATION_CONSTANTS.TVOC.MAX),
    etohNormalized: normalizeValue(reading.etoh, NORMALIZATION_CONSTANTS.ETOH.MIN, NORMALIZATION_CONSTANTS.ETOH.MAX),
    iaqNormalized: normalizeValue(reading.iaq, NORMALIZATION_CONSTANTS.IAQ.MIN, NORMALIZATION_CONSTANTS.IAQ.MAX)
  };
}

/**
 * Normalize a value between 0 and 1
 */
export function normalizeValue(value: number, min: number, max: number): number {
  return Math.min(1, Math.max(0, (value - min) / (max - min)));
}

/**
 * Class for training and managing the crowd density prediction model
 */
export class ModelTrainer {
  private weights: ModelWeights;
  private trainingData: NormalizedReading[] = [];
  private trainedWithDataPoints: number = 0;
  
  constructor(initialWeights: ModelWeights = defaultModelWeights) {
    this.weights = {...initialWeights};
  }
  
  /**
   * Get current model weights
   */
  getWeights(): ModelWeights {
    return {...this.weights};
  }
  
  /**
   * Set model weights explicitly
   */
  setWeights(weights: ModelWeights): void {
    this.weights = {...weights};
  }
  
  /**
   * Get time factor based on hour of day
   */
  getTimeFactor(timestamp: number): number {
    const date = new Date(timestamp);
    const hour = date.getHours();
    
    if (hour >= 6 && hour < 11) {
      return this.weights.timeFactors.morning;
    } else if (hour >= 11 && hour < 14) {
      return this.weights.timeFactors.noon;
    } else if (hour >= 14 && hour < 17) {
      return this.weights.timeFactors.afternoon;
    } else if (hour >= 17 && hour < 22) {
      return this.weights.timeFactors.evening;
    } else {
      return this.weights.timeFactors.night;
    }
  }
  
  /**
   * Calculate crowd density from normalized sensor values
   */
  calculateCrowdDensity(
    normalizedValues: {
      eco2Normalized: number;
      tvocNormalized: number;
      etohNormalized: number;
      iaqNormalized: number;
    },
    timestamp: number
  ): number {
    // Get time-based factor
    const timeFactor = this.getTimeFactor(timestamp);
    
    // Calculate weighted sum
    const weightedSum = 
      normalizedValues.eco2Normalized * this.weights.eco2Weight +
      normalizedValues.tvocNormalized * this.weights.tvocWeight +
      normalizedValues.etohNormalized * this.weights.etohWeight +
      normalizedValues.iaqNormalized * this.weights.iaqWeight;
    
    // Apply time factor and return (clamped between 0 and 1.5)
    return Math.min(1.5, Math.max(0, weightedSum * timeFactor));
  }
  
  /**
   * Estimate crowd count based on density
   */
  estimateCrowdCount(density: number): number {
    // Simple linear model, assuming density of 1.0 = 350 people
    // This can be customized based on venue capacity
    return Math.round(density * 350);
  }
  
  /**
   * Process a sensor reading into normalized form with calculated density
   */
  processSensorReading(reading: SensorData): NormalizedReading {
    // Normalize values
    const normalizedValues = normalizeSensorReading({
      eco2: reading.eco2,
      tvoc: reading.tvoc,
      etoh: reading.etoh,
      iaq: reading.iaq
    });
    
    // Calculate crowd density
    const timestamp = new Date(reading.timestamp).getTime();
    const density = this.calculateCrowdDensity(normalizedValues, timestamp);
    
    // Estimate crowd count
    const crowdCount = this.estimateCrowdCount(density);
    
    return {
      timestamp,
      ...normalizedValues,
      density,
      crowdCount
    };
  }
  
  /**
   * Add sensor reading to training data
   */
  addTrainingData(reading: SensorData): void {
    const processedReading = this.processSensorReading(reading);
    this.trainingData.push(processedReading);
    
    // Limit training data to prevent memory issues
    if (this.trainingData.length > 1000) {
      this.trainingData.shift();
    }
  }
  
  /**
   * Train model with accumulated data using gradient descent
   * Returns true if training succeeded
   */
  trainModel(): boolean {
    // Need at least 10 data points for meaningful training
    if (this.trainingData.length < 10) {
      console.log('Not enough training data, need at least 10 data points');
      return false;
    }
    
    console.log(`Training model with ${this.trainingData.length} data points...`);
    
    // Sort by timestamp to ensure chronological order
    this.trainingData.sort((a, b) => a.timestamp - b.timestamp);
    
    // Simple gradient descent
    const learningRate = TRAINING_PARAMS.learningRate;
    let improved = false;
    
    // For each epoch
    for (let epoch = 0; epoch < TRAINING_PARAMS.epochs; epoch++) {
      // Shuffle data for better training
      const shuffledData = [...this.trainingData].sort(() => Math.random() - 0.5);
      
      // Track loss for this epoch
      let totalLoss = 0;
      
      // Train in batches
      for (let i = 0; i < shuffledData.length; i += TRAINING_PARAMS.batchSize) {
        const batch = shuffledData.slice(i, i + TRAINING_PARAMS.batchSize);
        
        // Calculate gradients for this batch
        const gradients = {
          eco2Weight: 0,
          tvocWeight: 0,
          etohWeight: 0,
          iaqWeight: 0,
          timeFactors: {
            morning: 0,
            noon: 0,
            afternoon: 0,
            evening: 0,
            night: 0
          }
        };
        
        // For each sample in batch
        for (const sample of batch) {
          // Calculate predicted density with current weights
          const normalizedValues = {
            eco2Normalized: sample.eco2Normalized,
            tvocNormalized: sample.tvocNormalized,
            etohNormalized: sample.etohNormalized,
            iaqNormalized: sample.iaqNormalized
          };
          
          const predictedDensity = this.calculateCrowdDensity(normalizedValues, sample.timestamp);
          
          // Calculate error (supervised learning assumes the density we calculated is ground truth)
          // In a real implementation, we would use labeled data
          const error = sample.density - predictedDensity;
          totalLoss += error * error; // Squared error
          
          // Calculate gradients for sensor weights
          gradients.eco2Weight += error * normalizedValues.eco2Normalized;
          gradients.tvocWeight += error * normalizedValues.tvocNormalized;
          gradients.etohWeight += error * normalizedValues.etohNormalized;
          gradients.iaqWeight += error * normalizedValues.iaqNormalized;
          
          // Calculate gradients for time factors
          const date = new Date(sample.timestamp);
          const hour = date.getHours();
          
          if (hour >= 6 && hour < 11) {
            gradients.timeFactors.morning += error;
          } else if (hour >= 11 && hour < 14) {
            gradients.timeFactors.noon += error;
          } else if (hour >= 14 && hour < 17) {
            gradients.timeFactors.afternoon += error;
          } else if (hour >= 17 && hour < 22) {
            gradients.timeFactors.evening += error;
          } else {
            gradients.timeFactors.night += error;
          }
        }
        
        // Update weights with gradients
        this.weights.eco2Weight += learningRate * gradients.eco2Weight / batch.length;
        this.weights.tvocWeight += learningRate * gradients.tvocWeight / batch.length;
        this.weights.etohWeight += learningRate * gradients.etohWeight / batch.length;
        this.weights.iaqWeight += learningRate * gradients.iaqWeight / batch.length;
        
        this.weights.timeFactors.morning += learningRate * gradients.timeFactors.morning / batch.length;
        this.weights.timeFactors.noon += learningRate * gradients.timeFactors.noon / batch.length;
        this.weights.timeFactors.afternoon += learningRate * gradients.timeFactors.afternoon / batch.length;
        this.weights.timeFactors.evening += learningRate * gradients.timeFactors.evening / batch.length;
        this.weights.timeFactors.night += learningRate * gradients.timeFactors.night / batch.length;
        
        // Normalize weights to ensure they sum to 1
        const totalWeight = this.weights.eco2Weight + this.weights.tvocWeight + 
                           this.weights.etohWeight + this.weights.iaqWeight;
        
        this.weights.eco2Weight /= totalWeight;
        this.weights.tvocWeight /= totalWeight;
        this.weights.etohWeight /= totalWeight;
        this.weights.iaqWeight /= totalWeight;
        
        improved = true;
      }
      
      // Log progress
      console.log(`Epoch ${epoch + 1}/${TRAINING_PARAMS.epochs}, Loss: ${totalLoss / shuffledData.length}`);
    }
    
    // Update trained data point count
    this.trainedWithDataPoints = this.trainingData.length;
    
    console.log('Model training complete. Updated weights:', this.weights);
    return improved;
  }
  
  /**
   * Get a plain object representing the model's state
   */
  getModelState(): any {
    return {
      weights: this.weights,
      trainedWithDataPoints: this.trainedWithDataPoints,
      lastTrainingTimestamp: new Date().toISOString()
    };
  }
  
  /**
   * Load model state from a plain object
   */
  loadModelState(state: any): boolean {
    try {
      if (state && state.weights) {
        this.weights = state.weights;
        this.trainedWithDataPoints = state.trainedWithDataPoints || 0;
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error loading model state:', error);
      return false;
    }
  }
}