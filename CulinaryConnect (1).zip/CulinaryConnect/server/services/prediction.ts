/**
 * Advanced Prediction Service
 * Based on "Indoor Crowd Density Estimation Using a Novel CO2-Based Model"
 * Research paper: https://www.mdpi.com/2076-3417/14/14/6188
 */

import { SensorData } from '../../shared/schema';

// Type for current sensor reading
export interface SensorReading {
  eco2: number;  // CO2 equivalent in ppm
  tvoc: number;  // Total Volatile Organic Compounds in ppb
  etoh: number;  // Ethanol in ppb
  iaq: number;   // Indoor Air Quality index
}

// Type for prediction output
export interface PredictionOutput {
  timestamps: number[];
  density: number[];
  crowdCount: number[];
  confidence: number[];
}

// Constants derived from the research paper
const CO2_BACKGROUND = 400;  // Background CO2 level in ppm
const CO2_PER_PERSON = 38;   // CO2 generation rate per person in ppm
const VOLUME_COEFFICIENT = 0.8; // Coefficient for room volume
const VENTILATION_RATE = 0.2;  // Ventilation rate constant
const IAQ_FACTOR = 0.15;      // IAQ influence factor
const TVOC_FACTOR = 0.2;      // TVOC impact factor
const ETOH_FACTOR = 0.1;      // Ethanol impact factor
const RETENTION_FACTOR = 0.85; // How much CO2 is retained in the air over time

/**
 * Calculate crowd density based on CO2 and other sensor data
 * Using the enhanced model from the research paper
 * @param reading - Current sensor reading
 * @returns Predicted crowd density (0-1 scale)
 */
export function calculateEnhancedDensity(reading: SensorReading): number {
  // Calculate the CO2 above background level
  const co2Differential = Math.max(0, reading.eco2 - CO2_BACKGROUND);
  
  // Basic crowd density based on CO2 differential
  let baseDensity = co2Differential / (CO2_PER_PERSON * 8);
  
  // Apply volume coefficient - larger spaces dilute CO2
  baseDensity *= VOLUME_COEFFICIENT;
  
  // Calculate the IAQ contribution factor
  // Higher IAQ values indicate worse air quality
  const iaqContribution = Math.min(1, reading.iaq / 200) * IAQ_FACTOR;
  
  // Calculate the TVOC contribution
  const tvocNormalized = Math.min(1, reading.tvoc / 1000) * TVOC_FACTOR;
  
  // Calculate the ethanol contribution
  // Ethanol can be a good indicator of human presence (breath, etc.)
  const etohNormalized = Math.min(1, reading.etoh / 500) * ETOH_FACTOR;
  
  // Combine all factors into final density estimation
  const finalDensity = baseDensity + iaqContribution + tvocNormalized + etohNormalized;
  
  // Apply constraints to keep density within reasonable bounds
  return Math.min(1.5, Math.max(0, finalDensity));
}

/**
 * Estimate crowd count based on density
 * @param density - Crowd density value
 * @returns Estimated crowd count
 */
export function estimateCrowdCount(density: number): number {
  // Simple linear model, assuming density of 1.0 = 350 people
  // This would be customized based on the venue size and capacity
  return Math.round(density * 350);
}

/**
 * Predict future crowd density using time series analysis
 * @param historicalData - Array of historical processed data
 * @param currentReading - Current sensor readings
 * @param minutesAhead - Number of minutes to predict ahead
 * @returns Prediction output with arrays for timestamps, density, crowdCount, and confidence
 */
export function predictFutureDensity(
  historicalData: SensorData[], 
  currentReading: SensorReading, 
  minutesAhead: number
): PredictionOutput {
  // Prepare arrays for prediction results
  const timestamps: number[] = [];
  const densityValues: number[] = [];
  const crowdCountValues: number[] = [];
  const confidenceValues: number[] = [];
  
  // Calculate current density
  const currentDensity = calculateEnhancedDensity(currentReading);
  
  // Current time
  const now = new Date();
  
  // Add current values to the prediction
  timestamps.push(now.getTime());
  densityValues.push(currentDensity);
  crowdCountValues.push(estimateCrowdCount(currentDensity));
  confidenceValues.push(1.0); // 100% confidence for current reading
  
  // If no historical data, use simple model for prediction
  if (!historicalData || historicalData.length < 5) {
    return simpleModelPrediction(currentDensity, now, minutesAhead);
  }
  
  // Time-series analysis based on historical data
  // Get recent trends in density changes
  const trendFactors = calculateTrendFactors(historicalData);
  
  // Current state
  let predictedDensity = currentDensity;
  let predictedCO2 = currentReading.eco2;
  let predictedTVOC = currentReading.tvoc;
  let predictedEtOH = currentReading.etoh;
  let predictedIAQ = currentReading.iaq;
  
  // Generate prediction for each future minute
  for (let minute = 1; minute <= minutesAhead; minute++) {
    const timestamp = new Date(now.getTime() + minute * 60 * 1000);
    
    // Apply trend model
    const trendImpact = applyTrendModel(timestamp, trendFactors);
    
    // Update predicted sensor values using retention dynamics
    predictedCO2 = applyRetention(predictedCO2, CO2_BACKGROUND, trendImpact.co2Factor);
    predictedTVOC = applyRetention(predictedTVOC, 0, trendImpact.tvocFactor);
    predictedEtOH = applyRetention(predictedEtOH, 0, trendImpact.etohFactor);
    predictedIAQ = applyRetention(predictedIAQ, 1, trendImpact.iaqFactor);
    
    // Calculate new density based on predicted sensor values
    predictedDensity = calculateEnhancedDensity({
      eco2: predictedCO2,
      tvoc: predictedTVOC,
      etoh: predictedEtOH,
      iaq: predictedIAQ
    });
    
    // Add to prediction arrays
    timestamps.push(timestamp.getTime());
    densityValues.push(predictedDensity);
    crowdCountValues.push(estimateCrowdCount(predictedDensity));
    
    // Calculate confidence (decreases with time)
    const confidence = Math.max(0.5, 1 - (minute / (minutesAhead * 2)));
    confidenceValues.push(confidence);
  }
  
  return {
    timestamps,
    density: densityValues,
    crowdCount: crowdCountValues,
    confidence: confidenceValues
  };
}

/**
 * Apply retention model to sensor values
 */
function applyRetention(currentValue: number, baselineValue: number, changeFactor: number): number {
  // Sensor values trend back to baseline while also accounting for change factor
  const baselinePull = (baselineValue - currentValue) * (1 - RETENTION_FACTOR);
  const changeImpact = changeFactor;
  
  return currentValue + baselinePull + changeImpact;
}

/**
 * Calculate trend factors from historical data
 */
function calculateTrendFactors(historicalData: SensorData[]): any {
  // Sort data by timestamp in ascending order
  const sortedData = [...historicalData].sort((a, b) => 
    new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );
  
  // Get recent changes
  const recentChanges = {
    co2: [] as number[],
    tvoc: [] as number[],
    etoh: [] as number[],
    iaq: [] as number[]
  };
  
  // Calculate minute-by-minute changes
  for (let i = 1; i < sortedData.length; i++) {
    const currentRecord = sortedData[i];
    const prevRecord = sortedData[i-1];
    
    const currentTime = new Date(currentRecord.timestamp).getTime();
    const prevTime = new Date(prevRecord.timestamp).getTime();
    
    // Minutes between readings
    const minutesElapsed = (currentTime - prevTime) / (1000 * 60);
    
    // Skip if readings are more than 10 minutes apart
    if (minutesElapsed > 10) continue;
    
    if (minutesElapsed > 0) {
      recentChanges.co2.push((currentRecord.eco2 - prevRecord.eco2) / minutesElapsed);
      recentChanges.tvoc.push((currentRecord.tvoc - prevRecord.tvoc) / minutesElapsed);
      recentChanges.etoh.push((currentRecord.etoh - prevRecord.etoh) / minutesElapsed);
      recentChanges.iaq.push((currentRecord.iaq - prevRecord.iaq) / minutesElapsed);
    }
  }
  
  // Calculate average changes
  return {
    co2Average: calculateAverage(recentChanges.co2) || 0,
    tvocAverage: calculateAverage(recentChanges.tvoc) || 0,
    etohAverage: calculateAverage(recentChanges.etoh) || 0,
    iaqAverage: calculateAverage(recentChanges.iaq) || 0
  };
}

/**
 * Calculate average of an array of numbers
 */
function calculateAverage(values: number[]): number {
  if (!values.length) return 0;
  return values.reduce((sum, val) => sum + val, 0) / values.length;
}

/**
 * Apply trend model based on time patterns
 */
function applyTrendModel(timestamp: Date, trendFactors: any): any {
  // Get hour of day to account for typical crowd patterns
  const hour = timestamp.getHours();
  
  // Adjust factors based on time of day
  let timeMultiplier = 1.0;
  
  // Morning rush (9-10 AM)
  if (hour >= 9 && hour < 10) {
    timeMultiplier = 1.2;
  }
  // Lunch time (12-2 PM)
  else if (hour >= 12 && hour < 14) {
    timeMultiplier = 1.3;
  }
  // Evening rush (5-7 PM)
  else if (hour >= 17 && hour < 19) {
    timeMultiplier = 1.5;
  }
  // Night time (10 PM - 6 AM)
  else if (hour >= 22 || hour < 6) {
    timeMultiplier = 0.7;
  }
  
  // Random fluctuation factor (small random variations)
  const randomFactor = ((Math.random() - 0.5) * 2);
  
  return {
    co2Factor: trendFactors.co2Average * timeMultiplier + randomFactor,
    tvocFactor: trendFactors.tvocAverage * timeMultiplier + randomFactor,
    etohFactor: trendFactors.etohAverage * timeMultiplier + randomFactor,
    iaqFactor: trendFactors.iaqAverage * timeMultiplier + randomFactor
  };
}

/**
 * Simple model prediction when historical data is insufficient
 */
function simpleModelPrediction(currentDensity: number, now: Date, minutesAhead: number): PredictionOutput {
  const timestamps: number[] = [];
  const densityValues: number[] = [];
  const crowdCountValues: number[] = [];
  const confidenceValues: number[] = [];
  
  // Add current values
  timestamps.push(now.getTime());
  densityValues.push(currentDensity);
  crowdCountValues.push(estimateCrowdCount(currentDensity));
  confidenceValues.push(1.0);
  
  // Current density value
  let predictedDensity = currentDensity;
  
  // Generate prediction for each minute
  for (let minute = 1; minute <= minutesAhead; minute++) {
    const timestamp = new Date(now.getTime() + minute * 60 * 1000);
    const hour = timestamp.getHours();
    
    // Basic time-based trends
    let trend = 0;
    
    // Morning rush (9-10 AM)
    if (hour >= 9 && hour < 10) {
      trend = 0.01;
    }
    // Lunch time (12-2 PM)
    else if (hour >= 12 && hour < 14) {
      trend = 0.015;
    }
    // Evening rush (5-7 PM)
    else if (hour >= 17 && hour < 19) {
      trend = 0.02;
    }
    // Night time (10 PM - 6 AM)
    else if (hour >= 22 || hour < 6) {
      trend = -0.01;
    }
    // Default slight decay
    else {
      trend = -0.005;
    }
    
    // Random fluctuation
    const randomFactor = (Math.random() - 0.5) * 0.02;
    
    // Update predicted density
    predictedDensity = Math.max(0, Math.min(1.5, predictedDensity + trend + randomFactor));
    
    // Add to prediction arrays
    timestamps.push(timestamp.getTime());
    densityValues.push(predictedDensity);
    crowdCountValues.push(estimateCrowdCount(predictedDensity));
    
    // Calculate confidence (decreases with time)
    const confidence = Math.max(0.5, 1 - (minute / (minutesAhead * 2)));
    confidenceValues.push(confidence);
  }
  
  return {
    timestamps,
    density: densityValues,
    crowdCount: crowdCountValues,
    confidence: confidenceValues
  };
}