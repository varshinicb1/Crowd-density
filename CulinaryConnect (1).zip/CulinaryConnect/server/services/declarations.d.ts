// Type declarations for modules without type definitions

declare module 'qrcode-terminal';