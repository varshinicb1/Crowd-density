/**
 * Test SMS Service
 * This is a simple, direct function to test SMS functionality
 */

import axios from 'axios';
import { sendDemoSms } from './demo-sms';

// Using TextBelt API for SMS - free tier allows one text message per day
const SMS_API_URL = 'https://textbelt.com/text';

/**
 * Send a direct test SMS to a specified phone number
 * Automatically uses demo SMS service for Indian numbers since TextBelt has disabled free SMS to India
 * 
 * @param phoneNumber The phone number to send SMS to
 * @returns Promise with result of the SMS sending attempt
 */
export async function sendTestMessage(phoneNumber: string): Promise<{success: boolean, message: string}> {
  try {
    // Validate phone number format
    if (!phoneNumber || !phoneNumber.trim() || phoneNumber.length < 8) {
      console.error('Invalid phone number for SMS test:', phoneNumber);
      return { 
        success: false, 
        message: 'Invalid phone number format' 
      };
    }
    
    // Clean up the phone number - remove spaces, ensure international format
    const cleanNumber = phoneNumber.replace(/\s+/g, '');
    
    // Check if it's an Indian number
    const isIndianNumber = cleanNumber.startsWith('+91') || cleanNumber.startsWith('91');
    
    // Prepare test message
    const message = `Crowd Monitoring System - TEST SMS at ${new Date().toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })} IST. This confirms SMS notifications are working correctly.`;
    
    console.log(`Sending test SMS to ${cleanNumber}`);
    
    // If it's an Indian number, use the demo service (TextBelt blocks free SMS to India)
    if (isIndianNumber) {
      console.log('Using Demo SMS service for Indian phone number');
      return await sendDemoSms(cleanNumber, message);
    }
    
    // For non-Indian numbers, try using TextBelt
    const response = await axios.post(SMS_API_URL, {
      phone: cleanNumber,
      message: message,
      key: 'textbelt'  // Free TextBelt key allows 1 message per day
    });
    
    console.log('SMS API response:', response.data);
    
    if (response.data && response.data.success) {
      return {
        success: true,
        message: 'Test SMS sent successfully'
      };
    } else {
      if (response.data?.error?.includes('disabled for this country')) {
        // If country is blocked, fall back to demo service
        console.log('TextBelt blocked this country. Using Demo SMS service instead.');
        return await sendDemoSms(cleanNumber, message);
      }
      
      return {
        success: false,
        message: `Failed to send SMS: ${response.data.error || 'Unknown error'}`
      };
    }
  } catch (error: any) {
    console.error('Error sending test SMS:', error);
    return {
      success: false,
      message: `Error sending SMS: ${error?.message || 'Unknown error'}`
    };
  }
}