/**
 * Demo SMS Service for India
 * Since TextBelt has disabled free SMS to India, this demo service simulates SMS delivery
 * for testing purposes
 */

// Simulate a delay like a real API call
const simulateApiDelay = () => new Promise(resolve => setTimeout(resolve, 500));

/**
 * Send a simulated SMS to Indian numbers for demonstration purposes
 * 
 * @param phoneNumber The phone number to send SMS to
 * @param message The message content
 * @returns Promise with result of the SMS sending attempt
 */
export async function sendDemoSms(phoneNumber: string, message: string): Promise<{success: boolean, message: string}> {
  try {
    // Validate phone number format (basic check for Indian numbers)
    if (!phoneNumber || !phoneNumber.trim()) {
      console.error('Invalid phone number for demo SMS:', phoneNumber);
      return { 
        success: false, 
        message: 'Invalid phone number format' 
      };
    }
    
    // Clean up the phone number and check if it's an Indian number
    const cleanNumber = phoneNumber.replace(/\s+/g, '');
    const isIndianNumber = cleanNumber.startsWith('+91') || cleanNumber.startsWith('91');
    
    if (!isIndianNumber) {
      return {
        success: false,
        message: 'This demo SMS service only works with Indian phone numbers'
      };
    }
    
    console.log(`📱 DEMO SMS: Sending message to ${cleanNumber}`);
    console.log(`📱 DEMO SMS: Content: ${message}`);
    
    // Simulate API delay
    await simulateApiDelay();
    
    // Log the message that would have been sent
    console.log(`📱 DEMO SMS SENT SUCCESSFULLY TO ${cleanNumber}`);
    console.log('--------------- DEMO SMS CONTENT ---------------');
    console.log(message);
    console.log('------------------------------------------------');
    
    return {
      success: true,
      message: 'Demo SMS sent successfully (This is a simulation as real SMS delivery to India is disabled)'
    };
  } catch (error: any) {
    console.error('Error in demo SMS service:', error);
    return {
      success: false,
      message: `Error in demo SMS service: ${error?.message || 'Unknown error'}`
    };
  }
}