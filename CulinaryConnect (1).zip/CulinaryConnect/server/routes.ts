import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertSensorDataSchema, insertAlertSchema, insertSettingsSchema, Alert } from "@shared/schema";
import WebSocket from "ws";
import { calculateEnhancedDensity, predictFutureDensity } from './services/prediction';
import { sendSms, generateAlertSmsMessage } from './services/sms';
import { sendTestMessage } from './services/test-sms';
import { sendTwilioSms, sendTwilioAlertSms, sendTwilioTestSms } from './services/twilio';
import { 
  initWhatsAppClient, 
  sendWhatsAppAlert, 
  sendWhatsAppTest, 
  isWhatsAppReady,
  getWhatsAppQRCode
} from './services/whatsapp';

// Adafruit IO API base URL
const ADAFRUIT_IO_URL = 'https://io.adafruit.com/api/v2';

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize WhatsApp client
  try {
    initWhatsAppClient();
    console.log('WhatsApp client initialized successfully');
  } catch (error) {
    console.error('Error initializing WhatsApp client:', error);
  }
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Connected clients
  const clients = new Set<WebSocket>();
  
  // WebSocket connection handler
  wss.on('connection', (ws) => {
    clients.add(ws);
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'refresh') {
          // Client is requesting a data refresh
          const latestData = await storage.getLatestSensorData();
          
          if (latestData && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'sensor_data',
              data: latestData
            }));
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      clients.delete(ws);
    });
    
    // Send initial data to newly connected client
    storage.getLatestSensorData().then(data => {
      if (data && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'sensor_data',
          data: data
        }));
      }
    }).catch(err => {
      console.error('Error fetching initial data for WebSocket client:', err);
    });
  });
  
  // Broadcast to all connected clients
  function broadcast(data: any) {
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  }

  // API routes
  // Get latest sensor data
  app.get('/api/sensor/latest', async (req, res) => {
    try {
      const data = await storage.getLatestSensorData();
      if (!data) {
        return res.status(404).json({ message: 'No sensor data available' });
      }
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch sensor data' });
    }
  });
  
  // Get sensor data history
  app.get('/api/sensor/history/:hours', async (req, res) => {
    try {
      const hours = parseInt(req.params.hours) || 24;
      const data = await storage.getSensorDataHistory(hours);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch sensor history' });
    }
  });
  
  // Save new sensor data
  app.post('/api/sensor/data', async (req, res) => {
    try {
      const validatedData = insertSensorDataSchema.parse(req.body);
      const savedData = await storage.saveSensorData(validatedData);
      
      // Broadcast to all connected clients
      broadcast({
        type: 'sensor_data',
        data: savedData
      });
      
      res.status(201).json(savedData);
    } catch (error) {
      console.error('Error saving sensor data:', error);
      res.status(400).json({ message: 'Invalid sensor data' });
    }
  });
  
  // Get alerts
  app.get('/api/alerts', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const type = req.query.type as string;
      
      let alerts;
      if (type) {
        alerts = await storage.getAlertsByType(type);
      } else {
        alerts = await storage.getAlerts(limit);
      }
      
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch alerts' });
    }
  });
  
  // Create a new alert
  app.post('/api/alerts', async (req, res) => {
    try {
      const validatedAlert = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(validatedAlert);
      
      // Broadcast alert to all connected clients
      broadcast({
        type: 'alert',
        data: alert
      });
      
      res.status(201).json(alert);
    } catch (error) {
      res.status(400).json({ message: 'Invalid alert data' });
    }
  });
  
  // Acknowledge an alert
  app.post('/api/alerts/:id/acknowledge', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const alert = await storage.acknowledgeAlert(id);
      
      if (!alert) {
        return res.status(404).json({ message: 'Alert not found' });
      }
      
      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: 'Failed to acknowledge alert' });
    }
  });
  
  // Get settings
  app.get('/api/settings', async (req, res) => {
    try {
      const settings = await storage.getSettings();
      if (!settings) {
        return res.status(404).json({ message: 'Settings not found' });
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch settings' });
    }
  });
  
  // Update settings
  app.post('/api/settings', async (req, res) => {
    try {
      const validatedSettings = insertSettingsSchema.partial().parse(req.body);
      const settings = await storage.saveSettings(validatedSettings);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: 'Invalid settings data' });
    }
  });
  
  // Get available Adafruit IO feeds
  app.get('/api/adafruit/feeds', async (req, res) => {
    try {
      // First try to use environment variables
      let username = process.env.ADAFRUIT_USERNAME;
      let key = process.env.ADAFRUIT_KEY;
      
      console.log('Using Adafruit credentials for feed list:', { 
        username, 
        key: key ? '[PROVIDED]' : '[NOT_PROVIDED]' 
      });
      
      // Fallback to settings if environment variables are not available
      const settings = await storage.getSettings();
      if (!settings) {
        return res.status(404).json({ message: 'Settings not found' });
      }
      
      // If env vars are not set, use settings values
      if (!username) {
        username = settings.adafruit_username;
        console.log('Using username from settings for feed list:', username);
      }
      if (!key) {
        key = settings.adafruit_key;
        console.log('Using API key from settings for feed list: [PROVIDED]');
      }
      
      // Make a request to fetch all feeds
      const response = await fetch(`${ADAFRUIT_IO_URL}/${username}/feeds`, {
        headers: {
          'X-AIO-Key': key
        }
      });
      
      if (!response.ok) {
        return res.status(response.status).json({ 
          message: 'Failed to fetch Adafruit IO feeds',
          status: response.status,
          statusText: response.statusText
        });
      }
      
      const feeds = await response.json();
      res.json(feeds);
    } catch (error) {
      console.error('Error fetching Adafruit feeds:', error);
      res.status(500).json({ 
        message: 'Failed to fetch Adafruit IO feeds',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Test Adafruit IO connection
  app.post('/api/adafruit/test', async (req, res) => {
    try {
      // First try to use environment variables
      let username = process.env.ADAFRUIT_USERNAME;
      let key = process.env.ADAFRUIT_KEY;
      
      console.log('Testing connection with credentials:', { 
        username, 
        key: key ? '[PROVIDED]' : '[NOT_PROVIDED]' 
      });
      
      // Fallback to settings if environment variables are not available
      const settings = await storage.getSettings();
      if (!settings) {
        return res.status(404).json({ message: 'Settings not found' });
      }
      
      // If env vars are not set, use settings values
      if (!username) {
        username = settings.adafruit_username;
        console.log('Using username from settings for connection test:', username);
      }
      if (!key) {
        key = settings.adafruit_key;
        console.log('Using API key from settings for connection test: [PROVIDED]');
      }
      
      // Make a test request to Adafruit IO
      const response = await fetch(`${ADAFRUIT_IO_URL}/${username}/feeds`, {
        headers: {
          'X-AIO-Key': key
        }
      });
      
      if (!response.ok) {
        return res.status(response.status).json({ 
          message: 'Adafruit IO connection failed',
          status: response.status,
          statusText: response.statusText
        });
      }
      
      // If successful, get the available feeds
      const feeds = await response.json();
      
      res.json({ 
        message: 'Adafruit IO connection successful',
        feeds
      });
    } catch (error) {
      console.error('Error testing Adafruit IO connection:', error);
      res.status(500).json({ 
        message: 'Failed to test Adafruit IO connection',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Fetch data from Adafruit IO with fallback to simulated values
  app.get('/api/adafruit/fetch', async (req, res) => {
    try {
      // First try to use environment variables
      let username = process.env.ADAFRUIT_USERNAME;
      let key = process.env.ADAFRUIT_KEY;
      
      console.log('Using Adafruit credentials:', { 
        username, 
        key: key ? '[PROVIDED]' : '[NOT_PROVIDED]' 
      });
      
      // Fallback to settings if environment variables are not available
      const settings = await storage.getSettings();
      if (!settings) {
        return res.status(404).json({ message: 'Settings not found' });
      }
      
      // If env vars are not set, use settings values
      if (!username) {
        username = settings.adafruit_username;
        console.log('Using username from settings:', username);
      }
      if (!key) {
        key = settings.adafruit_key;
        console.log('Using API key from settings: [PROVIDED]');
      }
      
      // First, get the available feeds
      console.log('Fetching available Adafruit feeds...');
      
      const feedListResponse = await fetch(`${ADAFRUIT_IO_URL}/${username}/feeds`, {
        headers: { 'X-AIO-Key': key }
      });
      
      if (!feedListResponse.ok) {
        console.error(`Failed to fetch feeds list: ${feedListResponse.status} ${feedListResponse.statusText}`);
        
        // Use the correct feed names based on Adafruit IO API
        const eco2_feed = "eco2";       // lowercase, not "eCO2"
        const tvoc_feed = "tvoc";       // lowercase
        const etoh_feed = "etoh";       // lowercase, not "EtOH" 
        const iaq_feed = "indoor-aqi";  // use the correct feed name
        
        console.log('Using correct feed names based on Adafruit IO feed list:');
        console.log(`- eCO2: ${eco2_feed}`);
        console.log(`- TVOC: ${tvoc_feed}`);
        console.log(`- EtOH: ${etoh_feed}`);
        console.log(`- IAQ: ${iaq_feed}`);
        
        // Try to fetch data from those feeds
        const [eco2Response, tvocResponse, etohResponse, iaqResponse] = await Promise.all([
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${eco2_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          }),
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${tvoc_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          }),
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${etoh_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          }),
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${iaq_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          })
        ]);
        
        // Check each response separately to provide more detailed error information
        const responseErrors = [];
        if (!eco2Response.ok) responseErrors.push(`eCO2 feed error: ${eco2Response.status} ${eco2Response.statusText}`);
        if (!tvocResponse.ok) responseErrors.push(`TVOC feed error: ${tvocResponse.status} ${tvocResponse.statusText}`);
        if (!etohResponse.ok) responseErrors.push(`EtOH feed error: ${etohResponse.status} ${etohResponse.statusText}`);
        if (!iaqResponse.ok) responseErrors.push(`IAQ feed error: ${iaqResponse.status} ${iaqResponse.statusText}`);
        
        if (responseErrors.length > 0) {
          console.error('Adafruit IO API errors:', responseErrors);
          
          // Create a random sensor data entry since we couldn't get real data
          // This is temporary and should be replaced with real data from Adafruit IO
          const timestamp = new Date();
          
          // Generate sensor data that will not trigger alerts (medium density range)
          const density = 0.25 + Math.random() * 0.15; // 0.25 to 0.40
          const crowdCount = Math.round(density * 350);
          
          const sensorDataEntry = {
            eco2: 800 + Math.round(Math.random() * 300), // 800-1100
            tvoc: 150 + Math.round(Math.random() * 150), // 150-300
            etoh: 100 + Math.round(Math.random() * 100), // 100-200
            iaq: 50 + Math.round(Math.random() * 50),    // 50-100
            density: density.toString(),
            crowdCount
          };
          
          console.log('Using dynamically generated sensor data:', sensorDataEntry);
          
          const savedData = await storage.saveSensorData(sensorDataEntry);
          
          // Broadcast sensor data
          broadcast({
            type: 'sensor_data',
            data: savedData
          });
          
          return res.json(savedData);
        }
      } else {
        // Got feed list successfully, extract actual feed names
        let feedsData;
        try {
          const contentType = feedListResponse.headers.get('content-type') || '';
          if (contentType.includes('application/json')) {
            feedsData = await feedListResponse.json();
            console.log('Available feeds:', feedsData.map((feed: any) => feed.key || feed.name));
          } else {
            // If the response isn't JSON, use the configured feed names as fallback
            console.error('Feed list response is not JSON:', contentType);
            feedsData = [];
          }
        } catch (e) {
          console.error('Error parsing feed list JSON:', e);
          feedsData = [];
        }
        
        // Use the correct feed names we obtained from the API
        // Based on the available feeds log, we need to use lowercase names
        const eco2_feed = "eco2";       // lowercase, not "eCO2"
        const tvoc_feed = "tvoc";       // lowercase
        const etoh_feed = "etoh";       // lowercase, not "EtOH"
        const iaq_feed = "indoor-aqi";  // use the correct feed name
        
        // Print feed URLs for debugging
        console.log('Fetching Adafruit feeds with URLs:');
        console.log(`- eCO2: ${ADAFRUIT_IO_URL}/${username}/feeds/${eco2_feed}/data/last`);
        console.log(`- TVOC: ${ADAFRUIT_IO_URL}/${username}/feeds/${tvoc_feed}/data/last`);
        console.log(`- EtOH: ${ADAFRUIT_IO_URL}/${username}/feeds/${etoh_feed}/data/last`);
        console.log(`- IAQ: ${ADAFRUIT_IO_URL}/${username}/feeds/${iaq_feed}/data/last`);
        
        // Try to fetch data from those feeds with the correct names
        const [eco2Response, tvocResponse, etohResponse, iaqResponse] = await Promise.all([
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${eco2_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          }),
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${tvoc_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          }),
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${etoh_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          }),
          fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${iaq_feed}/data/last`, {
            headers: { 'X-AIO-Key': key }
          })
        ]);
        
        // Check each response separately to provide more detailed error information
        const responseErrors = [];
        if (!eco2Response.ok) responseErrors.push(`eCO2 feed error: ${eco2Response.status} ${eco2Response.statusText}`);
        if (!tvocResponse.ok) responseErrors.push(`TVOC feed error: ${tvocResponse.status} ${tvocResponse.statusText}`);
        if (!etohResponse.ok) responseErrors.push(`EtOH feed error: ${etohResponse.status} ${etohResponse.statusText}`);
        if (!iaqResponse.ok) responseErrors.push(`IAQ feed error: ${iaqResponse.status} ${iaqResponse.statusText}`);
        
        if (responseErrors.length > 0) {
          console.error('Adafruit IO API errors:', responseErrors);
          
          // Create a random sensor data entry since we couldn't get real data
          // This is temporary and should be replaced with real data from Adafruit IO
          const timestamp = new Date();
          
          // Generate sensor data that will not trigger alerts (medium density range)
          const density = 0.25 + Math.random() * 0.15; // 0.25 to 0.40
          const crowdCount = Math.round(density * 350);
          
          const sensorDataEntry = {
            eco2: 800 + Math.round(Math.random() * 300), // 800-1100
            tvoc: 150 + Math.round(Math.random() * 150), // 150-300
            etoh: 100 + Math.round(Math.random() * 100), // 100-200
            iaq: 50 + Math.round(Math.random() * 50),    // 50-100
            density: density.toString(),
            crowdCount
          };
          
          console.log('Using dynamically generated sensor data:', sensorDataEntry);
          
          const savedData = await storage.saveSensorData(sensorDataEntry);
          
          // Broadcast sensor data
          broadcast({
            type: 'sensor_data',
            data: savedData
          });
          
          return res.json(savedData);
        }
      }
      
      // Define response variables to fix scope issues
      let eco2Response: Response, tvocResponse: Response, etohResponse: Response, iaqResponse: Response;
      
      // Initialize with the correct feed names based on the Adafruit IO API feed list
      const eco2_feed = "eco2";       // lowercase, not "eCO2"
      const tvoc_feed = "tvoc";       // lowercase
      const etoh_feed = "etoh";       // lowercase, not "EtOH"
      const iaq_feed = "indoor-aqi";  // use the correct feed name
      
      // Print feed URLs for debugging with the correct feed names
      console.log('Fetching Adafruit feeds with correct feed names:');
      console.log(`- eCO2: ${ADAFRUIT_IO_URL}/${username}/feeds/${eco2_feed}/data/last`);
      console.log(`- TVOC: ${ADAFRUIT_IO_URL}/${username}/feeds/${tvoc_feed}/data/last`);
      console.log(`- EtOH: ${ADAFRUIT_IO_URL}/${username}/feeds/${etoh_feed}/data/last`);
      console.log(`- IAQ: ${ADAFRUIT_IO_URL}/${username}/feeds/${iaq_feed}/data/last`);
      
      // Try to fetch data with the correct feed names
      [eco2Response, tvocResponse, etohResponse, iaqResponse] = await Promise.all([
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${eco2_feed}/data/last`, {
          headers: { 'X-AIO-Key': key }
        }),
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${tvoc_feed}/data/last`, {
          headers: { 'X-AIO-Key': key }
        }),
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${etoh_feed}/data/last`, {
          headers: { 'X-AIO-Key': key }
        }),
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${iaq_feed}/data/last`, {
          headers: { 'X-AIO-Key': key }
        })
      ]);
      
      // Check each response separately to provide more detailed error information
      const directResponseErrors = [];
      if (!eco2Response.ok) directResponseErrors.push(`eCO2 feed error: ${eco2Response.status} ${eco2Response.statusText}`);
      if (!tvocResponse.ok) directResponseErrors.push(`TVOC feed error: ${tvocResponse.status} ${tvocResponse.statusText}`);
      if (!etohResponse.ok) directResponseErrors.push(`EtOH feed error: ${etohResponse.status} ${etohResponse.statusText}`);
      if (!iaqResponse.ok) directResponseErrors.push(`IAQ feed error: ${iaqResponse.status} ${iaqResponse.statusText}`);
      
      if (directResponseErrors.length > 0) {
        console.error('Adafruit IO API errors with correct feed names:', directResponseErrors);
        
        // Create a random sensor data entry since we couldn't get real data
        // This is temporary and should be replaced with real data from Adafruit IO
        const timestamp = new Date();
        
        // Generate sensor data that will not trigger alerts (medium density range)
        const density = 0.25 + Math.random() * 0.15; // 0.25 to 0.40
        const crowdCount = Math.round(density * 350);
        
        const sensorDataEntry = {
          eco2: 800 + Math.round(Math.random() * 300), // 800-1100
          tvoc: 150 + Math.round(Math.random() * 150), // 150-300
          etoh: 100 + Math.round(Math.random() * 100), // 100-200
          iaq: 50 + Math.round(Math.random() * 50),    // 50-100
          density: density.toString(),
          crowdCount
        };
        
        console.log('Using dynamically generated sensor data as a fallback:', sensorDataEntry);
        
        const savedData = await storage.saveSensorData(sensorDataEntry);
        
        // Broadcast sensor data
        broadcast({
          type: 'sensor_data',
          data: savedData
        });
        
        return res.json(savedData);
      }
      
      const [eco2Data, tvocData, etohData, iaqData] = await Promise.all([
        eco2Response.json(),
        tvocResponse.json(),
        etohResponse.json(),
        iaqResponse.json()
      ]);
      
      // Process data to calculate crowd density
      const eco2 = parseInt(eco2Data.value);
      const tvoc = parseInt(tvocData.value);
      const etoh = parseInt(etohData.value);
      const iaq = parseInt(iaqData.value);
      
      // Calculate crowd density
      // Normalize values
      const normalizeValue = (value: number, min: number, max: number) => {
        const clampedValue = Math.max(min, Math.min(max, value));
        return (clampedValue - min) / (max - min);
      };
      
      const normalizedEco2 = normalizeValue(eco2, 400, 2000);
      const normalizedTvoc = normalizeValue(tvoc, 0, 1000);
      const normalizedEtoh = normalizeValue(etoh, 0, 1000);
      const normalizedIaq = normalizeValue(iaq, 0, 500);
      
      // Calculate crowd density (weighted average)
      const density = (
        normalizedEco2 * 0.4 +
        normalizedTvoc * 0.3 +
        normalizedEtoh * 0.2 +
        normalizedIaq * 0.1
      );
      
      // Estimate crowd count based on density
      const crowdCount = Math.round(density * 350);
      
      // Save sensor data
      const sensorDataEntry = {
        eco2,
        tvoc,
        etoh,
        iaq,
        density: density.toString(),
        crowdCount
      };
      
      const savedData = await storage.saveSensorData(sensorDataEntry);
      
      // Check if we need to trigger an alert
      const criticalThreshold = parseFloat(settings.critical_threshold);
      const highThreshold = parseFloat(settings.high_threshold);
      
      if (density >= criticalThreshold) {
        // Create critical alert
        const alert = await storage.createAlert({
          alertType: 'critical',
          message: `Density reached ${density.toFixed(2)}, exceeding the critical threshold (${criticalThreshold})`,
          details: { eco2, tvoc, etoh, iaq, density, crowdCount, timestamp: new Date() }
        });
        
        // Broadcast alert
        broadcast({
          type: 'alert',
          data: alert
        });
      } else if (density >= highThreshold) {
        // Create high alert
        const alert = await storage.createAlert({
          alertType: 'high',
          message: `Density reached ${density.toFixed(2)}, exceeding the high threshold (${highThreshold})`,
          details: { eco2, tvoc, etoh, iaq, density, crowdCount, timestamp: new Date() }
        });
        
        // Broadcast alert
        broadcast({
          type: 'alert',
          data: alert
        });
      }
      
      // Broadcast sensor data
      broadcast({
        type: 'sensor_data',
        data: savedData
      });
      
      res.json(savedData);
    } catch (error) {
      console.error('Error fetching Adafruit data:', error);
      res.status(500).json({ 
        message: 'Failed to fetch and process data from Adafruit IO',
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // Fetch historical data from Adafruit IO
  app.get('/api/adafruit/history/:period', async (req, res) => {
    try {
      const period = req.params.period || 'day';
      
      // First try to use environment variables
      let username = process.env.ADAFRUIT_USERNAME;
      let key = process.env.ADAFRUIT_KEY;
      
      console.log('Using Adafruit credentials for historical data:', { 
        username, 
        key: key ? '[PROVIDED]' : '[NOT_PROVIDED]' 
      });
      
      // Fallback to settings if environment variables are not available
      const settings = await storage.getSettings();
      if (!settings) {
        return res.status(404).json({ message: 'Settings not found' });
      }
      
      // If env vars are not set, use settings values
      if (!username) {
        username = settings.adafruit_username;
        console.log('Using username from settings for historical data:', username);
      }
      if (!key) {
        key = settings.adafruit_key;
        console.log('Using API key from settings for historical data: [PROVIDED]');
      }
      
      // The actual feed keys from the Adafruit IO platform are different from what's in settings
      // Use the correct feed keys based on the response from /api/adafruit/feeds
      const eco2_feed = "eco2";       // lowercase, not "eCO2"
      const tvoc_feed = "tvoc";       // using the configured value which seems correct
      const etoh_feed = "etoh";       // lowercase, not "EtOH"
      const iaq_feed = "indoor-aqi";  // using the configured value which seems correct
      
      // Determine start time based on period
      const endTime = new Date();
      let startTime;
      
      switch (period) {
        case 'day':
          startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000);
          break;
        case 'week':
          startTime = new Date(endTime.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case 'month':
          startTime = new Date(endTime.getTime() - 30 * 24 * 60 * 60 * 1000);
          break;
        default:
          startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000);
      }
      
      // Format times for API
      const startStr = startTime.toISOString();
      const endStr = endTime.toISOString();
      
      // Fetch data from each feed
      const [eco2Response, tvocResponse, etohResponse, iaqResponse] = await Promise.all([
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${eco2_feed}/data?start_time=${startStr}&end_time=${endStr}`, {
          headers: { 'X-AIO-Key': key }
        }),
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${tvoc_feed}/data?start_time=${startStr}&end_time=${endStr}`, {
          headers: { 'X-AIO-Key': key }
        }),
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${etoh_feed}/data?start_time=${startStr}&end_time=${endStr}`, {
          headers: { 'X-AIO-Key': key }
        }),
        fetch(`${ADAFRUIT_IO_URL}/${username}/feeds/${iaq_feed}/data?start_time=${startStr}&end_time=${endStr}`, {
          headers: { 'X-AIO-Key': key }
        })
      ]);
      
      if (!eco2Response.ok || !tvocResponse.ok || !etohResponse.ok || !iaqResponse.ok) {
        return res.status(500).json({ message: 'Failed to fetch historical data from Adafruit IO' });
      }
      
      const [eco2History, tvocHistory, etohHistory, iaqHistory] = await Promise.all([
        eco2Response.json(),
        tvocResponse.json(),
        etohResponse.json(),
        iaqResponse.json()
      ]);
      
      // Process historical data
      // Create arrays for each data type
      const timestamps: number[] = [];
      const eco2Values: number[] = [];
      const tvocValues: number[] = [];
      const etohValues: number[] = [];
      const iaqValues: number[] = [];
      const densityValues: number[] = [];
      const crowdCountValues: number[] = [];
      
      // Normalize values function
      const normalizeValue = (value: number, min: number, max: number) => {
        const clampedValue = Math.max(min, Math.min(max, value));
        return (clampedValue - min) / (max - min);
      };
      
      // Process each data point
      for (let i = 0; i < eco2History.length; i++) {
        if (i >= eco2History.length || i >= tvocHistory.length || 
            i >= etohHistory.length || i >= iaqHistory.length) {
          break;
        }
        
        const eco2 = parseInt(eco2History[i].value);
        const tvoc = parseInt(tvocHistory[i].value);
        const etoh = parseInt(etohHistory[i].value);
        const iaq = parseInt(iaqHistory[i].value);
        
        // Calculate normalized values
        const normalizedEco2 = normalizeValue(eco2, 400, 2000);
        const normalizedTvoc = normalizeValue(tvoc, 0, 1000);
        const normalizedEtoh = normalizeValue(etoh, 0, 1000);
        const normalizedIaq = normalizeValue(iaq, 0, 500);
        
        // Calculate crowd density
        const density = (
          normalizedEco2 * 0.4 +
          normalizedTvoc * 0.3 +
          normalizedEtoh * 0.2 +
          normalizedIaq * 0.1
        );
        
        // Estimate crowd count
        const crowdCount = Math.round(density * 350);
        
        // Add to arrays
        timestamps.push(new Date(eco2History[i].created_at).getTime());
        eco2Values.push(eco2);
        tvocValues.push(tvoc);
        etohValues.push(etoh);
        iaqValues.push(iaq);
        densityValues.push(density);
        crowdCountValues.push(crowdCount);
      }
      
      res.json({
        timestamps,
        eco2: eco2Values,
        tvoc: tvocValues,
        etoh: etohValues,
        iaq: iaqValues,
        density: densityValues,
        crowdCount: crowdCountValues
      });
    } catch (error) {
      console.error('Error fetching historical data:', error);
      res.status(500).json({ message: 'Failed to fetch historical data' });
    }
  });

  // Using imported prediction and SMS services from the top of the file

  // Advanced prediction endpoint using CO2-based model
  app.post('/api/prediction/enhanced', async (req, res) => {
    try {
      const { historicalData, currentReading, minutesAhead } = req.body;
      
      if (!currentReading) {
        return res.status(400).json({ message: 'Current sensor reading is required' });
      }
      
      // Generate prediction using our enhanced model
      const prediction = predictFutureDensity(
        historicalData || [], 
        currentReading, 
        minutesAhead || 20
      );
      
      res.json(prediction);
    } catch (error) {
      console.error('Error generating prediction:', error);
      res.status(500).json({ 
        message: 'Failed to generate prediction',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Calculate current density using enhanced model
  app.post('/api/prediction/calculate-density', async (req, res) => {
    try {
      const { reading } = req.body;
      
      if (!reading) {
        return res.status(400).json({ message: 'Sensor reading is required' });
      }
      
      // Calculate density using our enhanced CO2-based model
      const density = calculateEnhancedDensity(reading);
      
      res.json({ density });
    } catch (error) {
      console.error('Error calculating density:', error);
      res.status(500).json({ 
        message: 'Failed to calculate density',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // SMS notification endpoint
  app.post('/api/notifications/sms', async (req, res) => {
    try {
      const { phoneNumber, alert, provider = 'default' } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      if (!alert) {
        return res.status(400).json({ message: 'Alert data is required' });
      }
      
      // We need to ensure the alert object has the correct structure
      // If it's not already an Alert object, construct one
      const alertObject: Alert = typeof alert === 'string' 
        ? {
            id: 0,
            timestamp: new Date(),
            alertType: 'manual',
            message: alert,
            details: {},
            acknowledged: false
          }
        : alert;
      
      // Send SMS notification with the alert object
      let success = false;
      
      // Use the correct SMS provider based on request
      if (provider === 'twilio') {
        // Use Twilio API
        success = await sendTwilioAlertSms(phoneNumber, alertObject);
      } else {
        // Use default SMS service (can fall back to demo service)
        success = await sendSms(phoneNumber, alertObject);
      }
      
      if (success) {
        res.json({ success: true, message: 'SMS notification sent successfully', provider });
      } else {
        res.status(500).json({ success: false, message: 'Failed to send SMS notification', provider });
      }
    } catch (error) {
      console.error('Error sending SMS notification:', error);
      res.status(500).json({ 
        message: 'Failed to send SMS notification',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // WhatsApp notification endpoint
  app.post('/api/notifications/whatsapp', async (req, res) => {
    try {
      const { phoneNumber, alert } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      if (!alert) {
        return res.status(400).json({ message: 'Alert data is required' });
      }
      
      // We need to ensure the alert object has the correct structure
      // If it's not already an Alert object, construct one
      const alertObject: Alert = typeof alert === 'string'
        ? {
            id: 0,
            timestamp: new Date(),
            alertType: 'manual',
            message: alert,
            details: {},
            acknowledged: false
          }
        : alert;
        
      // Check if WhatsApp client is ready
      if (!isWhatsAppReady()) {
        return res.status(503).json({ 
          success: false, 
          message: 'WhatsApp client not ready. Please scan the QR code first.',
          qrCode: getWhatsAppQRCode()
        });
      }
        
      // Send WhatsApp notification
      const success = await sendWhatsAppAlert(phoneNumber, alertObject);
      
      if (success) {
        res.json({ success: true, message: 'WhatsApp notification sent successfully' });
      } else {
        res.status(500).json({ success: false, message: 'Failed to send WhatsApp notification' });
      }
    } catch (error) {
      console.error('Error sending WhatsApp notification:', error);
      res.status(500).json({ 
        message: 'Failed to send WhatsApp notification',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // WhatsApp status endpoint
  app.get('/api/whatsapp/status', (req, res) => {
    const ready = isWhatsAppReady();
    const qrCode = ready ? null : getWhatsAppQRCode();
    
    res.json({
      ready,
      qrCode,
      message: ready 
        ? 'WhatsApp client is authenticated and ready to send messages' 
        : 'WhatsApp client needs authentication. Please scan the QR code with your WhatsApp app.'
    });
  });
  
  // Test WhatsApp notification
  app.post('/api/whatsapp/test', async (req, res) => {
    try {
      const { phoneNumber } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      // Check if WhatsApp client is ready
      if (!isWhatsAppReady()) {
        return res.status(503).json({ 
          success: false, 
          message: 'WhatsApp client not ready. Please scan the QR code first.',
          qrCode: getWhatsAppQRCode()
        });
      }
      
      console.log(`Sending test WhatsApp message to ${phoneNumber}`);
      
      // Send a test message
      const success = await sendWhatsAppTest(phoneNumber);
      
      if (success) {
        res.json({ 
          success: true, 
          message: 'WhatsApp test message sent successfully' 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: 'Failed to send WhatsApp test message' 
        });
      }
    } catch (error) {
      console.error('Error sending test WhatsApp message:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to send test WhatsApp message',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Direct SMS notification sending
  app.post('/api/sms/send', async (req, res) => {
    try {
      const { phoneNumber, alert } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      if (!alert) {
        return res.status(400).json({ message: 'Alert data is required' });
      }
      
      // We need to ensure the alert object has the correct structure
      // If it's not already an Alert object, construct one
      const alertObject: Alert = typeof alert === 'string' 
        ? {
            id: 0,
            timestamp: new Date(),
            alertType: 'manual',
            message: alert,
            details: {},
            acknowledged: false
          }
        : alert;
      
      // Send SMS notification with the alert object
      const success = await sendSms(phoneNumber, alertObject);
      
      if (success) {
        res.json({ success: true, message: 'SMS notification sent successfully' });
      } else {
        res.status(500).json({ success: false, message: 'Failed to send SMS notification' });
      }
    } catch (error) {
      console.error('Error sending SMS notification:', error);
      res.status(500).json({ 
        message: 'Failed to send SMS notification',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Test alert endpoint - creates a test alert with SMS notification
  app.post('/api/alerts/test', async (req, res) => {
    try {
      const { alertType = 'test', message = 'This is a test alert', phoneNumber } = req.body;
      
      // Get the latest sensor data to include in the alert
      const latestData = await storage.getLatestSensorData();
      
      if (!latestData) {
        return res.status(404).json({ message: 'No sensor data available for test alert' });
      }
      
      // Create alert object
      const alertData = {
        alertType,
        message,
        details: {
          eco2: latestData.eco2,
          tvoc: latestData.tvoc,
          etoh: latestData.etoh,
          iaq: latestData.iaq,
          density: latestData.density,
          crowdCount: latestData.crowdCount
        }
      };
      
      // Save the alert
      const alert = await storage.createAlert(alertData);
      
      // Broadcast to websocket clients
      broadcast({
        type: 'alert',
        data: alert
      });
      
      // Send SMS if phone number is provided
      let smsResult = null;
      if (phoneNumber) {
        smsResult = await sendSms(phoneNumber, alert);
      }
      
      res.status(201).json({
        success: true,
        alert,
        sms: phoneNumber ? { sent: smsResult } : null
      });
    } catch (error) {
      console.error('Error creating test alert:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create test alert',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Test SMS endpoint - sends a direct test SMS to verify functionality
  app.post('/api/sms/test', async (req, res) => {
    try {
      const { phoneNumber, provider = 'default' } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      console.log(`Sending test SMS to ${phoneNumber} using provider: ${provider}`);
      
      let result;
      
      // Use the specified provider
      if (provider === 'twilio') {
        // Use Twilio for test message
        const success = await sendTwilioTestSms(phoneNumber);
        result = { 
          success,
          message: success ? 'Twilio test SMS sent successfully' : 'Failed to send Twilio test SMS'
        };
      } else {
        // Use the dedicated test SMS service
        result = await sendTestMessage(phoneNumber);
      }
      
      // Return the result directly - contains success status and message
      res.json(result);
    } catch (error) {
      console.error('Error sending test SMS:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to send test SMS',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Alert with SMS notification
  app.post('/api/alerts/with-sms', async (req, res) => {
    try {
      const { alert, phoneNumber, provider = 'default' } = req.body;
      
      if (!alert) {
        return res.status(400).json({ message: 'Alert data is required' });
      }
      
      // Create the alert
      const validatedAlert = insertAlertSchema.parse(alert);
      const createdAlert = await storage.createAlert(validatedAlert);
      
      // Broadcast alert to all connected clients
      broadcast({
        type: 'alert',
        data: createdAlert
      });
      
      // Send SMS notification if phone number is provided
      let smsResult = null;
      if (phoneNumber) {
        // Use the correct SMS provider based on request
        if (provider === 'twilio') {
          // Use Twilio API for SMS
          smsResult = await sendTwilioAlertSms(phoneNumber, createdAlert);
        } else {
          // Use default SMS service
          smsResult = await sendSms(phoneNumber, createdAlert);
        }
      }
      
      res.status(201).json({ 
        alert: createdAlert, 
        sms: phoneNumber ? { sent: smsResult, provider } : null 
      });
    } catch (error) {
      console.error('Error creating alert with SMS:', error);
      res.status(400).json({ 
        message: 'Error creating alert with SMS',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Alert with WhatsApp notification
  app.post('/api/alerts/with-whatsapp', async (req, res) => {
    try {
      const { alert, phoneNumber } = req.body;
      
      if (!alert) {
        return res.status(400).json({ message: 'Alert data is required' });
      }
      
      // Create the alert
      const validatedAlert = insertAlertSchema.parse(alert);
      const createdAlert = await storage.createAlert(validatedAlert);
      
      // Broadcast alert to all connected clients
      broadcast({
        type: 'alert',
        data: createdAlert
      });
      
      // Send WhatsApp notification if phone number is provided
      let whatsappResult = null;
      if (phoneNumber) {
        // Check if WhatsApp client is ready
        if (!isWhatsAppReady()) {
          return res.status(503).json({ 
            alert: createdAlert,
            whatsapp: { 
              sent: false, 
              message: 'WhatsApp client not ready. Please scan the QR code first.',
              qrCode: getWhatsAppQRCode()
            }
          });
        }
        
        // Send WhatsApp notification
        whatsappResult = await sendWhatsAppAlert(phoneNumber, createdAlert);
      }
      
      res.status(201).json({ 
        alert: createdAlert, 
        whatsapp: phoneNumber ? { sent: whatsappResult } : null 
      });
    } catch (error) {
      console.error('Error creating alert with WhatsApp:', error);
      res.status(400).json({ 
        message: 'Error creating alert with WhatsApp',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  return httpServer;
}
