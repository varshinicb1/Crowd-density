import { 
  users, type User, type InsertUser,
  sensorData, type SensorData, type InsertSensorData,
  alerts, type Alert, type InsertAlert,
  settings, type Settings, type InsertSettings
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Sensor data methods
  saveSensorData(data: InsertSensorData): Promise<SensorData>;
  getLatestSensorData(): Promise<SensorData | undefined>;
  getSensorDataHistory(hours: number): Promise<SensorData[]>;
  
  // Alert methods
  createAlert(alert: InsertAlert): Promise<Alert>;
  getAlerts(limit: number): Promise<Alert[]>;
  getAlertsByType(type: string): Promise<Alert[]>;
  acknowledgeAlert(id: number): Promise<Alert | undefined>;
  
  // Settings methods
  getSettings(): Promise<Settings | undefined>;
  saveSettings(settings: Partial<InsertSettings>): Promise<Settings>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private sensorDataList: Map<number, SensorData>;
  private alertsList: Map<number, Alert>;
  private appSettings: Settings | undefined;
  private userIdCounter: number;
  private sensorDataIdCounter: number;
  private alertIdCounter: number;

  constructor() {
    this.users = new Map();
    this.sensorDataList = new Map();
    this.alertsList = new Map();
    this.userIdCounter = 1;
    this.sensorDataIdCounter = 1;
    this.alertIdCounter = 1;
    
    // Initialize default settings
    this.appSettings = {
      id: 1,
      critical_threshold: "1.0",
      high_threshold: "0.7",
      enable_sound: true,
      enable_browser: true,
      enable_email: false,
      email_address: "",
      refresh_interval: 30,
      prediction_interval: 300,
      adafruit_username: process.env.ADAFRUIT_USERNAME || "varshinicb99",
      adafruit_key: process.env.ADAFRUIT_KEY || "aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe",
      eco2_feed: "eCO2",
      tvoc_feed: "tvoc",
      etoh_feed: "EtOH",
      iaq_feed: "indoor-aqi"
    };
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Sensor data methods
  async saveSensorData(data: InsertSensorData): Promise<SensorData> {
    const id = this.sensorDataIdCounter++;
    const timestamp = new Date();
    const sensorDataItem: SensorData = { ...data, id, timestamp };
    this.sensorDataList.set(id, sensorDataItem);
    return sensorDataItem;
  }

  async getLatestSensorData(): Promise<SensorData | undefined> {
    const allData = Array.from(this.sensorDataList.values());
    if (allData.length === 0) return undefined;
    
    // Sort by timestamp descending and return the latest
    return allData.sort((a, b) => 
      b.timestamp.getTime() - a.timestamp.getTime()
    )[0];
  }

  async getSensorDataHistory(hours: number): Promise<SensorData[]> {
    const allData = Array.from(this.sensorDataList.values());
    const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);
    
    return allData
      .filter(data => data.timestamp >= cutoffTime)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  // Alert methods
  async createAlert(alert: InsertAlert): Promise<Alert> {
    const id = this.alertIdCounter++;
    const timestamp = new Date();
    const alertItem: Alert = { ...alert, id, timestamp, acknowledged: false };
    this.alertsList.set(id, alertItem);
    return alertItem;
  }

  async getAlerts(limit: number): Promise<Alert[]> {
    const allAlerts = Array.from(this.alertsList.values());
    
    return allAlerts
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async getAlertsByType(type: string): Promise<Alert[]> {
    const allAlerts = Array.from(this.alertsList.values());
    
    return allAlerts
      .filter(alert => alert.alertType === type)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async acknowledgeAlert(id: number): Promise<Alert | undefined> {
    const alert = this.alertsList.get(id);
    if (!alert) return undefined;
    
    const updatedAlert: Alert = { ...alert, acknowledged: true };
    this.alertsList.set(id, updatedAlert);
    return updatedAlert;
  }

  // Settings methods
  async getSettings(): Promise<Settings | undefined> {
    return this.appSettings;
  }

  async saveSettings(newSettings: Partial<InsertSettings>): Promise<Settings> {
    if (!this.appSettings) {
      const id = 1;
      this.appSettings = {
        id,
        critical_threshold: newSettings.critical_threshold || "1.0",
        high_threshold: newSettings.high_threshold || "0.7",
        enable_sound: newSettings.enable_sound ?? true,
        enable_browser: newSettings.enable_browser ?? true,
        enable_email: newSettings.enable_email ?? false,
        email_address: newSettings.email_address || "",
        refresh_interval: newSettings.refresh_interval || 30,
        prediction_interval: newSettings.prediction_interval || 300,
        adafruit_username: newSettings.adafruit_username || process.env.ADAFRUIT_USERNAME || "varshinicb99",
        adafruit_key: newSettings.adafruit_key || process.env.ADAFRUIT_KEY || "aio_IeYt11LJWFXdMgyJqQjcUDcYtwXe",
        eco2_feed: newSettings.eco2_feed || "eCO2",
        tvoc_feed: newSettings.tvoc_feed || "tvoc",
        etoh_feed: newSettings.etoh_feed || "EtOH",
        iaq_feed: newSettings.iaq_feed || "indoor-aqi"
      };
    } else {
      this.appSettings = {
        ...this.appSettings,
        ...newSettings
      };
    }
    
    return this.appSettings;
  }
}

export const storage = new MemStorage();
