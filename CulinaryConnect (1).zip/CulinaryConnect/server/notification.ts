/**
 * Notification Service
 * Handles SMS and email notifications for alerts
 * Uses free services that don't require API keys
 */

import axios from 'axios';
import { ProcessedData } from '../shared/schema';
import { log } from './vite';

// Record to track when we last sent notifications to avoid spam
const lastNotificationSent: Record<string, number> = {
  'low': 0,
  'medium': 0,
  'high': 0,
  'critical': 0
};

// Cooldown periods for different alert levels (in milliseconds)
const NOTIFICATION_COOLDOWNS: Record<string, number> = {
  'low': 60 * 60 * 1000, // 1 hour
  'medium': 30 * 60 * 1000, // 30 minutes
  'high': 15 * 60 * 1000, // 15 minutes
  'critical': 5 * 60 * 1000 // 5 minutes
};

/**
 * Free SMS service - this implementation mimics sending SMS without actually sending
 * In a production environment, replace with a real SMS gateway
 * 
 * For a free alternative to SendGrid, you could use:
 * 1. Twilio free trial
 * 2. Vonage free trial
 * 3. MessageBird free credits
 * 4. Clickatell free test messages
 */
async function sendFreeSms(phoneNumber: string, message: string, alertType: string): Promise<boolean> {
  try {
    // Log the SMS that would be sent
    log(`[NOTIFICATION] Would send SMS to ${phoneNumber}: ${message}`, 'notification');
    
    // For demo purposes, make a GET request to webhook.site which provides
    // a free request inspection service - this helps to verify the notification
    // system is working without actually sending SMS
    // Replace YOUR_WEBHOOK_URL with a webhook URL from webhook.site
    const webhookUrl = 'https://webhook.site/echo';
    
    // Send notification data to webhook for testing
    await axios.post(webhookUrl, {
      phoneNumber,
      message,
      alertType,
      timestamp: new Date().toISOString()
    });
    
    return true;
  } catch (error) {
    log(`Error in sendFreeSms: ${error}`, 'notification');
    return false;
  }
}

/**
 * Format alert message based on alert level and sensor data
 */
function formatAlertMessage(
  alertLevel: string, 
  data: ProcessedData,
  location: string = 'Main Hall'
): string {
  const timestamp = new Date().toLocaleTimeString('en-IN', { 
    timeZone: 'Asia/Kolkata',
    hour: '2-digit', 
    minute: '2-digit'
  });
  
  const baseMessage = `[${alertLevel.toUpperCase()}] Crowd Density Alert at ${location}`;
  
  let details = '';
  switch (alertLevel) {
    case 'critical':
      details = `IMMEDIATE ACTION: Critical crowd density (${data.density.toFixed(2)}) detected. Estimated ${data.crowdCount} people. Risk of overcrowding!`;
      break;
    case 'high':
      details = `High crowd density (${data.density.toFixed(2)}) detected. Estimated ${data.crowdCount} people. Monitor situation closely.`;
      break;
    case 'medium':
      details = `Medium crowd density (${data.density.toFixed(2)}) detected. Estimated ${data.crowdCount} people.`;
      break;
    case 'low':
      details = `Low crowd density (${data.density.toFixed(2)}) detected. Estimated ${data.crowdCount} people. Normal conditions.`;
      break;
  }
  
  return `${baseMessage} at ${timestamp}\n${details}`;
}

/**
 * Send alert notification via SMS
 */
export async function sendAlertNotification(
  alertType: string,
  data: ProcessedData,
  phoneNumbers: string[]
): Promise<boolean> {
  // Check if we're in cooldown period for this alert type
  const now = Date.now();
  const lastSent = lastNotificationSent[alertType] || 0;
  const cooldown = NOTIFICATION_COOLDOWNS[alertType] || 30 * 60 * 1000; // Default 30 min
  
  if (now - lastSent < cooldown) {
    log(`Skipping ${alertType} notification due to cooldown period`, 'notification');
    return false;
  }
  
  // Format alert message
  const message = formatAlertMessage(alertType, data);
  
  // Track notification attempt
  lastNotificationSent[alertType] = now;
  
  // No phone numbers provided
  if (!phoneNumbers || phoneNumbers.length === 0) {
    log('No phone numbers provided for notification', 'notification');
    return false;
  }
  
  // Send to all phone numbers
  const results = await Promise.all(
    phoneNumbers.map(phone => sendFreeSms(phone, message, alertType))
  );
  
  // Return true if at least one SMS was sent successfully
  return results.some(result => result === true);
}

/**
 * Determine alert level from sensor data and thresholds
 */
export function getAlertLevel(
  density: number,
  criticalThreshold: number = 0.9,
  highThreshold: number = 0.7,
  mediumThreshold: number = 0.3
): string {
  if (density >= criticalThreshold) {
    return 'critical';
  } else if (density >= highThreshold) {
    return 'high';
  } else if (density >= mediumThreshold) {
    return 'medium';
  } else {
    return 'low';
  }
}